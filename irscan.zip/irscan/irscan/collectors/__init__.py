"""按平台选择采集器实现。"""

from ..core.engine import ScanConfig
from .base import BaseCollector
from .linux import LinuxCollector
from .macos import MacOSCollector
from .windows import WindowsCollector

__all__ = ["BaseCollector", "LinuxCollector", "MacOSCollector",
           "WindowsCollector", "collect"]

PLATFORM_COLLECTORS = {
    "linux": LinuxCollector,
    "windows": WindowsCollector,
    "macos": MacOSCollector,
}


def collect(config: ScanConfig) -> "object":
    """按平台分发采集器。"""
    from ..core.engine import detect_platform

    name = detect_platform(config.platform_override)
    cls = PLATFORM_COLLECTORS.get(name)
    if cls is None:
        raise NotImplementedError(f"暂不支持的平台: {name}")
    return cls(config)()
