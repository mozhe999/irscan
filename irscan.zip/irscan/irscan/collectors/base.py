"""采集器基类。"""

from __future__ import annotations

import os
import platform as platform_mod

from ..core.engine import ScanConfig
from ..core.models import HostSnapshot


class BaseCollector:
    """采集器接口。collect() 不抛异常，失败项记入 error 供报告标注盲区。"""

    platform = "unknown"

    def __init__(self, config: ScanConfig) -> None:
        self.config = config
        self.timeout = config.timeout

        self.root = getattr(config, "root", None) or "/"

    def _p(self, path: str) -> str:
        """把系统绝对路径映射到采集根下，使测试可以用临时目录树替代真实 /proc。"""
        if self.root == "/":
            return path
        return os.path.join(self.root, path.lstrip("/"))

    @property
    def is_live_root(self) -> bool:
        """采集对象是否为当前运行中的系统。"""
        return self.root == "/"

    def collect(self) -> HostSnapshot:
        raise NotImplementedError

    def __call__(self, config: ScanConfig | None = None) -> HostSnapshot:
        """支持 `Collector(config)()` 形式，便于注册为可调用对象。"""
        if config is not None:
            self.config = config
            self.timeout = config.timeout
        snap = HostSnapshot(platform=self.platform, hostname=platform_mod.node())
        try:
            return self.collect()
        except Exception as exc:
            snap.note_error(f"{type(self).__name__} 采集异常: {exc}")
            return snap
