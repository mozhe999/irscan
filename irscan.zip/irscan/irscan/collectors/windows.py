"""Windows 采集器：进程与账户走 PowerShell CIM，安全日志用 wevtutil 导出 XML。"""

from __future__ import annotations

import csv
import io
import os
import platform as platform_mod
import re
import xml.etree.ElementTree as ET
from datetime import datetime

from ..core.models import (
    AccountInfo,
    ConnectionInfo,
    EventRecord,
    FileInfo,
    HostSnapshot,
    ProcessInfo,
    ServiceInfo,
    StartupItem,
    WmiSubscription,
)
from ..core.utils import run_command
from .base import BaseCollector


def classify_service_path(raw_path: str, path: str) -> str:
    """返回服务路径的风险标记：missing_binary / user_writable / unquoted_space。"""
    if not path:
        return ""

    if raw_path.startswith('"'):
        end = raw_path.find('"', 1)
        exe = raw_path[1:end] if end > 0 else path
    else:
        exe = path.split(" ")[0]

    low = exe.lower()

    if ("\\users\\" in low or low.startswith("c:\\users")
            or "\\appdata\\" in low or "\\temp\\" in low
            or "\\windows\\temp" in low
            or ("\\programdata\\" in low and "\\programdata\\microsoft\\" not in low)):
        return "user_writable"

    if (not raw_path.startswith('"') and " " in path
            and not path.split(" ")[0].lower().endswith((".exe", ".dll", ".sys"))):
        return "unquoted_space"

    if exe.lower().endswith((".exe", ".dll", ".sys")) and not os.path.isfile(exe):
        return "missing_binary"
    return "third_party"

PS = ["powershell", "-NoProfile", "-NonInteractive", "-Command"]

_PS_UTF8 = "[Console]::OutputEncoding=[System.Text.Encoding]::UTF8;"

_ISO_RE = re.compile(
    r"(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?"
)


def parse_iso(raw: str) -> datetime | None:
    """解析事件日志时间戳，失败返回 None。"""
    m = _ISO_RE.search(raw or "")
    if not m:
        return None
    frac = m.group(7) or "0"
    micro = int((frac + "000000")[:6])
    try:
        return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)),
                        int(m.group(4)), int(m.group(5)), int(m.group(6)), micro)
    except ValueError:
        return None


def _strip_ns(tag: str) -> str:
    return tag.split("}", 1)[1] if "}" in tag else tag


class WindowsCollector(BaseCollector):
    platform = "windows"

    def collect(self) -> HostSnapshot:
        snap = HostSnapshot(platform="windows", hostname=platform_mod.node())

        def guard(label: str, fn):
            try:
                return fn() or []
            except Exception as exc:
                snap.note_error(f"{label}采集失败: {exc}")
                return []

        snap.processes = guard("进程", lambda: self.processes(snap))
        snap.connections = guard("网络连接", lambda: self.connections(snap))
        snap.startup = guard("持久化项", lambda: self.startup(snap))
        snap.accounts = guard("账户", lambda: self.accounts(snap))
        snap.events = guard("安全事件", lambda: self.security_events(snap))
        snap.services = guard("服务", lambda: self.services(snap))
        snap.wmi = guard("WMI 订阅", lambda: self.wmi_subscriptions(snap))
        snap.files = guard("敏感文件", lambda: self.sensitive_files(snap))
        try:
            self.cross_view(snap)
        except Exception as exc:
            snap.note_error(f"交叉视角采集失败: {exc}")
        return snap

    def cross_view(self, snap: HostSnapshot) -> None:
        """通过 tasklist 取 PID 列表，用于和 CIM 视角比对。"""
        snap.extra["visible_pids"] = self._cmdline_pids()

    def _cmdline_pids(self) -> list[str]:
        code, out, _ = run_command(["tasklist", "/FO", "CSV", "/NH"], timeout=self.timeout)
        if code != 0:
            return []
        pids: list[str] = []
        for row in csv.reader(io.StringIO(out)):
            if len(row) >= 2 and row[1].strip().strip('"').isdigit():
                pids.append(row[1].strip().strip('"'))
        return pids

    def _ps(self, script: str) -> str:
        rc, out, err = run_command(PS + [_PS_UTF8 + script], timeout=self.timeout)
        if rc != 0:
            return ""
        return out

    def processes(self, snap: HostSnapshot) -> list[ProcessInfo]:
        script = (
            "Get-CimInstance Win32_Process | "
            "Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine | "
            "ConvertTo-Csv -NoTypeInformation"
        )
        raw = self._ps(script)
        if not raw.strip():
            snap.note_error("无法通过 CIM 获取进程列表（PowerShell 不可用或被策略禁用）")
            return self._processes_fallback(snap)

        out: list[ProcessInfo] = []
        try:
            reader = csv.DictReader(io.StringIO(raw.strip()))
            for row in reader:
                try:
                    pid = int(row.get("ProcessId") or -1)
                except ValueError:
                    continue
                out.append(ProcessInfo(
                    pid=pid,
                    name=(row.get("Name") or "").strip(),
                    ppid=int(row.get("ParentProcessId") or -1),
                    exe=(row.get("ExecutablePath") or "").strip(),
                    cmdline=(row.get("CommandLine") or "").strip(),
                ))
        except Exception as exc:
            snap.note_error(f"解析进程列表失败: {exc}")
        return out

    def _processes_fallback(self, snap: HostSnapshot) -> list[ProcessInfo]:
        """CIM 不可用时退回 tasklist，只能拿到进程名。"""
        rc, out, _ = run_command(["tasklist", "/FO", "CSV", "/NH"], timeout=self.timeout)
        if rc != 0:
            snap.note_error("tasklist 也不可用，进程信息缺失")
            return []
        items: list[ProcessInfo] = []
        for row in csv.reader(io.StringIO(out)):
            if len(row) < 2:
                continue
            try:
                items.append(ProcessInfo(pid=int(row[1]), name=row[0].strip()))
            except ValueError:
                continue
        return items

    def connections(self, snap: HostSnapshot) -> list[ConnectionInfo]:
        rc, out, _ = run_command(["netstat", "-ano"], timeout=self.timeout)
        if rc != 0:
            snap.note_error("netstat 执行失败，网络连接信息缺失")
            return []

        pid_names = {p.pid: p.name for p in snap.processes}
        items: list[ConnectionInfo] = []
        for line in out.splitlines():
            parts = line.split()
            if len(parts) < 4 or parts[0].upper() not in ("TCP", "UDP"):
                continue
            proto, local, remote = parts[0].upper(), parts[1], parts[2]
            if proto == "UDP":
                state, pid_raw = "", parts[-1]
            else:
                if len(parts) < 5:
                    continue
                state, pid_raw = parts[3], parts[4]

            def split_addr(v: str) -> tuple[str, int]:
                if v.startswith("["):
                    addr, _, rest = v[1:].partition("]")
                    port = rest.lstrip(":")
                else:
                    addr, _, port = v.rpartition(":")
                try:
                    return addr, int(port)
                except ValueError:
                    return addr, 0

            laddr, lport = split_addr(local)
            raddr, rport = split_addr(remote)
            try:
                pid = int(pid_raw)
            except ValueError:
                pid = -1
            items.append(ConnectionInfo(
                proto=proto, local_addr=laddr, local_port=lport,
                remote_addr=raddr, remote_port=rport, state=state.upper(),
                pid=pid, process=pid_names.get(pid, ""),
            ))
        return items

    def startup(self, snap: HostSnapshot) -> list[StartupItem]:
        items: list[StartupItem] = []
        items.extend(self._scheduled_tasks(snap))
        items.extend(self._run_keys(snap))
        return items

    def _scheduled_tasks(self, snap: HostSnapshot) -> list[StartupItem]:
        rc, out, _ = run_command(["schtasks", "/Query", "/FO", "CSV", "/V"], timeout=self.timeout)
        if rc != 0 or not out.strip():
            snap.note_error("无法查询计划任务（权限不足或 schtasks 不可用）")
            return []

        rows = list(csv.reader(io.StringIO(out)))
        if len(rows) < 2:
            return []
        header = rows[0]

        def col(*keywords: str) -> int:
            for i, h in enumerate(header):
                low = h.lower()
                if all(k in low for k in keywords):
                    return i
            return -1

        i_name = col("taskname") or col("任务名") or 0
        i_cmd = col("task to run") or col("要运行的任务")
        i_status = col("status") or col("状态")

        items: list[StartupItem] = []
        for row in rows[1:]:
            if len(row) <= i_name:
                continue
            name = row[i_name].strip().lstrip("\\")
            if not name or name.lower() == "taskname":
                continue
            cmd = row[i_cmd].strip() if 0 <= i_cmd < len(row) else ""
            status = row[i_status].strip() if 0 <= i_status < len(row) else ""
            items.append(StartupItem(
                source="计划任务", name=name, command=cmd,
                enabled=status.lower() not in ("disabled", "已禁用"),
            ))
        return items

    def _run_keys(self, snap: HostSnapshot) -> list[StartupItem]:
        keys = [
            r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
            r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
            r"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
            r"HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run",
        ]
        items: list[StartupItem] = []
        for key in keys:
            rc, out, _ = run_command(["reg", "query", key], timeout=self.timeout)
            if rc != 0:
                continue
            for line in out.splitlines():
                line = line.strip()
                if not line or line.startswith(("HKEY", "结束", "End of")):
                    continue

                parts = line.split(None, 2)
                if len(parts) < 3:
                    continue
                name, _typ, value = parts
                items.append(StartupItem(source="注册表 Run", name=name, command=value))
        return items

    def accounts(self, snap: HostSnapshot) -> list[AccountInfo]:
        script = (
            "Get-CimInstance Win32_UserAccount | "
            "Select-Object Name,Disabled,LocalAccount,SID,Lockout | "
            "ConvertTo-Csv -NoTypeInformation"
        )
        raw = self._ps(script)
        if raw.strip():
            items: list[AccountInfo] = []
            try:
                for row in csv.DictReader(io.StringIO(raw.strip())):
                    name = (row.get("Name") or "").strip()
                    if not name:
                        continue
                    disabled = str(row.get("Disabled", "")).strip().lower() == "true"
                    sid = (row.get("SID") or "").strip()
                    note = ""
                    if sid.endswith("-500"):
                        note = "内置 Administrator（RID 500），建议确认是否应禁用"
                    elif name.endswith("$"):
                        note = "机器账户"
                    items.append(AccountInfo(
                        username=name, uid=sid,
                        enabled=not disabled, note=note,
                    ))
            except Exception as exc:
                snap.note_error(f"解析账户列表失败: {exc}")
            if items:
                return items

        rc, out, _ = run_command(["net", "user"], timeout=self.timeout)
        if rc != 0:
            snap.note_error("无法获取账户列表")
            return []
        names: list[str] = []
        started = False
        for line in out.splitlines():
            line = line.strip()
            if not line or line.startswith("-"):
                continue
            if "命令成功" in line or "command completed" in line.lower():
                break
            if not started:
                if re.match(r"^\\?[Uu]ser accounts", line) or "的用户帐户" in line:
                    started = True
                continue
            for tok in line.split():
                if tok and not tok.startswith("*"):
                    names.append(tok)
        return [AccountInfo(username=n, note="未能确认启用状态") for n in names]

    def services(self, snap: HostSnapshot) -> list[ServiceInfo]:
        """返回服务列表，路径风险由 classify_service_path 标注。"""
        script = (
            "Get-CimInstance Win32_Service | "
            "Select-Object Name,DisplayName,PathName,State,StartMode,StartName | "
            "ConvertTo-Csv -NoTypeInformation"
        )
        raw = self._ps(script)
        if not raw.strip():
            snap.note_error("无法获取服务列表")
            return []
        items: list[ServiceInfo] = []
        try:
            for row in csv.DictReader(io.StringIO(raw.strip())):
                name = (row.get("Name") or "").strip()
                if not name:
                    continue
                raw_path = (row.get("PathName") or "").strip()
                path = raw_path.strip('"')
                items.append(ServiceInfo(
                    name=name,
                    display_name=(row.get("DisplayName") or "").strip(),
                    path=path,
                    state=(row.get("State") or "").strip(),
                    start_mode=(row.get("StartMode") or "").strip(),
                    user=(row.get("StartName") or "").strip(),
                    note="",
                    risk=classify_service_path(raw_path, path),
                ))
        except Exception as exc:
            snap.note_error(f"解析服务列表失败: {exc}")
        return items

    def wmi_subscriptions(self, snap: HostSnapshot) -> list[WmiSubscription]:
        """查询 WMI 永久事件订阅：__EventFilter 与 CommandLineEventConsumer。"""
        script = (
            "Get-CimInstance -Namespace root/subscription -ClassName __EventFilter "
            "| Select-Object Name,Query | ConvertTo-Csv -NoTypeInformation"
        )
        raw = self._ps(script)
        if not raw.strip():
            snap.note_error("无法查询 WMI 事件订阅（需管理员权限）")
            return []

        items: list[WmiSubscription] = []
        try:
            for row in csv.DictReader(io.StringIO(raw.strip())):
                name = (row.get("Name") or "").strip()
                if not name:
                    continue
                items.append(WmiSubscription(
                    kind="Filter", name=name,
                    query=(row.get("Query") or "").strip(),
                    note="事件过滤器：定义了在什么条件下触发",
                ))
        except Exception as exc:
            snap.note_error(f"解析 WMI Filter 失败: {exc}")

        script_c = (
            "Get-CimInstance -Namespace root/subscription -ClassName CommandLineEventConsumer "
            "| Select-Object Name,CommandLineTemplate | ConvertTo-Csv -NoTypeInformation"
        )
        raw_c = self._ps(script_c)
        if raw_c.strip():
            try:
                for row in csv.DictReader(io.StringIO(raw_c.strip())):
                    name = (row.get("Name") or "").strip()
                    if not name:
                        continue
                    items.append(WmiSubscription(
                        kind="Consumer", name=name,
                        command=(row.get("CommandLineTemplate") or "").strip(),
                        note="命令行消费者：事件触发时执行的命令（重点核查）",
                    ))
            except Exception as exc:
                snap.note_error(f"解析 WMI Consumer 失败: {exc}")
        return items

    def sensitive_files(self, snap: HostSnapshot) -> list[FileInfo]:
        out: list[FileInfo] = []
        out.extend(self._hosts_file())
        out.extend(self._startup_folders())
        return out

    def _hosts_file(self) -> list[FileInfo]:
        path = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                            "System32", "drivers", "etc", "hosts")
        if not os.path.isfile(path):
            return []
        try:
            with open(path, "rb") as fh:
                content = fh.read().decode("utf-8", errors="replace")
        except OSError:
            return []
        entries = [l.strip() for l in content.splitlines()
                   if l.strip() and not l.strip().startswith("#")]
        try:
            mtime = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M:%S")
        except OSError:
            mtime = ""
        return [FileInfo(path=path, kind="hosts", size=os.path.getsize(path),
                         modified_at=mtime, content="\n".join(entries[:10]),
                         note=f"{len(entries)} 条解析记录，被篡改可用于流量劫持")]

    def _startup_folders(self) -> list[FileInfo]:
        """开始菜单的「启动」文件夹，注册表 Run 之外的持久化位置。"""
        out: list[FileInfo] = []
        appdata = os.environ.get("APPDATA", "")
        programdata = os.environ.get("ProgramData", "")
        dirs = []
        if appdata:
            dirs.append(os.path.join(appdata, "Microsoft", "Windows",
                                     "Start Menu", "Programs", "Startup"))
        if programdata:
            dirs.append(os.path.join(programdata, "Microsoft", "Windows",
                                     "Start Menu", "Programs", "Startup"))
        for d in dirs:
            if not os.path.isdir(d):
                continue
            try:
                for name in os.listdir(d):
                    path = os.path.join(d, name)
                    if not os.path.isfile(path):
                        continue
                    try:
                        mtime = datetime.fromtimestamp(
                            os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M:%S")
                    except OSError:
                        mtime = ""
                    out.append(FileInfo(path=path, kind="startup_folder",
                                        size=os.path.getsize(path),
                                        modified_at=mtime,
                                        note="开机自动运行，需确认归属"))
            except OSError:
                continue
        return out

    def security_events(self, snap: HostSnapshot) -> list[EventRecord]:
        ms = int(self.config.event_hours * 3600 * 1000)
        query = (
            f"*[System[(EventID=4624 or EventID=4625) and "
            f"TimeCreated[timediff(@SystemTime) <= {ms}]]]"
        )
        rc, out, err = run_command(
            ["wevtutil", "qe", "Security", f"/q:{query}", "/f:xml",
             f"/c:3000", "/rd:true"],
            timeout=self.timeout,
        )
        if rc != 0:
            snap.note_error(
                f"未能读取 Windows 安全日志（通常需要管理员权限）: {err.strip()[:200]}"
            )
            return []
        return self._parse_events(out, snap)

    def _parse_events(self, xml_text: str, snap: HostSnapshot) -> list[EventRecord]:

        wrapped = f"<Events>{xml_text.strip()}</Events>"
        try:
            root = ET.fromstring(wrapped)
        except ET.ParseError as exc:
            snap.note_error(f"安全日志 XML 解析失败: {exc}")
            return []

        records: list[EventRecord] = []
        for node in root:
            if _strip_ns(node.tag) != "Event":
                continue
            event_id = 0
            stamp: datetime | None = None
            fields: dict[str, str] = {}
            for child in node.iter():
                tag = _strip_ns(child.tag)
                if tag == "EventID" and not event_id:
                    try:
                        event_id = int((child.text or "0").strip())
                    except ValueError:
                        pass
                elif tag == "TimeCreated":
                    stamp = parse_iso(child.attrib.get("SystemTime", ""))
                elif tag == "Data" and child.attrib.get("Name"):
                    fields[child.attrib["Name"]] = (child.text or "").strip()
            if event_id in (4624, 4625):
                records.append(EventRecord(event_id=event_id, timestamp=stamp, fields=fields))
        return records
