"""macOS 采集器：没有 /proc，只能走 ps / lsof / launchctl 等命令行。"""

from __future__ import annotations

import os
import platform as platform_mod
import re

from ..core.models import (
    AccountInfo,
    ConnectionInfo,
    FileInfo,
    HostSnapshot,
    ProcessInfo,
    StartupItem,
)
from ..core.utils import read_text, run_command
from .base import BaseCollector

LAUNCH_DIRS = (
    "/Library/LaunchDaemons",
    "/Library/LaunchAgents",
    "/System/Library/LaunchDaemons",
)


class MacOSCollector(BaseCollector):
    platform = "macos"

    def collect(self) -> HostSnapshot:
        snap = HostSnapshot(platform="macos", hostname=platform_mod.node())

        snap.extra["data_from_commands"] = True

        def guard(label: str, fn):
            try:
                return fn() or []
            except Exception as exc:
                snap.note_error(f"{label}采集失败: {exc}")
                return []

        snap.processes = guard("进程", self.processes)
        snap.connections = guard("网络连接", self.connections)
        snap.startup = guard("持久化项", self.startup)
        snap.accounts = guard("账户", self.accounts)
        snap.files = guard("敏感文件", self.sensitive_files)
        return snap

    def processes(self) -> list[ProcessInfo]:
        """ps 在 macOS 上的输出格式与 Linux 不同。"""
        out: list[ProcessInfo] = []
        code, raw, _ = run_command(
            ["ps", "-eo", "pid=,ppid=,comm=,args="], timeout=self.timeout)
        if code != 0:
            return out
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(None, 3)
            if len(parts) < 3:
                continue
            try:
                pid, ppid = int(parts[0]), int(parts[1])
            except ValueError:
                continue
            comm = parts[2]
            cmdline = parts[3] if len(parts) > 3 else ""
            exe = cmdline.split()[0] if cmdline else comm
            out.append(ProcessInfo(pid=pid, name=os.path.basename(comm),
                                   ppid=ppid, exe=exe, cmdline=cmdline))
        return out

    def connections(self) -> list[ConnectionInfo]:
        """连接列表，含持有连接的进程名。"""
        out: list[ConnectionInfo] = []
        code, raw, _ = run_command(
            ["lsof", "-nP", "-iTCP", "-iUDP", "-F", "pcnPT"], timeout=self.timeout)
        if code != 0:
            return out
        cur: dict[str, str] = {}
        for line in raw.splitlines():
            if len(line) < 2:
                continue
            tag, val = line[0], line[1:]
            if tag == "p":
                if cur.get("addr"):
                    out.extend(self._emit(cur))
                cur = {"pid": val}
            elif tag == "c":
                cur["cmd"] = val
            elif tag == "P":
                cur["proto"] = "tcp" if val.lower() == "tcp" else "udp"
            elif tag == "T":
                cur["state"] = val
            elif tag == "n":
                cur["addr"] = val
        if cur.get("addr"):
            out.extend(self._emit(cur))
        return out

    def _emit(self, rec: dict[str, str]) -> list[ConnectionInfo]:
        """把 lsof 记录拆成本端与远端地址。"""
        addr = rec.get("addr", "")
        proto = rec.get("proto", "tcp")
        try:
            pid = int(rec.get("pid", "-1"))
        except ValueError:
            pid = -1
        if "->" in addr:
            local, remote = addr.split("->", 1)
        else:
            local, remote = addr, ""
        lip, lport = self._split_host_port(local)
        rip, rport = self._split_host_port(remote)
        return [ConnectionInfo(
            proto=proto, local_addr=lip, local_port=lport,
            remote_addr=rip, remote_port=rport,
            state=rec.get("state", ""), pid=pid,
            process=rec.get("cmd", ""),
        )]

    @staticmethod
    def _split_host_port(raw: str) -> tuple[str, int]:
        if not raw or ":" not in raw:
            return raw or "", 0
        host, _, port = raw.rpartition(":")

        host = host.strip("[]")
        try:
            return host, int(port)
        except ValueError:
            return host, 0

    def startup(self) -> list[StartupItem]:
        """launchd 是 macOS 的主要持久化机制，plist 相当于注册表 Run 项。"""
        items: list[StartupItem] = []
        for d in LAUNCH_DIRS:
            if not os.path.isdir(d):
                continue
            try:
                names = os.listdir(d)
            except OSError:
                continue
            for name in names:
                if not name.endswith(".plist"):
                    continue
                path = os.path.join(d, name)
                cmd = self._plist_program(path)
                items.append(StartupItem(
                    source="launchd:" + d,
                    name=name[:-6],
                    command=cmd or path,
                ))
        items.extend(self._cron())
        return items

    @staticmethod
    def _plist_program(path: str) -> str:
        """从 plist 中取可执行命令。"""
        try:
            text = read_text(path)
        except OSError:
            return ""
        if "<plist" not in text:
            code, out, _ = run_command(
                ["plutil", "-convert", "xml1", "-o", "-", path], timeout=15)
            text = out if code == 0 else ""
        m = re.search(r"<key>ProgramArguments</key>\s*<array>(.*?)</array>",
                      text, re.S)
        if m:
            args = re.findall(r"<string>(.*?)</string>", m.group(1), re.S)
            if args:
                return " ".join(a.strip() for a in args)
        m = re.search(r"<key>Program</key>\s*<string>(.*?)</string>", text, re.S)
        return m.group(1).strip() if m else ""

    def _cron(self) -> list[StartupItem]:
        items: list[StartupItem] = []
        try:
            code, raw, _ = run_command(["crontab", "-l"], timeout=self.timeout)
        except Exception:
            return items
        if code != 0:
            return items
        for line in raw.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                items.append(StartupItem(source="cron", name=line[:60], command=line))
        return items

    def accounts(self) -> list[AccountInfo]:
        """dscl 列出本地用户，下划线开头的为系统账户。"""
        out: list[AccountInfo] = []
        code, raw, _ = run_command(
            ["dscl", ".", "-list", "/Users", "UniqueID"], timeout=self.timeout)
        if code != 0:
            return out
        for line in raw.splitlines():
            parts = line.split()
            if len(parts) < 2 or parts[0].startswith("_"):
                continue
            try:
                uid = int(parts[1])
            except ValueError:
                continue
            out.append(AccountInfo(
                username=parts[0], uid=str(uid),
                shell=self._user_shell(parts[0]),
                home=os.path.join("/Users", parts[0]),
            ))
        return out

    @staticmethod
    def _user_shell(user: str) -> str:
        code, out, _ = run_command(
            ["dscl", ".", "-read", f"/Users/{user}", "UserShell"], timeout=10)
        if code != 0:
            return ""
        return out.split(":", 1)[-1].strip() if ":" in out else ""

    def sensitive_files(self) -> list[FileInfo]:
        """hosts、authorized_keys 与 shell 初始化文件，与 Linux 同类风险。"""
        out: list[FileInfo] = []
        home = os.path.expanduser("~")

        hosts = "/etc/hosts"
        if os.path.isfile(hosts):
            try:
                entries = [ln.strip() for ln in read_text(hosts).splitlines()
                           if ln.strip() and not ln.startswith("#")]
            except OSError:
                entries = []
            if entries:
                out.append(FileInfo(kind="hosts", path=hosts,
                                    content="\n".join(entries[:10]),
                                    note=f"{len(entries)} 条解析记录"))

        keys = os.path.join(home, ".ssh", "authorized_keys")
        if os.path.isfile(keys):
            try:
                content = read_text(keys)
            except OSError:
                content = ""
            n = len([ln for ln in content.splitlines()
                     if ln.strip() and not ln.startswith("#")])
            if n:
                out.append(FileInfo(kind="authorized_keys", path=keys,
                                    content=f"{n} 个公钥",
                                    note="当前用户的免密登录公钥文件"))

        for rel in (".bash_profile", ".zshrc", ".bashrc"):
            p = os.path.join(home, rel)
            if os.path.isfile(p):
                try:
                    content = read_text(p)
                except OSError:
                    continue
                if "PROMPT_COMMAND" in content:
                    out.append(FileInfo(
                        kind="shell_rc", path=p,
                        note="包含 PROMPT_COMMAND（每次回车都会执行）"))
        return out
