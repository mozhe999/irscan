"""Linux 采集器：直接读 /proc 与系统文件，不依赖 ps / netstat 等命令。"""

from __future__ import annotations

import os
import re
import shutil
import socket
from datetime import datetime

from ..core.models import (
    AccountInfo,
    ConnectionInfo,
    FileInfo,
    HostSnapshot,
    ProcessInfo,
    ServiceInfo,
    StartupItem,
)
from ..core.utils import read_text, run_command
from .base import BaseCollector

TCP_STATES = {
    "01": "ESTABLISHED",
    "02": "SYN_SENT",
    "03": "SYN_RECV",
    "04": "FIN_WAIT1",
    "05": "FIN_WAIT2",
    "06": "TIME_WAIT",
    "07": "CLOSE",
    "08": "CLOSE_WAIT",
    "09": "LAST_ACK",
    "0A": "LISTEN",
    "0B": "CLOSING",
}

CRON_DIRS = ("/etc/cron.d", "/var/spool/cron/crontabs", "/etc/cron.daily",
             "/etc/cron.hourly", "/etc/cron.weekly", "/etc/cron.monthly")


class LinuxCollector(BaseCollector):
    platform = "linux"

    def collect(self) -> HostSnapshot:
        snap = HostSnapshot(platform="linux", hostname=self.hostname())

        def guard(label: str, fn):
            try:
                return fn() or []
            except Exception as exc:
                snap.note_error(f"{label}采集失败: {exc}")
                return []

        snap.processes = guard("进程", self.processes)
        snap.connections = guard("网络连接", lambda: self.connections(snap.processes))
        snap.startup = guard("持久化项", self.startup)
        snap.accounts = guard("账户", self.accounts)
        snap.files = guard("敏感文件", self.sensitive_files)
        snap.services = guard("服务", self.services)
        try:
            self.cross_view(snap)
        except Exception as exc:
            snap.note_error(f"交叉视角采集失败: {exc}")
        return snap

    def cross_view(self, snap: HostSnapshot) -> None:
        """返回命令行视角的 PID 列表，用于和 /proc 视角比对。"""
        snap.extra["visible_pids"] = self._ps_pids()
        snap.extra["promisc"] = self._promisc_ifaces()
        snap.extra["shell_rc"] = self._shell_rc_hits()
        snap.extra["pkg_modified"] = self._pkg_integrity()

    def _ps_pids(self) -> list[str]:
        """通过 ps 取 PID 列表。"""
        if not self.is_live_root:
            return []
        code, out, _ = run_command(["ps", "-e", "-o", "pid="], timeout=self.timeout)
        if code != 0:
            return []
        return [line.strip() for line in out.splitlines() if line.strip().isdigit()]

    def _promisc_ifaces(self) -> list[str]:
        """返回处于混杂模式的网卡名。"""
        found: list[str] = []
        base = self._p("/sys/class/net")
        try:
            ifaces = os.listdir(base)
        except OSError:
            return found
        for iface in ifaces:
            if iface == "lo":
                continue
            try:
                flags = int(read_text(f"{base}/{iface}/flags").strip(), 16)
            except (OSError, ValueError):
                continue
            if flags & 0x100:
                found.append(iface)
        return found

    def _shell_rc_hits(self) -> list[str]:
        """返回 shell 初始化文件中的可疑行。"""
        targets = [self._p(x) for x in ("/etc/profile", "/etc/bashrc",
                                        "/etc/bash.bashrc", "/etc/zsh/zshrc",
                                        "/root/.bashrc", "/root/.bash_profile",
                                        "/root/.profile")]
        try:
            pdir = self._p("/etc/profile.d")
            targets += [os.path.join(pdir, n) for n in os.listdir(pdir)]
        except OSError:
            pass

        cmd_alias = re.compile(r"^\s*alias\s+(ls|ps|top|netstat|ss|lsof|df|who|w|last|history|find|cat|ps)\b", re.I)
        dangerous = re.compile(r"(curl|wget|nc\b|netcat|/dev/tcp/|bash\s+-i|python\s+-c|base64\s+-d)", re.I)
        hits: list[str] = []
        for path in targets:
            if not os.path.isfile(path):
                continue
            try:
                content = read_text(path)
            except OSError:
                continue
            for lineno, line in enumerate(content.splitlines(), 1):
                if line.strip().startswith("#") or "=" not in line and "alias" not in line:
                    continue
                if cmd_alias.search(line) or ("PROMPT_COMMAND" in line and dangerous.search(line)):
                    hits.append(f"{path}:{lineno}: {line.strip()[:160]}")
        return hits

    def _pkg_integrity(self) -> list[str]:
        """用包管理器校验关键命令的二进制是否被替换。"""

        if not self.is_live_root:
            return []
        critical = [self._p(x) for x in (
            "/usr/bin/ps", "/usr/bin/top", "/usr/bin/ls", "/usr/bin/netstat",
            "/usr/bin/lsof", "/usr/bin/ss", "/usr/bin/find", "/usr/bin/who",
            "/usr/bin/wget", "/usr/bin/curl", "/usr/sbin/sshd", "/bin/login")]
        existing = [p for p in critical if os.path.isfile(p)]
        if not existing:
            return []
        if shutil.which("rpm"):
            code, out, _ = run_command(["rpm", "-Vf"] + existing, timeout=self.timeout)

            return [ln.strip() for ln in out.splitlines() if ln.strip()] if code == 0 else []
        if shutil.which("dpkg"):
            hits: list[str] = []
            for path in existing:
                code, out, _ = run_command(
                    ["dpkg", "-S", path], timeout=self.timeout)
                if code != 0:
                    continue
                pkg = out.split(":")[0].strip()
                if not pkg:
                    continue
                code, out, _ = run_command(["dpkg", "-V", pkg], timeout=self.timeout)
                if code == 0 and out.strip():
                    hits.extend(ln.strip() for ln in out.splitlines() if path in ln)
            return hits
        return []

    def hostname(self) -> str:
        try:
            return read_text(self._p("/etc/hostname")).strip()
        except OSError:
            return socket.gethostname()

    def processes(self) -> list[ProcessInfo]:
        """解析 /proc/<pid> 下的 stat 与 cmdline，返回进程列表。"""
        out: list[ProcessInfo] = []
        try:
            entries = os.listdir(self._p("/proc"))
        except OSError:
            return out
        for entry in entries:
            if not entry.isdigit():
                continue
            pid = int(entry)
            stat_path = self._p(f"/proc/{entry}/stat")
            try:
                raw = read_text(stat_path)
            except OSError:
                continue
            try:
                tail = raw[raw.rindex(")") + 2:]
                fields = tail.split()
                ppid = int(fields[1])
            except (ValueError, IndexError):
                ppid = -1
            name = raw[raw.find("(") + 1: raw.rindex(")")]

            try:
                cmdline = read_text(self._p(f"/proc/{entry}/cmdline")).replace("\x00", " ").strip()
            except OSError:
                cmdline = ""
            try:
                exe = os.readlink(self._p(f"/proc/{entry}/exe"))
            except OSError:
                exe = ""

            out.append(ProcessInfo(pid=pid, name=name, ppid=ppid, exe=exe, cmdline=cmdline))
        return out

    def _parse_hex_addr(self, raw: str) -> tuple[str, int]:
        """把 /proc/net/tcp 的十六进制地址转为 (ip, port)。"""
        ip_hex, port_hex = raw.split(":")
        try:
            packed = bytes.fromhex(ip_hex)
            if len(packed) == 4:
                ip = ".".join(str(b) for b in reversed(packed))
            else:

                groups = [packed[i:i + 4] for i in range(0, 16, 4)]
                ip = ":".join("".join(f"{b:02x}" for b in reversed(g)) for g in groups)
            return ip, int(port_hex, 16)
        except ValueError:
            return "0.0.0.0", 0

    def _inode_pid_map(self, processes: list[ProcessInfo]) -> dict[str, ProcessInfo]:
        """socket inode 映射回进程，用于在报告中标明连接归属。"""
        mapping: dict[str, ProcessInfo] = {}
        for proc in processes:
            fd_dir = self._p(f"/proc/{proc.pid}/fd")
            try:
                fds = os.listdir(fd_dir)
            except OSError:
                continue
            for fd in fds:
                try:
                    target = os.readlink(os.path.join(fd_dir, fd))
                except OSError:
                    continue
                if target.startswith("socket:["):
                    mapping.setdefault(target[8:-1], proc)
        return mapping

    def connections(self, processes: list[ProcessInfo]) -> list[ConnectionInfo]:
        inode_map = self._inode_pid_map(processes)
        out: list[ConnectionInfo] = []
        for rel, proto in (("/proc/net/tcp", "tcp"), ("/proc/net/tcp6", "tcp6"),
                           ("/proc/net/udp", "udp"), ("/proc/net/udp6", "udp6")):
            path = self._p(rel)
            try:
                lines = read_text(path).splitlines()[1:]
            except OSError:
                continue
            for line in lines:
                parts = line.split()
                if len(parts) < 10:
                    continue
                laddr, lport = self._parse_hex_addr(parts[1])
                raddr, rport = self._parse_hex_addr(parts[2])
                state = TCP_STATES.get(parts[3], parts[3])
                inode = parts[9]
                proc = inode_map.get(inode)
                out.append(ConnectionInfo(
                    proto=proto, local_addr=laddr, local_port=lport,
                    remote_addr=raddr, remote_port=rport, state=state,
                    pid=proc.pid if proc else -1,
                    process=proc.name if proc else "",
                ))
        return out

    def startup(self) -> list[StartupItem]:
        items: list[StartupItem] = []
        items.extend(self._systemd())
        items.extend(self._cron())
        items.extend(self._rc_local())
        return items

    def _systemd(self) -> list[StartupItem]:
        """优先用 systemctl，失败则读 wants 目录的软链接。"""
        rc, out, _ = run_command(
            ["systemctl", "list-unit-files", "--type=service", "--state=enabled", "--no-legend"]
        )
        items: list[StartupItem] = []
        if rc == 0 and out.strip():
            for line in out.splitlines():
                name = line.split()[0]
                if name.endswith(".service"):
                    items.append(StartupItem(source="systemd", name=name))
            return items

        wants_root = self._p("/etc/systemd/system")
        try:
            for dirpath, _dirs, files in os.walk(wants_root):
                if not dirpath.endswith(".wants"):
                    continue
                for f in files:
                    items.append(StartupItem(
                        source="systemd", name=f,
                        command=os.path.join(dirpath, f),
                    ))
        except OSError:
            pass
        return items

    def _cron(self) -> list[StartupItem]:
        items: list[StartupItem] = []
        import glob

        paths: list[str] = [self._p("/etc/crontab")]
        for d in (self._p(x) for x in CRON_DIRS):
            if os.path.isdir(d):
                paths.extend(glob.glob(os.path.join(d, "*")))

        for path in paths:
            if not os.path.isfile(path):
                continue
            try:
                content = read_text(path)
            except OSError:
                continue
            for line in content.splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue

                if line.startswith("@") or len(line.split()) >= 6:
                    items.append(StartupItem(source="cron", name=path, command=line))
        return items

    def _rc_local(self) -> list[StartupItem]:
        for path in (self._p("/etc/rc.local"), self._p("/etc/rc.d/rc.local")):
            if os.path.isfile(path):
                try:
                    content = read_text(path)
                except OSError:
                    continue
                cmds = [l.strip() for l in content.splitlines()
                        if l.strip() and not l.strip().startswith("#") and "exit 0" not in l]
                return [StartupItem(source="rc.local", name=path, command=c) for c in cmds]
        return []

    def sensitive_files(self) -> list[FileInfo]:
        """返回敏感文件信息：SUID、ld.so.preload、authorized_keys、shell 配置。"""
        out: list[FileInfo] = []
        out.extend(self._suid_files())
        out.extend(self._ld_preload())
        out.extend(self._authorized_keys())
        out.extend(self._sudoers())
        out.extend(self._hosts_file())
        out.extend(self._history_files())
        return out

    def _stat_info(self, path: str) -> tuple[str, str, int, str]:
        try:
            st = os.stat(path)
        except OSError:
            return "", "", 0, ""
        import stat as stat_mod
        try:
            import pwd
            owner = pwd.getpwuid(st.st_uid).pw_name
        except Exception:
            owner = str(st.st_uid)
        from datetime import datetime as dt
        return (
            stat_mod.filemode(st.st_mode),
            owner,
            st.st_size,
            dt.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
        )

    def _walk_suid(self, roots: list[str]) -> list[str]:
        """用 lstat 遍历目录查找 SUID/SGID 文件。"""
        import stat as stat_mod

        hits: list[str] = []
        budget = 60000
        for root in roots:
            if not os.path.isdir(root):
                continue
            try:
                walker = os.walk(root)
            except OSError:
                continue
            for dirpath, dirnames, filenames in walker:
                dirnames[:] = [d for d in dirnames
                               if d not in ("proc", "sys", "dev", ".git")]
                for name in filenames:
                    if budget <= 0:
                        return hits
                    budget -= 1
                    full = os.path.join(dirpath, name)
                    try:
                        mode = os.lstat(full).st_mode
                    except OSError:
                        continue
                    if mode & (stat_mod.S_ISUID | stat_mod.S_ISGID):
                        hits.append(full)
        return hits

    def _suid_files(self) -> list[FileInfo]:
        """查找 SUID/SGID 文件，优先用 find，缺失时退回 Python 遍历。"""
        out: list[FileInfo] = []
        scan_dirs = [self._p(x) for x in
                     ("/usr", "/bin", "/sbin", "/opt", "/home", "/tmp", "/var")]

        found: list[str] = []
        if self.is_live_root and shutil.which("find"):
            rc, raw, _ = run_command(
                ["find"] + scan_dirs +
                ["-xdev", "-type", "f", "-perm", "-4000", "-o",
                 "-type", "f", "-perm", "-2000"],
                timeout=self.timeout,
            )
            if rc == 0:
                found = [ln.strip() for ln in raw.splitlines() if ln.strip()]
        if not found:
            found = self._walk_suid(scan_dirs)

        for path in found:
            path = path.strip()
            if not path:
                continue
            mode, owner, size, mtime = self._stat_info(path)
            kind = "suid" if "s" in mode[3] else "sgid"
            out.append(FileInfo(path=path, kind=kind, mode=mode, owner=owner,
                                size=size, modified_at=mtime))
        return out

    def _ld_preload(self) -> list[FileInfo]:
        """读取 /etc/ld.so.preload 内容。"""
        out: list[FileInfo] = []
        path = self._p("/etc/ld.so.preload")
        if not os.path.isfile(path):
            return out
        try:
            content = read_text(path).strip()
        except OSError:
            return out
        mode, owner, size, mtime = self._stat_info(path)
        note = ""
        if content:
            note = ("该文件非空，指定的共享库会被注入到所有动态链接进程，"
                    "是典型的 rootkit/后门手法")
        out.append(FileInfo(path=path, kind="ld_preload", mode=mode, owner=owner,
                            size=size, modified_at=mtime, content=content[:500],
                            note=note))
        return out

    def _authorized_keys(self) -> list[FileInfo]:
        """各用户 ~/.ssh/authorized_keys，落公钥即可免密长期驻留。"""
        out: list[FileInfo] = []
        try:
            import pwd
            homes = [(u.pw_name, u.pw_dir) for u in pwd.getpwall()
                     if u.pw_dir and os.path.isdir(u.pw_dir)]
        except Exception:
            homes = [("root", self._p("/root"))]
        for user, home in homes:
            path = os.path.join(home, ".ssh", "authorized_keys")
            if not os.path.isfile(path):
                continue
            try:
                content = read_text(path)
            except OSError:
                continue
            keys = [l for l in content.splitlines() if l.strip() and not l.startswith("#")]
            mode, owner, size, mtime = self._stat_info(path)
            out.append(FileInfo(
                path=path, kind="authorized_keys", mode=mode, owner=owner,
                size=size, modified_at=mtime,
                content=f"{len(keys)} 个公钥",
                note=f"用户 {user} 的免密登录公钥文件",
            ))
        return out

    def _sudoers(self) -> list[FileInfo]:
        """/etc/sudoers 与 /etc/sudoers.d，检查是否被加入 NOPASSWD。"""
        out: list[FileInfo] = []
        paths = [self._p("/etc/sudoers")]
        d = self._p("/etc/sudoers.d")
        if os.path.isdir(d):
            paths += [os.path.join(d, f) for f in os.listdir(d)]
        for path in paths:
            if not os.path.isfile(path):
                continue
            try:
                content = read_text(path)
            except OSError:
                continue
            mode, owner, size, mtime = self._stat_info(path)
            nopass = [l.strip() for l in content.splitlines()
                      if "NOPASSWD" in l and not l.strip().startswith("#")]
            note = f"含 {len(nopass)} 条 NOPASSWD 配置" if nopass else ""
            out.append(FileInfo(path=path, kind="sudoers", mode=mode, owner=owner,
                                size=size, modified_at=mtime,
                                content="\n".join(nopass[:5]), note=note))
        return out

    def _hosts_file(self) -> list[FileInfo]:
        """/etc/hosts，被篡改可用于把域名指向攻击者主机。"""
        path = self._p("/etc/hosts")
        if not os.path.isfile(path):
            return []
        try:
            content = read_text(path)
        except OSError:
            return []
        entries = [l.strip() for l in content.splitlines()
                   if l.strip() and not l.strip().startswith("#")]
        mode, owner, size, mtime = self._stat_info(path)
        return [FileInfo(path=path, kind="hosts", mode=mode, owner=owner,
                         size=size, modified_at=mtime,
                         content="\n".join(entries[:10]),
                         note=f"{len(entries)} 条解析记录")]

    def _history_files(self) -> list[FileInfo]:
        """shell history。历史被清空或大小突变本身也是线索。"""
        out: list[FileInfo] = []
        candidates = [self._p("/root/.bash_history")]
        try:
            import pwd
            for u in pwd.getpwall():
                if u.pw_dir:
                    candidates.append(os.path.join(u.pw_dir, ".bash_history"))
        except Exception:
            pass
        for path in dict.fromkeys(candidates):
            if not os.path.isfile(path):
                continue
            mode, owner, size, mtime = self._stat_info(path)
            if size == 0:
                note = "history 文件大小为 0，可能是被清空过（攻击者常用手法）"
            else:
                note = ""
            out.append(FileInfo(path=path, kind="history", mode=mode, owner=owner,
                                size=size, modified_at=mtime, note=note))
        return out

    def services(self) -> list[ServiceInfo]:
        """Linux 服务列表，systemd 优先，否则读 init.d。"""
        rc, out, _ = run_command(
            ["systemctl", "list-units", "--type=service", "--all", "--no-legend"],
            timeout=self.timeout,
        )
        items: list[ServiceInfo] = []
        if rc == 0 and out.strip():
            for line in out.splitlines():
                parts = line.split(None, 4)
                if len(parts) < 4:
                    continue
                name, _load, active, sub = parts[:4]
                items.append(ServiceInfo(name=name, state=f"{active}/{sub}"))
            return items
        d = self._p("/etc/init.d")
        if os.path.isdir(d):
            items = [ServiceInfo(name=n, path=os.path.join(d, n), state="unknown")
                     for n in os.listdir(d) if not n.endswith((".sh", ".rpm"))]
        return items

    def accounts(self) -> list[AccountInfo]:
        try:
            lines = read_text(self._p("/etc/passwd")).splitlines()
        except OSError:
            return []

        out: list[AccountInfo] = []
        for line in lines:
            if not line.strip() or line.startswith("#"):
                continue
            parts = line.split(":")
            if len(parts) < 7:
                continue
            user, _pw, uid, gid, _gecos, home, shell = parts[:7]
            note = ""
            if uid == "0" and user != "root":
                note = "非 root 用户却拥有 uid=0，等同于 root 权限"
            out.append(AccountInfo(
                username=user, uid=uid, gid=gid, home=home, shell=shell,
                enabled="nologin" not in shell and "false" not in shell,
                note=note,
            ))
        return out
