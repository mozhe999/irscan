"""检测器集合，每个检测器签名为 detect(ctx) -> list[Finding]。"""

from ..core.engine import ScanContext
from ..core.models import Finding
from . import (bruteforce, filesystem, heuristics, integrity, ioc, lateral,
               timeline, weblog, webshell)

DETECTORS = [
    integrity.detect,
    ioc.detect,
    bruteforce.detect,
    lateral.detect,
    weblog.detect,
    webshell.detect,
    filesystem.detect,
    heuristics.detect,
]

TIMELINE_BUILDERS = [timeline.build]

TIMELINE_SUMMARIZERS = [timeline.summarize]

__all__ = [
    "DETECTORS",
    "TIMELINE_BUILDERS",
    "TIMELINE_SUMMARIZERS",
    "bruteforce",
    "filesystem",
    "heuristics",
    "integrity",
    "ioc",
    "lateral",
    "timeline",
    "weblog",
    "webshell",
]
