"""横向移动线索：基于 Windows 4624 的登录类型判定。"""

from __future__ import annotations

from collections import defaultdict

from ..core.engine import AuthEvent, ScanContext
from ..core.models import Finding, Severity
from ..core.utils import is_public_ip

SUSPICIOUS_PROCESSES = ("psexesvc", "winexesvc", "paexec", "remcomsvc")


def detect(ctx: ScanContext) -> list[Finding]:
    findings: list[Finding] = []
    findings.extend(_network_logon_spread(ctx))
    findings.extend(_remote_interactive(ctx))
    findings.extend(_psexec_like(ctx))
    return findings


def _network_logon_spread(ctx: ScanContext) -> list[Finding]:
    """同一账号从多台不同主机发起网络登录。"""
    by_user: dict[str, list[AuthEvent]] = defaultdict(list)
    for ev in ctx.auth_events:
        if ev.success and ev.logon_type == "3" and ev.username and ev.source_ip:
            by_user[ev.username].append(ev)

    out: list[Finding] = []
    for user, events in by_user.items():
        ips = sorted({e.source_ip for e in events})
        if len(ips) < ctx.config.lateral_host_threshold:
            continue
        events.sort(key=lambda e: e.timestamp or e.occurred_at or e.timestamp)
        f = Finding(
            title=f"账号 {user} 从 {len(ips)} 台主机发起网络登录（疑似横向移动）",
            severity=Severity.HIGH,
            category="横向移动",
            description=(
                f"账号 {user} 通过 LogonType=3（网络登录）从 {len(ips)} 个不同源地址"
                f"成功登录本机，共 {len(events)} 次。"
                f"网络登录不是交互式操作，正常运维账号很少同时从这么多主机发起，"
                f"典型场景是攻击者在内网横向扩散或用脚本批量分发。"
            ),
            recommendation=(
                f"1) 确认该账号是否为运维/备份/监控类服务账号，是否有合理理由；"
                f"2) 逐个核查来源主机 {'、'.join(ips[:8])} 是否已被控制；"
                f"3) 检查本机共享目录、计划任务、服务是否被新增或修改；"
                f"4) 若确认异常，重置该账号口令并限制其登录的主机范围。"
            ),
            subjects=[user] + ips[:12],
            source="Windows 安全日志 4624 (LogonType=3)",
            occurred_at=events[0].timestamp,
            confidence="中",
            technique="T1021.002",
            tactic="横向移动",
        )
        for ip in ips[:12]:
            cnt = sum(1 for e in events if e.source_ip == ip)
            f.add_evidence(f"{ip}：网络登录成功 {cnt} 次")
        out.append(f)
    return out


def _remote_interactive(ctx: ScanContext) -> list[Finding]:
    """RDP 登录来源为公网地址，属于高危暴露面。"""
    by_user: dict[str, list[AuthEvent]] = defaultdict(list)
    for ev in ctx.auth_events:
        if ev.success and ev.logon_type == "10" and ev.username and is_public_ip(ev.source_ip):
            by_user[ev.username].append(ev)

    out: list[Finding] = []
    for user, events in by_user.items():
        ips = sorted({e.source_ip for e in events})
        f = Finding(
            title=f"账号 {user} 从公网 IP 通过远程桌面登录",
            severity=Severity.MEDIUM,
            category="暴露面",
            description=(
                f"账号 {user} 通过 RDP（LogonType=10）从公网地址 "
                f"{'、'.join(ips[:5])} 登录成功。远程桌面直接暴露在公网上，"
                f"会持续承受爆破与漏洞利用（如 BlueKeep、CVE-2019-0708）压力。"
            ),
            recommendation=(
                f"1) 确认是否业务必需；若非必需，关闭公网 3389 或改用 VPN 接入；"
                f"2) 开启网络级别身份验证（NLA）与账户锁定策略；"
                f"3) 限制可 RDP 登录的账号白名单。"
            ),
            subjects=[user] + ips[:8],
            source="Windows 安全日志 4624 (LogonType=10)",
            occurred_at=events[0].timestamp,
            confidence="高",
            technique="T1133",
            tactic="初始访问",
        )
        for ip in ips[:8]:
            cnt = sum(1 for e in events if e.source_ip == ip)
            f.add_evidence(f"{ip}：RDP 登录成功 {cnt} 次")
        out.append(f)
    return out


def _psexec_like(ctx: ScanContext) -> list[Finding]:
    """PsExec 类登录，运维与攻击行为难以区分，只报中危待确认。"""
    hits = [
        ev for ev in ctx.auth_events
        if ev.success
        and ev.logon_type == "3"
        and any(p in (ev.auth_type or "").lower() or p in (ev.raw or "").lower()
                for p in SUSPICIOUS_PROCESSES)
    ]
    if not hits:
        return []
    ips = sorted({e.source_ip for e in hits if e.source_ip})
    f = Finding(
        title="检测到 PsExec 类远程执行工具登录",
        severity=Severity.MEDIUM,
        category="横向移动",
        description=(
            f"安全日志中出现 {len(hits)} 次带有 PsExec/PAExec 类特征的远程登录，"
            f"来源：{'、'.join(ips[:5])}。"
            f"这类工具运维也会用，但同样是内网横向移动最常见的载体，需要人工确认归属。"
        ),
        recommendation=(
            "1) 与运维确认是否有对应的批量运维操作窗口；"
            "2) 若无法归属到具体工单，按入侵处理，排查来源主机；"
            "3) 建议在 EDR 中对 psexesvc 服务创建行为做告警。"
        ),
        subjects=ips[:10],
        source="Windows 安全日志 4624",
        occurred_at=hits[0].timestamp,
        confidence="低",
        technique="T1021.006",
        tactic="横向移动",
    )
    for e in hits[:10]:
        f.add_evidence(e.raw)
    return [f]
