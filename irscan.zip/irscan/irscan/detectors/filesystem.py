"""文件系统专项检测：ld.so.preload、WMI 订阅、authorized_keys、SUID、服务路径。"""

from __future__ import annotations

import os
import re

from ..core.engine import ScanContext
from ..core.models import Finding, Severity

KNOWN_SUID = {
    "su", "sudo", "passwd", "chsh", "chfn", "gpasswd", "newgrp", "mount",
    "umount", "ping", "ping6", "traceroute", "mtr", "at", "crontab",
    "pkexec", "dbus-daemon-launch-helper", "unix_chkpwd", "unix2_chkpwd",
    "ssh-keysign", "ntfs-3g", "fusermount", "Xorg", "chrome-sandbox",
}

SUSPICIOUS_SUID_DIRS = ("/tmp", "/dev/shm", "/var/tmp", "/home", "/root")

DEFAULT_HOSTS = {"localhost", "ip6-localhost", "ip6-loopback", "broadcasthost"}


def detect(ctx: ScanContext) -> list[Finding]:
    out: list[Finding] = []
    out.extend(_ld_preload(ctx))
    out.extend(_wmi_subscription(ctx))
    out.extend(_authorized_keys(ctx))
    out.extend(_suid_anomalies(ctx))
    out.extend(_service_anomalies(ctx))
    out.extend(_hosts_tamper(ctx))
    return out


def _ld_preload(ctx: ScanContext) -> list[Finding]:
    """ld.so.preload 非空：注入所有动态链接进程，重启后仍生效。"""
    out: list[Finding] = []
    for f in ctx.snapshot.files:
        if f.kind != "ld_preload" or not f.content:
            continue
        f_finding = Finding(
            title=f"发现 LD_PRELOAD 后门：{f.path}",
            severity=Severity.CRITICAL,
            category="持久化/后门",
            description=(
                f"{f.path} 内容为：{f.content[:300]}。"
                f"该文件指定的共享库会被加载到系统中几乎所有动态链接的进程里，"
                f"攻击者可借此劫持任意函数、隐藏进程与网络连接。"
                f"这是 rootkit 级别的持久化，重启后依然生效，"
                f"且常规排查（ps/netstat/ls）都会被它欺骗。"
            ),
            recommendation=(
                f"1) **不要直接删除**，先保存该文件与它指向的 SO 作为取证材料；"
                f"2) 检查指向的 SO 文件来源与哈希，送威胁情报查询；"
                f"3) 由于本机命令行输出可能已被劫持，建议从 Live CD 或离线环境复核；"
                f"4) 高度怀疑时按主机失陷处理，考虑重建。"
            ),
            subjects=[f.path] + f.content.split()[:3],
            source="文件系统",
            occurred_at=None,
            confidence="高",
            technique="T1574",
            tactic="持久化 / 防御规避",
        )
        f_finding.add_evidence(f"文件内容: {f.content[:300]}")
        f_finding.add_evidence(f"修改时间: {f.modified_at or '未知'}")
        out.append(f_finding)
    return out


def _wmi_subscription(ctx: ScanContext) -> list[Finding]:
    """WMI 永久事件订阅，无文件落地的持久化方式。"""
    consumers = [w for w in ctx.snapshot.wmi if w.kind == "Consumer"]
    filters = [w for w in ctx.snapshot.wmi if w.kind == "Filter"]
    if not consumers:
        return []

    out: list[Finding] = []
    for c in consumers:
        f = Finding(
            title=f"发现 WMI 事件订阅持久化：{c.name}",
            severity=Severity.HIGH,
            category="持久化",
            description=(
                f"WMI 仓库中存在 CommandLineEventConsumer「{c.name}」，"
                f"将在其绑定的事件触发时执行：{c.command[:200]}。"
                f"这种持久化不写注册表 Run、不建计划任务、不建服务，"
                f"只存在于 WMI 仓库中，任务管理器和 msconfig 都看不到它，"
                f"是 Windows 上最容易被漏掉的持久化手法之一。"
            ),
            recommendation=(
                f"1) 确认该订阅是否为运维/监控软件创建；"
                f"2) 无法归属则删除订阅："
                f"Get-CimInstance -Namespace root/subscription -ClassName "
                f"CommandLineEventConsumer -Filter \"Name='{c.name}'\" | Remove-CimInstance；"
                f"3) 同时删除对应的 __EventFilter 与 __FilterToConsumerBinding，只删一部分无效；"
                f"4) 排查是谁创建了该订阅（查 WMI 操作日志与 4624 登录记录）。"
            ),
            subjects=[c.name],
            source="WMI root/subscription",
            confidence="中",
            technique="T1546.003",
            tactic="持久化",
        )
        f.add_evidence(f"执行命令: {c.command[:300]}")
        for flt in filters[:3]:
            f.add_evidence(f"关联过滤器 {flt.name}: {flt.query[:150]}")
        out.append(f)
    return out


def _authorized_keys(ctx: ScanContext) -> list[Finding]:
    """authorized_keys：加一条公钥即可免密长期驻留。"""
    out: list[Finding] = []
    for f in ctx.snapshot.files:
        if f.kind != "authorized_keys":
            continue
        out.append(Finding(
            title=f"SSH 免密登录公钥文件：{f.path}",
            severity=Severity.LOW,
            category="持久化",
            description=(
                f"{f.note}，{f.content}。"
                f"攻击者在拿到权限后常往这里追加自己的公钥，即可绕过口令长期驻留，"
                f"且不产生任何进程或日志。请逐条核对公钥归属。"
            ),
            recommendation=(
                f"1) 逐个核对公钥是否为可信人员所有，不认识的立即删除；"
                f"2) 检查文件修改时间 {f.modified_at or '未知'} 前后是否有异常登录；"
                f"3) 建议改用证书认证或限制 authorized_keys 的写入权限。"
            ),
            subjects=[f.path],
            source="文件系统",
            confidence="中",
            technique="T1098",
            tactic="持久化",
        ))
    return out


def _suid_anomalies(ctx: ScanContext) -> list[Finding]:
    """非白名单 SUID 程序 / 位于临时目录的 SUID 文件。"""
    out: list[Finding] = []
    for f in ctx.snapshot.files:
        if f.kind not in ("suid", "sgid"):
            continue
        name = os.path.basename(f.path)
        in_temp = f.path.startswith(SUSPICIOUS_SUID_DIRS)
        if name in KNOWN_SUID and not in_temp:
            continue

        severity = Severity.CRITICAL if in_temp else Severity.HIGH
        reason = ("该 SUID 文件位于临时/用户可写目录，正常系统不会在这里放 SUID 程序，"
                  "这几乎可以断定是攻击者为提权放置的"
                  if in_temp else
                  f"程序 {name} 不在常见 SUID 白名单内，具备以属主权限执行的能力，"
                  f"若为提权辅助程序（如 bash/cp/nmap/vim/find）则危害极大")

        fnd = Finding(
            title=f"异常 {f.kind.upper()} 文件：{f.path}",
            severity=severity,
            category="权限提升",
            description=(
                f"{reason}。属主 {f.owner}，权限 {f.mode}，"
                f"修改时间 {f.modified_at or '未知'}。"
                f"SUID 程序在执行时以文件属主（通常是 root）身份运行，"
                f"是本地提权最经典的跳板。"
            ),
            recommendation=(
                f"1) 确认该程序是否为业务必需；"
                f"2) 非必需则移除 SUID 位：chmod a-s {f.path}；"
                f"3) 对其进行哈希与威胁情报查询，确认是否为已知提权工具；"
                f"4) 检查该文件修改时间前后的登录与命令历史。"
            ),
            subjects=[f.path],
            source="文件系统",
            confidence="高" if in_temp else "中",
            technique="T1547.008",
            tactic="权限提升",
        )
        fnd.add_evidence(f"{f.mode} {f.owner} {f.size}B  mtime={f.modified_at}")
        out.append(fnd)
    return out

SERVICE_RISK = {
    "missing_binary": (
        Severity.MEDIUM, "服务指向的可执行文件已不存在",
        "服务注册了可执行路径但该文件在磁盘上不存在。"
        "最常见的原因是软件卸载后残留了服务注册项；"
        "另一种可能是攻击者替换服务二进制后删除了原始文件；"
        "若该服务当前仍处于运行状态，则属于强入侵信号，需立即核查。",
        "先看服务当前状态：未运行多为卸载残留，清理即可；"
        "仍在运行则说明实际加载的不是注册路径上的文件，应立即排查并保留证据。",
        "T1036", "防御规避",
    ),
    "user_writable": (
        Severity.HIGH, "服务二进制位于用户可写目录",
        "该服务的可执行文件放在普通用户就有写权限的目录下。"
        "这意味着无需管理员权限即可替换服务二进制，"
        "服务若以 SYSTEM 运行则等同于一条现成的提权链。",
        "确认该服务是否必须运行在用户目录；是则迁移到 Program Files，"
        "并核查二进制的数字签名与文件修改时间。",
        "T1574.010", "权限提升",
    ),
    "unquoted_space": (
        Severity.LOW, "服务路径未加引号且含空格",
        "Windows 解析未加引号的服务路径时会按空格分段依次猜测，"
        "攻击者只要在更早被猜到的目录放入同名可执行文件即可劫持服务执行。"
        "这是经典的提权手法，本身不是入侵迹象，但属于应修复的配置缺陷。",
        "在注册表 ImagePath 中为路径补上英文双引号，或迁移到不含空格的目录。",
        "T1574.009", "权限提升",
    ),
}


def _service_anomalies(ctx: ScanContext) -> list[Finding]:
    """服务路径风险分级。第三方服务不单独出结论，只报可利用缺陷。"""
    out: list[Finding] = []
    for s in ctx.snapshot.services:
        spec = SERVICE_RISK.get(s.risk)
        if not spec:
            continue
        sev, title, desc, rec, tech, tactic = spec

        if s.risk == "missing_binary" and s.state.lower() == "running":
            sev = Severity.HIGH
        f = Finding(
            title=f"{title}：{s.name}",
            severity=sev,
            category="持久化 / 配置缺陷",
            description=(
                f"服务 {s.name}（{s.display_name}）的可执行路径为 {s.path}。"
                f"状态 {s.state}，启动类型 {s.start_mode}，运行账户 {s.user}。"
                f"{desc}"
            ),
            recommendation=rec,
            subjects=[s.name, s.path],
            source="服务列表",
            confidence="中",
            technique=tech,
            tactic=tactic,
        )
        f.add_evidence(f"路径: {s.path}")
        f.add_evidence(f"状态: {s.state} 启动类型: {s.start_mode} 账户: {s.user}")
        out.append(f)
    return out


def _hosts_tamper(ctx: ScanContext) -> list[Finding]:
    """/etc/hosts 或 Windows hosts 被加入异常解析记录。"""
    out: list[Finding] = []
    for f in ctx.snapshot.files:
        if f.kind != "hosts" or not f.content:
            continue
        entries = [e for e in f.content.splitlines() if e.strip()]
        suspicious = []
        for e in entries:
            parts = e.split()
            if len(parts) < 2:
                continue
            _ip, host = parts[0], parts[1]

            if re.search(r"(update|download|cdn|api|auth|login|sso|pay|bank)", host, re.I):
                if host.lower() not in DEFAULT_HOSTS:
                    suspicious.append(e)
        if not suspicious:
            continue
        out.append(Finding(
            title=f"hosts 文件存在可疑解析记录：{f.path}",
            severity=Severity.MEDIUM,
            category="防御规避",
            description=(
                f"hosts 文件中发现 {len(suspicious)} 条指向非正常地址的"
                f"关键业务域名解析记录，可用于把更新/登录流量劫持到攻击者控制的服务器，"
                f"进而投递恶意更新或窃取凭据：{'；'.join(suspicious[:5])}"
            ),
            recommendation=(
                f"1) 逐条确认这些记录是否为企业内部配置；"
                f"2) 非预期则删除并排查是谁修改的（查文件修改时间与当时的登录记录）；"
                f"3) 若存在指向外部 IP 的更新域名，需排查该时段是否下载过恶意程序。"
            ),
            subjects=suspicious[:8],
            source="hosts 文件",
            confidence="中",
            technique="T1565",
            tactic="防御规避",
        ))
    return out
