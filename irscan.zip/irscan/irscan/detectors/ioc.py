"""IOC 比对：哈希命中判严重，文件名与内容正则判高危。"""

from __future__ import annotations

import os
import time

from ..core.ioc import IOCSet, load_ioc_file
from ..core.models import Finding, Severity

MAX_FILES = 5000
MAX_WEBROOT_FILES = 2000

_CACHE: dict[tuple, IOCSet] = {}


def _load_cached(path: str) -> IOCSet:
    """按 (路径, 修改时间) 缓存解析结果。"""
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return IOCSet()
    key = (path, mtime)
    if key not in _CACHE:
        _CACHE[key] = load_ioc_file(path)
    return _CACHE[key]


def _candidate_paths(ctx) -> tuple[list[str], list[str]]:
    """收集值得比对的文件路径，返回 (路径列表, 超限说明)。"""
    seen: set[str] = set()
    paths: list[str] = []
    notes: list[str] = []

    def add(p: str) -> None:
        if not p or p in seen or not os.path.isfile(p):
            return
        seen.add(p)
        paths.append(p)

    for f in ctx.snapshot.files:
        add(f.path)

    for s in ctx.snapshot.services:
        add(s.path.split(" ")[0].strip('"'))

    for root in ctx.config.webroots:
        if not os.path.isdir(root):
            continue
        count = 0
        for dirpath, _dirs, files in os.walk(root):
            for name in files:
                if count >= MAX_WEBROOT_FILES:
                    notes.append(
                        f"站点目录 {root} 文件数超过 {MAX_WEBROOT_FILES}，"
                        f"IOC 比对只覆盖了前 {MAX_WEBROOT_FILES} 个")
                    break
                add(os.path.join(dirpath, name))
                count += 1
            if count >= MAX_WEBROOT_FILES:
                break

    if len(paths) > MAX_FILES:
        notes.append(
            f"待比对文件 {len(paths)} 个，超过上限 {MAX_FILES}，本次只比对前 {MAX_FILES} 个")
        return paths[:MAX_FILES], notes
    return paths, notes


def detect(ctx) -> list[Finding]:
    ioc_files = list(getattr(ctx.config, "ioc_files", None) or [])
    if not ioc_files:
        return []

    ioset = IOCSet()
    for path in ioc_files:
        part = _load_cached(path)
        if not len(part):
            ctx.note_error(f"IOC 情报文件无法读取或未包含有效条目: {path}")
            continue
        ioset.merge(part)
        for err in part.errors:
            ctx.note_error(f"IOC 加载：{err}")

    if not len(ioset):
        return []

    started = time.time()
    paths, notes = _candidate_paths(ctx)
    for note in notes:
        ctx.note_error(note)

    from ..core.ioc import MAX_TEXT_BYTES, file_hashes
    from ..core.utils import read_text

    hits: list[Finding] = []
    unreadable = 0
    for path in paths:
        name = os.path.basename(path)

        for ioc in ioset.filenames:
            rx = ioc.regex
            if rx and rx.search(name):
                hits.append(Finding(
                    title=f"文件名命中情报：{name}",
                    severity=Severity.HIGH,
                    category="已知恶意文件",
                    description=(
                        f"文件名匹配情报条目「{ioc.description or ioc.value}」。"
                        f"文件名比哈希容易改，需结合文件内容与来源判断。"
                    ),
                    recommendation=(
                        "1) 确认该文件是否为业务文件；"
                        "2) 计算哈希到情报平台二次确认；"
                        "3) 排查文件的落地时间与创建者。"
                    ),
                    evidence=[f"路径: {path}", f"匹配规则: {ioc.value}"],
                    subjects=[path],
                    source="文件名 IOC",
                    confidence="中",
                    technique="T1204.002",
                    tactic="执行",
                ))

        digest = file_hashes(path)
        if digest is None:
            unreadable += 1
            continue
        md5, sha1, sha256 = digest
        note = ioset.hashes.get(sha256) or ioset.hashes.get(sha1) or ioset.hashes.get(md5)
        if note:
            hits.append(Finding(
                title=f"哈希命中已知恶意样本：{name}",
                severity=Severity.CRITICAL,
                category="已知恶意文件",
                description=(
                    f"文件 {path} 的 SHA256 为 {sha256}，命中情报条目「{note}」。"
                    f"文件在磁盘上存在本身即构成失陷证据。"
                ),
                recommendation=(
                    "1) 立即隔离该文件并保留副本作为取证材料，不要直接删除；"
                    "2) 排查来源（谁上传的、哪个进程创建的、落地时间）；"
                    "3) 按主机失陷处理，排查同时间段的登录与进程创建记录。"
                ),
                evidence=[f"路径: {path}", f"SHA256: {sha256}", f"MD5: {md5}",
                          f"情报标注: {note}"],
                subjects=[path, sha256],
                source=f"哈希 IOC（{len(ioset.hashes)} 条）",
                confidence="高",
                technique="T1204.002",
                tactic="执行",
            ))

        if ioset.content:
            try:
                size = os.path.getsize(path)
            except OSError:
                continue
            if size > MAX_TEXT_BYTES:
                continue
            try:
                text = read_text(path)
            except OSError:
                continue
            for ioc in ioset.content:
                rx = ioc.regex
                if not rx:
                    continue
                m = rx.search(text)
                if not m:
                    continue
                hits.append(Finding(
                    title=f"文件内容命中情报：{name}",
                    severity=Severity.HIGH,
                    category="已知恶意文件",
                    description=(
                        f"文件内容匹配情报正则「{ioc.description or ioc.value}」，"
                        f"命中片段：{m.group(0)[:120]}"
                    ),
                    recommendation=(
                        "1) 打开该文件确认是否为业务代码；"
                        "2) 计算哈希到情报平台二次确认；"
                        "3) 排查文件的落地时间与上传入口。"
                    ),
                    evidence=[f"路径: {path}", f"匹配规则: {ioc.value}",
                              f"片段: {m.group(0)[:200]}"],
                    subjects=[path],
                    source="内容 IOC",
                    confidence="中",
                    technique="T1204.002",
                    tactic="执行",
                ))

    if unreadable:
        ctx.note_error(
            f"{unreadable} 个文件因过大或无权限未能计算哈希，未参与 IOC 比对")

    if hits:
        ctx.snapshot.extra.setdefault("ioc_scanned", []).append(
            f"{len(paths)} 个文件 / {time.time() - started:.1f}s")
    return hits
