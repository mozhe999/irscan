"""攻击时间线：把带时间戳的素材聚合成段并排序。"""

from __future__ import annotations

import os
import re
from datetime import datetime

from ..core.engine import ScanContext
from ..core.models import Finding, Severity, TimelineEvent
from ..core.utils import parse_clf_time
from ..parsers.logs import parse_clf_line

STAGE_PATTERNS: list[tuple[str, str, Severity]] = [
    (r"union(?:\s|%20|%09|\+)+select|sleep\s*\(|information_schema", "SQL 注入探测", Severity.HIGH),
    (r"cmd=|exec=|command=", "尝试命令执行", Severity.HIGH),
    (r"\.\./", "路径穿越尝试", Severity.MEDIUM),
    (r"/\.env|/\.git|wp-config|\.bak|\.sql", "探测敏感文件/备份", Severity.MEDIUM),
    (r"upload|/uploads/", "文件上传行为", Severity.MEDIUM),
]

TOOL_UA = re.compile(r"sqlmap|nmap|nikto|masscan|acunetix|nessus|wpscan|awvs|havij", re.I)

_C_STAGES = [(re.compile(p, re.I), stage, sev) for p, stage, sev in STAGE_PATTERNS]

_STAGE_CACHE: dict[str, tuple[str, Severity]] = {}
_STAGE_CACHE_LIMIT = 50000


def _stage_of(uri: str) -> tuple[str, Severity] | None:
    """返回该 URI 对应的攻击阶段；不属于攻击行为则返回 None。"""
    cached = _STAGE_CACHE.get(uri)
    if cached is not None:
        stage, sev = cached
        return (stage, sev) if stage else None
    result = ("", Severity.INFO)
    for rx, stage, sev in _C_STAGES:
        if rx.search(uri):
            result = (stage, sev)
            break
    if len(_STAGE_CACHE) >= _STAGE_CACHE_LIMIT:
        _STAGE_CACHE.clear()
    _STAGE_CACHE[uri] = result
    return (result[0], result[1]) if result[0] else None


def build(ctx: ScanContext) -> list[TimelineEvent]:
    """从上下文里的各种素材重建时间线。"""
    events: list[TimelineEvent] = []

    events.extend(_auth_events(ctx))
    events.extend(_web_events(ctx))
    events.extend(_file_events(ctx))
    events.extend(_process_events(ctx))

    seen: set[tuple[str, str]] = set()
    unique: list[TimelineEvent] = []
    for e in sorted(events, key=lambda x: x.timestamp):
        key = (e.timestamp.isoformat(timespec="seconds"), e.label)
        if key in seen:
            continue
        seen.add(key)
        unique.append(e)
    return _collapse(unique)


def _auth_events(ctx: ScanContext) -> list[TimelineEvent]:
    """登录事件按时间连续段聚类。"""
    groups: dict[tuple[str, bool], list] = {}
    for ev in ctx.auth_events:
        if ev.timestamp is None:
            continue
        groups.setdefault((ev.source_ip, ev.success), []).append(ev)

    failed_ips = {ip for (ip, ok) in groups if not ok}
    failed_before: dict[str, datetime] = {}
    for (ip, ok), items in groups.items():
        if not ok:
            last_fail = max(e.timestamp for e in items if e.timestamp)
            failed_before[ip] = max(failed_before.get(ip, last_fail), last_fail)

    out: list[TimelineEvent] = []
    for (ip, success), items in groups.items():
        items.sort(key=lambda e: e.timestamp)
        for span in _spans(items, gap_seconds=180):
            first, last = span[0], span[-1]
            users = sorted({e.username for e in span if e.username})
            count = len(span)

            if success:
                label = f"登录成功：{first.username or '未知'}@{ip}"
                if first.logon_type == "3":
                    label += "（网络登录）"

                prior_fail = failed_before.get(ip)
                if ip in failed_ips and prior_fail and first.timestamp >= prior_fail:
                    severity = Severity.CRITICAL
                    label += "（此前有失败记录，疑为爆破成功，攻击链闭合点）"
                elif first.logon_type == "3":
                    severity = Severity.CRITICAL
                else:
                    severity = Severity.MEDIUM
            elif count >= ctx.config.fail_threshold:
                label = f"登录失败 ×{count}：{ip}（疑似爆破）"
                severity = Severity.HIGH
            else:
                label = f"登录失败 ×{count}：{ip}"
                severity = Severity.LOW

            if count > 1:
                window = f"{first.timestamp.strftime('%H:%M:%S')} ~ {last.timestamp.strftime('%H:%M:%S')}"
                detail = f"{window}；涉及账号 {', '.join(users[:6]) or '未知'}"
            else:
                detail = first.raw[:180]

            out.append(TimelineEvent(
                timestamp=first.timestamp,
                label=label,
                detail=detail,
                severity=severity,
                source="auth 日志 / 4625" if not success else "auth 日志 / 4624",
            ))
    return out


def _web_events(ctx: ScanContext) -> list[TimelineEvent]:
    """Web 攻击请求按「同 IP + 同类型 + 时间连续」聚类。"""
    groups: dict[tuple[str, str], list[tuple[datetime, str, str]]] = {}
    for line in ctx.weblog_lines:

        rec = parse_clf_line(line, want_ts=False, want_ua=False)
        if rec is None:
            continue
        uri, status, ip = rec["uri"], rec["status"], rec["ip"]

        label = ""
        severity = Severity.INFO
        stage = _stage_of(uri)
        if stage:
            label, severity = stage
        elif TOOL_UA.search(line):
            label, severity = "扫描器活动", Severity.MEDIUM
        if not label:
            continue

        ts = parse_clf_time(rec["time"])
        if ts is None:
            continue
        if status == "200" and severity == Severity.MEDIUM:
            severity = Severity.HIGH
        groups.setdefault((ip, label), []).append((ts, uri, status))

    out: list[TimelineEvent] = []
    for (ip, label), items in groups.items():
        items.sort(key=lambda x: x[0])
        for span in _spans(items, gap_seconds=120):
            first, last = span[0], span[-1]
            count = len(span)
            severity = max((_stage_severity(label), Severity.MEDIUM))
            if count >= 3:
                severity = Severity(max(Severity.HIGH, severity))
            if count > 1:
                window = f"{first[0].strftime('%H:%M:%S')} ~ {last[0].strftime('%H:%M:%S')}"
                out.append(TimelineEvent(
                    timestamp=first[0],
                    label=f"{label} ×{count}（{ip}）",
                    detail=f"{window}；样例 {first[1][:120]} -> {first[2]}",
                    severity=severity,
                    source="Web 访问日志",
                ))
            else:
                out.append(TimelineEvent(
                    timestamp=first[0],
                    label=f"{label}（{ip}）",
                    detail=f"{first[1][:160]} -> {first[2]}",
                    severity=severity,
                    source="Web 访问日志",
                ))
    return out


def _stage_severity(label: str) -> Severity:
    for _pattern, stage, sev in STAGE_PATTERNS:
        if stage == label:
            return sev
    return Severity.MEDIUM


def _spans(items: list, gap_seconds: int) -> list[list]:
    """把按时间排序的同类事件切成若干"连续段"：相邻间隔超过 gap 就断开。"""
    spans: list[list] = []
    cur: list = []

    def ts_of(x) -> datetime:

        return getattr(x, "timestamp", None) or x[0]

    for item in items:
        if cur and (ts_of(item) - ts_of(cur[-1])).total_seconds() > gap_seconds:
            spans.append(cur)
            cur = []
        cur.append(item)
    if cur:
        spans.append(cur)
    return spans


def _file_events(ctx: ScanContext) -> list[TimelineEvent]:
    """文件 mtime 事件。"""
    out: list[TimelineEvent] = []
    interesting = {"suid", "sgid", "ld_preload", "authorized_keys", "startup_folder"}
    for f in ctx.snapshot.files:
        if f.kind not in interesting or not f.modified_at:
            continue
        try:
            ts = datetime.strptime(f.modified_at, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
        sev = Severity.HIGH if f.kind in ("ld_preload", "authorized_keys") else Severity.MEDIUM
        out.append(TimelineEvent(
            timestamp=ts,
            label=f"关键文件变更：{os.path.basename(f.path)}（{f.kind}）",
            detail=f"{f.path}  属主 {f.owner}  权限 {f.mode}",
            severity=sev,
            source="文件系统",
        ))
    return out


def _process_events(ctx: ScanContext) -> list[TimelineEvent]:
    """返回可疑进程的启动时间。"""
    out: list[TimelineEvent] = []
    for p in ctx.snapshot.processes:
        if not p.started_at:
            continue
        try:
            ts = datetime.strptime(p.started_at, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
        out.append(TimelineEvent(
            timestamp=ts,
            label=f"进程启动：{p.name} (PID {p.pid})",
            detail=p.cmdline[:160],
            severity=Severity.INFO,
            source="进程快照",
        ))
    return out


def _collapse(events: list[TimelineEvent], max_keep: int = 60) -> list[TimelineEvent]:
    """时间线过长时等距抽样裁剪。"""
    if len(events) <= max_keep:
        return events
    events = sorted(events, key=lambda e: e.timestamp)
    step = len(events) / max_keep
    picked = [events[int(i * step)] for i in range(max_keep)]
    if events[-1] not in picked:
        picked[-1] = events[-1]
    return picked


def summarize(timeline: list[TimelineEvent]) -> list[Finding]:
    """把时间线归纳成一条结论。"""
    if not timeline:
        return []

    high = [e for e in timeline if e.severity >= Severity.HIGH]
    if not high:
        return []

    if not any(e.source != "文件系统" for e in high):
        return []

    first, last = timeline[0].timestamp, timeline[-1].timestamp
    span_min = max((last - first).total_seconds() / 60, 0)

    lines = []
    for e in high[:12]:
        lines.append(f"{e.timestamp.strftime('%m-%d %H:%M:%S')}  {e.label}")

    return [Finding(
        title=f"攻击时间线重建：{first.strftime('%m-%d %H:%M')} ~ "
              f"{last.strftime('%m-%d %H:%M')}（跨度 {span_min:.0f} 分钟）",
        severity=Severity.HIGH if high else Severity.INFO,
        category="时间线",
        description=(
            f"共还原 {len(timeline)} 个时间点，其中 {len(high)} 个为高危及以上动作。"
            f"攻击活动从 {first.strftime('%Y-%m-%d %H:%M:%S')} 持续到 "
            f"{last.strftime('%Y-%m-%d %H:%M:%S')}。"
            f"完整时间线见报告「攻击时间线」章节，可用于还原攻击者的操作顺序与停留时长。"
        ),
        recommendation=(
            "1) 以时间线为轴，逐段核对监控与告警是否存在对应记录；"
            "2) 以「首次成功登录」为分界点，排查之后所有文件与账号变更；"
            "3) 时间线之外的时间段若日志缺失，需确认是否被攻击者清理。"
        ),
        subjects=[e.label for e in high[:8]],
        source="时间线重建",
        occurred_at=first,
        confidence="中",
        technique="T1078",
        tactic="防御规避 / 凭据访问",
    )]


def render_text(timeline: list[TimelineEvent], limit: int = 40) -> str:
    """命令行用的纯文本时间线。"""
    if not timeline:
        return "  （无时间线数据）"
    lines = []
    for e in timeline[:limit]:
        lines.append(
            f"  {e.timestamp.strftime('%m-%d %H:%M:%S')}  "
            f"[{e.severity.label}] {e.label}"
        )
        if e.detail:
            lines.append(f"                     └ {e.detail[:110]}")
    if len(timeline) > limit:
        lines.append(f"  ... 其余 {len(timeline) - limit} 条见 HTML 报告")
    return "\n".join(lines)
