"""Web 访问日志：按来源 IP 聚合行为画像。"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..core.engine import ScanContext
from ..core.models import Finding, Severity
from ..core.utils import is_public_ip
from ..parsers.logs import parse_clf_line

_S1 = r"(?:\s|%20|%09|\+|/\*[^*]*\*/)+"
_S0 = r"(?:\s|%20|%09|\+|/\*[^*]*\*/)*"

SQLI_PATTERNS = [
    (rf"union{_S1}select", "UNION SELECT 注入"),
    (rf"(?:%27|'){_S0}(?:or|and){_S1}\d+{_S0}={_S0}\d+", "布尔型注入"),
    (rf"\b(?:sleep|benchmark|pg_sleep|waitfor\s+delay){_S0}\(", "时间盲注"),
    (r"information_schema", "探测 information_schema"),
    (r"\bxp_cmdshell\b", "MSSQL 命令执行"),
    (rf"load_file{_S0}\(", "MySQL 文件读取"),
    (rf"into{_S1}outfile", "MySQL 文件写入"),
    (rf"extractvalue{_S0}\(|updatexml{_S0}\(", "报错注入"),
]

RCE_PATTERNS = [
    (r"/cgi-bin/", "访问 CGI 目录"),
    (r"(?:\?|&)(?:cmd|exec|command|shell)=[^&]{3,}", "URL 参数疑似传命令"),
    (rf";{_S0}(?:cat|ls|whoami|id|wget|curl)\s", "命令拼接"),
    (rf"\|{_S0}(?:sh|bash|cmd)\b", "管道执行"),
]

TRAVERSAL_PATTERNS = [
    (r"(?:\.\./|\.\.%2f|\.\.\\|%2e%2e%2f){2,}", "路径穿越"),
]

SCANNER_UA = [
    (r"sqlmap", "sqlmap"),
    (r"nmap scripting engine|nmap\b", "nmap"),
    (r"nikto", "nikto"),
    (r"masscan", "masscan"),
    (r"(?:awvs|acunetix)", "AWVS"),
    (r"nessus", "Nessus"),
    (r"(?:dirbuster|gobuster|dirb\b)", "目录爆破器"),
    (r"wpscan", "WPScan"),
    (r"burp|zgrab|hydra|metasploit|havij|appscan", "其他扫描器"),
]

SENSITIVE_PATHS = [
    (r"/\.git/(?:config|HEAD)", ".git 目录泄露"),
    (r"/\.env\b", ".env 配置文件"),
    (r"/\.svn/", ".svn 目录泄露"),
    (r"wp-config\.php", "WordPress 配置文件"),
    (r"/(?:phpmyadmin|adminer|myadmin)/", "数据库管理后台"),
    (r"/actuator(?:/|$)", "Spring Boot Actuator"),
    (r"/(?:web|manage|admin)?\.?config\.(?:php|bak|old|xml|yml|yaml|json)", "配置文件/备份"),
    (r"\.(?:sql|bak|zip|tar|gz|rar|7z)\b", "备份或压缩包"),
    (r"/(?:shell|cmd|cmd\.jsp|ma\.php|c\.php|xiaoma\.php|admin\.php)\b", "常见后门文件名"),
    (r"/(?:_ignition|solr|druid|swagger-ui)\b", "已知组件管理端"),
]

MIN_404_FOR_SCAN = 50
MIN_ATTACK_HITS = 3


@dataclass
class IPProfile:
    ip: str
    requests: int = 0
    status404: int = 0
    hits: dict[str, int] = field(default_factory=dict)
    samples: list[str] = field(default_factory=list)
    uas: set[str] = field(default_factory=set)
    sensitive_200: list[str] = field(default_factory=list)
    first_seen: str = ""
    last_seen: str = ""

    def hit(self, label: str) -> None:
        self.hits[label] = self.hits.get(label, 0) + 1

    def sample(self, line: str) -> None:
        if len(self.samples) < 10:
            self.samples.append(line)


def _compile(patterns: list[tuple[str, str]]) -> list[tuple[re.Pattern[str], str]]:
    return [(re.compile(p, re.I), label) for p, label in patterns]

_C_SQLI = _compile(SQLI_PATTERNS)
_C_RCE = _compile(RCE_PATTERNS)
_C_TRAVERSAL = _compile(TRAVERSAL_PATTERNS)
_C_SENSITIVE = _compile(SENSITIVE_PATHS)
_C_UA = _compile(SCANNER_UA)
_RE_LEADING_TOKEN = re.compile(r"^(\S+)")

_URI_CACHE: dict[str, tuple[list[str], list[str]]] = {}
_UA_CACHE: dict[str, list[str]] = {}
CACHE_LIMIT = 50000


def _match_all(compiled: list[tuple[re.Pattern[str], str]], text: str) -> list[str]:
    return [label for rx, label in compiled if rx.search(text)]


def _scan_uri(uri: str) -> tuple[list[str], list[str]]:
    """返回 (全部命中标签, 其中属于敏感资源的标签)。结果按 uri 缓存。"""
    cached = _URI_CACHE.get(uri)
    if cached is not None:
        return cached
    labels = [f"SQL 注入：{x}" for x in _match_all(_C_SQLI, uri)]
    labels += [f"命令执行：{x}" for x in _match_all(_C_RCE, uri)]
    labels += [f"路径穿越：{x}" for x in _match_all(_C_TRAVERSAL, uri)]
    sensitive = _match_all(_C_SENSITIVE, uri)
    labels += [f"敏感资源探测：{x}" for x in sensitive]
    if len(_URI_CACHE) >= CACHE_LIMIT:
        _URI_CACHE.clear()
    result = (labels, sensitive)
    _URI_CACHE[uri] = result
    return result


def _scan_ua(ua: str) -> list[str]:
    cached = _UA_CACHE.get(ua)
    if cached is not None:
        return cached
    out = _match_all(_C_UA, ua)
    if len(_UA_CACHE) >= CACHE_LIMIT:
        _UA_CACHE.clear()
    _UA_CACHE[ua] = out
    return out


def detect(ctx: ScanContext) -> list[Finding]:
    if not ctx.weblog_lines:
        return []

    profiles: dict[str, IPProfile] = {}
    unparsed = 0

    for line in ctx.weblog_lines:
        if not line.strip():
            continue
        rec = parse_clf_line(line, want_ts=False)
        if rec is None:

            unparsed += 1
            m = _RE_LEADING_TOKEN.match(line)
            ip = m.group(1) if m else "unknown"
            profile = profiles.setdefault(ip, IPProfile(ip=ip))
            profile.requests += 1
            for label in _match_all(_C_SQLI, line):
                profile.hit(f"SQL 注入：{label}")
            profile.sample(line[:300])
            continue

        ip = rec["ip"]
        profile = profiles.setdefault(ip, IPProfile(ip=ip))
        profile.requests += 1
        if rec["status"] == "404":
            profile.status404 += 1

        target = rec["uri"]
        labels, sensitive = _scan_uri(target)
        if labels:
            for label in labels:
                profile.hit(label)
            if sensitive and rec["status"] == "200":
                for label in sensitive:
                    profile.sensitive_200.append(f"{label} -> {target} (200)")

        if rec["ua"]:
            profile.uas.add(rec["ua"][:80])
            for label in _scan_ua(rec["ua"]):
                profile.hit(f"扫描器指纹：{label}")

        if not profile.first_seen:
            profile.first_seen = rec["time"]
        profile.last_seen = rec["time"]
        if profile.hits:
            profile.sample(rec["raw"][:300])

    if unparsed:
        ctx.note_error(
            f"有 {unparsed} 条 Web 日志无法按标准格式解析，已按 IP 粗粒度统计"
        )

    findings: list[Finding] = []
    for ip, p in profiles.items():
        total_hits = sum(p.hits.values())
        if total_hits == 0 and p.status404 < MIN_404_FOR_SCAN:
            continue

        severity, reasons = _judge(p)
        if severity is None:
            continue

        public = is_public_ip(ip)
        f = Finding(
            title=f"Web 攻击行为：{ip}（{'公网' if public else '内网'}，{total_hits} 次命中）",
            severity=severity,
            category="Web 攻击",
            description=(
                f"该 IP 共发起 {p.requests} 次请求，命中攻击特征 {total_hits} 次。"
                + (f"主要行为：{'、'.join(sorted(p.hits, key=lambda k: -p.hits[k])[:6])}。"
                   if p.hits else "")
                + (f"404 请求 {p.status404} 次（疑似目录/备份文件爆破）。"
                   if p.status404 >= MIN_404_FOR_SCAN else "")
                + f"时间范围 {p.first_seen} ~ {p.last_seen}。"
            ),
            recommendation=(
                f"1) 在 WAF/防火墙封禁 {ip}；"
                f"2) 核查对应接口是否存在真实漏洞（重点看返回 200 的请求）；"
                f"3) 若存在敏感文件可访问，立即下线并轮换其中的凭据；"
                f"4) 检索该 IP 是否有成功登录记录，判断攻击是否已得手。"
            ),
            subjects=[ip] + list(p.hits)[:8],
            source="Web 访问日志",
            confidence="高" if total_hits >= MIN_ATTACK_HITS else "中",
            **_technique_for(p),
        )
        for label, cnt in sorted(p.hits.items(), key=lambda kv: -kv[1])[:8]:
            f.add_evidence(f"{label} × {cnt}")
        for s in p.sensitive_200[:5]:
            f.add_evidence(f"[需紧急确认] 敏感资源返回 200：{s}")
        if p.uas:
            f.add_evidence("UA: " + " | ".join(list(p.uas)[:3]))
        for s in p.samples[:5]:
            f.add_evidence(s)
        findings.append(f)

    return findings


def _technique_for(p: IPProfile) -> dict[str, str]:
    """按主导行为判定 ATT&CK 技术。"""
    if p.sensitive_200:
        return {"technique": "T1552", "tactic": "凭据访问"}
    if any(k.startswith("命令执行") for k in p.hits):
        return {"technique": "T1190", "tactic": "初始访问"}
    if any(k.startswith("SQL 注入") for k in p.hits):
        return {"technique": "T1190", "tactic": "初始访问"}
    if any(k.startswith("扫描器指纹") for k in p.hits):
        return {"technique": "T1595", "tactic": "侦察"}
    if p.status404 >= MIN_404_FOR_SCAN:
        return {"technique": "T1595", "tactic": "侦察"}
    return {"technique": "", "tactic": ""}


def _judge(p: IPProfile) -> tuple[Severity | None, list[str]]:
    """按画像给风险定级。"""
    reasons: list[str] = []

    if p.sensitive_200:
        return Severity.HIGH, ["敏感资源被成功访问"]

    attack_hits = sum(v for k, v in p.hits.items() if not k.startswith("扫描器指纹"))
    scanner_hits = sum(v for k, v in p.hits.items() if k.startswith("扫描器指纹"))

    if attack_hits >= MIN_ATTACK_HITS or scanner_hits > 0:
        severity = Severity.HIGH if attack_hits >= MIN_ATTACK_HITS else Severity.MEDIUM
        reasons.append("存在明确攻击载荷")

        if p.status404 >= MIN_404_FOR_SCAN:
            reasons.append("伴随目录爆破")
            severity = Severity.HIGH
        return severity, reasons

    if p.status404 >= MIN_404_FOR_SCAN:
        return Severity.MEDIUM, ["大量 404，疑似目录爆破"]

    if sum(p.hits.values()) > 0:
        return Severity.LOW, ["少量特征命中，建议人工确认"]
    return None, []
