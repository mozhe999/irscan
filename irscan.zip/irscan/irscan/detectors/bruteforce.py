"""暴力破解检测：滑动窗口判定失败次数，并关联失败之后出现的成功登录。"""

from __future__ import annotations

from collections import defaultdict
from datetime import timedelta

from ..core.engine import AuthEvent, ScanContext
from ..core.models import Finding, Severity
from ..core.utils import is_public_ip

SPRAY_MIN_USERS = 5

SUCCESS_LINK_WINDOW = timedelta(minutes=60)


def _max_in_window(stamps: list, window: timedelta) -> int:
    """滑动窗口内最大事件数。输入需已排序。"""
    best = 0
    start = 0
    for i, ts in enumerate(stamps):
        while ts - stamps[start] > window:
            start += 1
        best = max(best, i - start + 1)
    return best


def detect(ctx: ScanContext) -> list[Finding]:
    cfg = ctx.config
    window = cfg.window
    findings: list[Finding] = []

    failed: dict[str, list[AuthEvent]] = defaultdict(list)
    success: dict[str, list[AuthEvent]] = defaultdict(list)
    for ev in ctx.auth_events:
        if not ev.source_ip:
            continue
        if ev.timestamp is None:
            continue
        (success if ev.success else failed)[ev.source_ip].append(ev)

    for ip, events in failed.items():
        events.sort(key=lambda e: e.timestamp)
        stamps = [e.timestamp for e in events]
        peak = _max_in_window(stamps, window)
        if peak < cfg.fail_threshold:
            continue

        users = sorted({e.username for e in events if e.username})
        public = is_public_ip(ip)
        confidence = "高" if public else "中"
        origin = "公网" if public else "内网"

        hits = success.get(ip, [])
        succeeded = [s for s in hits if s.timestamp >= events[0].timestamp]
        if succeeded:

            window_end = max(e.timestamp for e in events) + SUCCESS_LINK_WINDOW
            linked = [s for s in succeeded if s.timestamp <= window_end]
            if linked:
                first = linked[0]
                f = Finding(
                    title=f"疑似爆破成功：{ip} 已登录成功",
                    severity=Severity.CRITICAL,
                    category="暴力破解",
                    description=(
                        f"来自{origin}地址 {ip} 的登录失败在 {cfg.window_seconds} 秒窗口内"
                        f"峰值达到 {peak} 次，之后出现成功登录，账号为 "
                        f"{first.username or '未知'}。"
                        f"攻击链已闭合，应视为主机已失陷，立即隔离并排查该账号的操作记录。"
                    ),
                    recommendation=(
                        f"1) 立即隔离主机或封禁 {ip}；"
                        f"2) 重置 {first.username or '该'} 账号口令并检查其 sudo/特权组；"
                        f"3) 检索该账号登录后创建的进程、计划任务、SSH authorized_keys；"
                        f"4) 检查 /root/.bash_history 与 ~/.ssh/known_hosts 是否被篡改。"
                    ),
                    subjects=[ip] + ([first.username] if first.username else []),
                    source="auth 日志 / Windows 4625+4624",
                    occurred_at=first.timestamp,
                    confidence="高",
                    technique="T1078",
                    tactic="初始访问 / 凭据访问",
                )
                for e in events[:8]:
                    f.add_evidence(e.raw)
                f.add_evidence(">>> 成功登录 >>>")
                for s in linked[:3]:
                    f.add_evidence(s.raw)
                findings.append(f)
                continue

        if len(users) >= SPRAY_MIN_USERS and peak < cfg.fail_threshold * 2:
            f = Finding(
                title=f"疑似密码喷洒：{ip} 尝试了 {len(users)} 个账号",
                severity=Severity.HIGH,
                category="密码喷洒",
                description=(
                    f"{origin}地址 {ip} 在窗口内对每个账号仅尝试少数几次"
                    f"（峰值 {peak} 次），但覆盖了 {len(users)} 个不同账号，"
                    f"这是典型的密码喷洒特征，刻意避开基于单账号失败次数的阈值。"
                ),
                recommendation=(
                    f"1) 封禁 {ip}；"
                    f"2) 检查这些账号是否存在弱口令（{'、'.join(users[:8])}"
                    f"{' 等' if len(users) > 8 else ''}）；"
                    f"3) 对 SSH/RDP 开启失败锁定策略（如 fail2ban / 账户锁定阈值）。"
                ),
                subjects=[ip] + users[:10],
                source="auth 日志 / Windows 4625",
                occurred_at=events[0].timestamp,
                confidence=confidence,
                technique="T1110.003",
                tactic="凭据访问",
            )
            for u in users[:10]:
                cnt = sum(1 for e in events if e.username == u)
                f.add_evidence(f"账号 {u}：失败 {cnt} 次")
            findings.append(f)
            continue

        severity = Severity.CRITICAL if peak >= cfg.critical_threshold else Severity.HIGH
        f = Finding(
            title=f"检测到暴力破解：{ip}（{peak} 次/{cfg.window_seconds} 秒）",
            severity=severity,
            category="暴力破解",
            description=(
                f"{origin}地址 {ip} 在 {cfg.window_seconds} 秒滑动窗口内登录失败峰值 "
                f"{peak} 次，累计失败 {len(events)} 次，针对账号："
                f"{'、'.join(users[:5]) or '未知'}"
                f"{' 等' if len(users) > 5 else ''}。"
            ),
            recommendation=(
                f"1) 防火墙或 fail2ban 封禁 {ip}；"
                f"2) 确认被针对账号未使用弱口令；"
                f"3) 建议禁用 SSH 密码登录改用密钥，或启用二次认证。"
            ),
            subjects=[ip] + users[:10],
            source="auth 日志 / Windows 4625",
            occurred_at=events[0].timestamp,
            confidence=confidence,
            technique="T1110.001",
            tactic="凭据访问",
        )
        for e in events[:10]:
            f.add_evidence(e.raw)
        findings.append(f)

    findings.extend(_detect_impossible_travel(ctx))
    return findings


def _detect_impossible_travel(ctx: ScanContext) -> list[Finding]:
    """同一账号短时间内从多个不同 IP 登录成功。"""
    by_user: dict[str, list[AuthEvent]] = defaultdict(list)
    for ev in ctx.auth_events:
        if ev.success and ev.username and ev.timestamp:
            by_user[ev.username].append(ev)

    out: list[Finding] = []
    for user, events in by_user.items():
        ips = sorted({e.source_ip for e in events if e.source_ip})
        if len(ips) < 3:
            continue
        events.sort(key=lambda e: e.timestamp)
        span = events[-1].timestamp - events[0].timestamp
        if span.total_seconds() <= 0:
            continue

        if span / len(ips) > timedelta(minutes=10):
            continue
        f = Finding(
            title=f"账号 {user} 短时间从 {len(ips)} 个来源登录成功",
            severity=Severity.MEDIUM,
            category="异常登录",
            description=(
                f"账号 {user} 在 {int(span.total_seconds() // 60)} 分钟内"
                f"从 {len(ips)} 个不同 IP 登录成功，"
                f"可能是口令泄露被多人共用，也可能是会话劫持。"
            ),
            recommendation=(
                f"1) 与账号持有人确认这些登录是否为其本人操作；"
                f"2) 若无法确认，重置口令并吊销现有会话；"
                f"3) 检查该账号是否有异常的权限变更。"
            ),
            subjects=[user] + ips[:10],
            source="auth 日志 / Windows 4624",
            occurred_at=events[0].timestamp,
            confidence="低",
            technique="T1078",
            tactic="初始访问",
        )
        for ip in ips[:10]:
            cnt = sum(1 for e in events if e.source_ip == ip)
            f.add_evidence(f"{ip}：成功登录 {cnt} 次")
        out.append(f)
    return out
