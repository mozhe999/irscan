"""Webshell 检测：按外置规则对文件内容加权评分。"""

from __future__ import annotations

import os
import re
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from ..core.engine import ScanContext
from ..core.models import Finding, Severity
from ..core.utils import iter_files, read_text

WEB_EXTS = (
    ".php", ".php3", ".php4", ".php5", ".php7", ".phtml", ".pht",
    ".jsp", ".jspx", ".jspf", ".asp", ".aspx", ".asa", ".asax",
    ".cer", ".cdx", ".perl", ".pl", ".cgi",
)

DEFAULT_TECHNIQUE = "T1505.003"


def detect(ctx: ScanContext) -> list[Finding]:
    if not ctx.config.webroots:
        return []
    ruleset = ctx.ruleset
    if ruleset is None:
        return []

    findings: list[Finding] = []
    for root in ctx.config.webroots:
        if not os.path.isdir(root):
            ctx.note_error(f"网站目录不存在: {root}")
            continue
        findings.extend(_scan_dir(root, ctx))
    findings.extend(_yara_scan(ctx))
    return findings


def _scan_dir(root: str, ctx: ScanContext) -> list[Finding]:
    ruleset = ctx.ruleset
    assert ruleset is not None
    high = int(ruleset.scoring.get("high", 6))
    out: list[Finding] = []

    paths = iter_files(root, exts=WEB_EXTS)
    jobs = max(1, int(getattr(ctx.config, "jobs", 1) or 1))

    def work(path: str) -> tuple | None:
        """返回 None（不用管）/ ("err", path)（读不了）/ ("hit", path, hits, mtime)。"""
        try:
            content = read_text(path)
            mtime = os.path.getmtime(path)
        except OSError:
            return ("err", path)
        if not content.strip():
            return None
        hits = ruleset.scan("file", content)
        if not hits:
            return None
        return ("hit", path, hits, mtime)

    if jobs > 1 and len(paths) > 100:
        with ThreadPoolExecutor(max_workers=jobs) as pool:
            scanned = list(pool.map(work, paths))
    else:
        scanned = [work(p) for p in paths]

    unreadable = [item[1] for item in scanned if item and item[0] == "err"]
    if unreadable:
        ctx.note_error(
            f"{len(unreadable)} 个文件读不到（权限不足或被占用），未纳入 Webshell 扫描，"
            f"例如 {unreadable[0]}"
        )

    for item in scanned:
        if not item or item[0] != "hit":
            continue
        _, path, hits, mtime = item

        score = sum(h.score for h in hits)
        severity = ruleset.severity_for_score(score)
        try:
            mtime_str = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
        except (OSError, ValueError):
            mtime_str = "未知"

        top = max(hits, key=lambda h: h.score).rule
        falsepositives: list[str] = []
        for h in hits:
            for fp in h.rule.falsepositives:
                if fp not in falsepositives:
                    falsepositives.append(fp)

        f = Finding(
            title=f"可疑 Webshell：{path}（风险分 {score}）",
            severity=severity,
            category="Webshell",
            description=(
                f"命中 {len(hits)} 条规则，累计 {score} 分（高危阈值 {high}）。"
                f"最后修改 {mtime_str}，核对这个时间是否对应某次发版或运维操作。"
            ),
            recommendation=(
                "1) 打开文件确认是否为业务代码；"
                "2) 确认是后门后下线文件并保留副本作为取证材料；"
                "3) 查该时间点前后的 Web 访问日志，定位上传入口"
                "（通常是文件上传漏洞、编辑器漏洞或后台弱口令）；"
                "4) 检查同目录下是否还有其他后门。"
            ),
            subjects=[path],
            source="规则 webshell",
            confidence="高" if score >= high else "中",
            technique=top.technique or DEFAULT_TECHNIQUE,
            tactic=top.tactic or "持久化",
            falsepositives=falsepositives,
        )
        for h in hits:
            f.add_evidence(h.detail())
        out.append(f)
    return out


def _yara_scan(ctx: ScanContext) -> list[Finding]:
    """可选的 yara 扫描：装了 yara-python 且给了规则目录才跑。"""
    rules_dir = os.environ.get("IRSCAN_YARA_RULES")
    if not rules_dir or not os.path.isdir(rules_dir):
        return []
    try:
        import yara  # type: ignore
    except ImportError:
        ctx.note_error("已配置 yara 规则目录但未安装 yara-python，跳过 yara 扫描")
        return []

    findings: list[Finding] = []
    for name in sorted(os.listdir(rules_dir)):
        if not name.endswith((".yar", ".yara")):
            continue
        try:
            rules = yara.compile(filepath=os.path.join(rules_dir, name))
        except Exception as exc:
            ctx.note_error(f"yara 规则编译失败 {name}: {exc}")
            continue
        for root in ctx.config.webroots:
            if not os.path.isdir(root):
                continue
            for path in iter_files(root, exts=WEB_EXTS):
                try:
                    matches = rules.match(path)
                except Exception:
                    continue
                for m in matches:
                    findings.append(Finding(
                        title=f"YARA 命中：{m.rule} @ {path}",
                        severity=Severity.HIGH,
                        category="Webshell",
                        description=(
                            f"规则 {m.rule}（文件 {name}）命中该文件，命中字符串："
                            f"{', '.join(str(s) for s in m.strings[:5]) if m.strings else '—'}"
                        ),
                        recommendation="确认为后门后下线文件并保留副本，同时溯源上传入口。",
                        subjects=[path],
                        source=f"yara:{name}",
                        confidence="高",
                        technique=DEFAULT_TECHNIQUE,
                        tactic="持久化",
                    ))
    return findings
