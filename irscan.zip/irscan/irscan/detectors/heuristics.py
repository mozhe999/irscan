"""主机侧启发式检测：进程、网络连接、账户、持久化项。"""

from __future__ import annotations

import os
import re

from ..core.engine import ScanContext
from ..core.models import ConnectionInfo, Finding, Severity

SYSTEM_PROCESS_HOME = {
    "svchost.exe": r"windows\\system32",
    "lsass.exe": r"windows\\system32",
    "csrss.exe": r"windows\\system32",
    "services.exe": r"windows\\system32",
    "smss.exe": r"windows\\system32",
    "winlogon.exe": r"windows\\system32",
    "explorer.exe": r"windows\\",
}
SYSTEM_PROCESS_HOME_UNIX = {
    "sshd", "systemd", "init", "kthreadd", "cron", "rsyslogd", "dbus-daemon",
}

TEMP_DIR_HINTS = (
    "/tmp", "/var/tmp", "/dev/shm",
    "appdata\\local\\temp", "\\windows\\temp", "%temp%", "/temp/",
)

SUSPICIOUS_PORTS = {
    4444, 5555, 6666, 6667, 7777, 8888, 1337, 31337, 4443, 9001, 9034, 10000,
}

SUSPICIOUS_PROC_NAMES = {
    "nc.exe", "ncat.exe", "netcat", "mimikatz.exe", "psexec.exe",
    "psexesvc.exe", "lazagne.exe", "beacon.exe", "cobalt", "meterpreter",
}


def detect(ctx: ScanContext) -> list[Finding]:
    out: list[Finding] = []
    out.extend(_suspicious_processes(ctx))
    out.extend(_masquerading(ctx))
    out.extend(_suspicious_connections(ctx))
    out.extend(_account_anomalies(ctx))
    out.extend(_persistence_anomalies(ctx))
    return out


def _is_temp_path(path: str) -> bool:
    low = path.lower()
    return any(h in low for h in TEMP_DIR_HINTS)


def _suspicious_processes(ctx: ScanContext) -> list[Finding]:
    ruleset = ctx.ruleset
    if ruleset is None:
        return []
    out: list[Finding] = []
    for proc in ctx.snapshot.processes:
        blob = f"{proc.name} {proc.cmdline} {proc.exe}"
        hits = ruleset.scan("process", blob)
        labels = [h.rule.label() for h in hits]

        if proc.name.lower() in SUSPICIOUS_PROC_NAMES:
            labels.append(f"已知攻击工具名：{proc.name}")
        if not labels:
            continue

        severity = max((h.rule.severity for h in hits), default=Severity.HIGH)
        top = max(hits, key=lambda h: h.rule.severity).rule if hits else None
        falsepositives: list[str] = []
        for h in hits:
            for fp in h.rule.falsepositives:
                if fp not in falsepositives:
                    falsepositives.append(fp)

        f = Finding(
            title=f"可疑进程：{proc.name} (PID {proc.pid})",
            severity=severity,
            category="可疑进程",
            description=(
                f"进程 PID={proc.pid}、PPID={proc.ppid}、名称 {proc.name}，"
                f"命中特征：{'；'.join(labels)}。"
                + (f"可执行文件位于临时目录 {proc.exe}，正常程序不会从临时目录运行。"
                   if proc.exe and _is_temp_path(proc.exe) else "")
            ),
            recommendation=(
                f"1) 先不要直接 kill，抓取进程内存与完整命令行后再处置；"
                f"2) 查看父进程 PID {proc.ppid} 确认是谁拉起的；"
                f"3) 检查该进程的网络连接与创建的文件；"
                f"4) 确认为恶意后隔离主机并溯源入口。"
            ),
            subjects=[proc.name, str(proc.pid)],
            source="进程快照",
            confidence="中",
            technique=(top.technique if top else "") or "T1059",
            tactic=(top.tactic if top else "") or "执行",
            falsepositives=falsepositives,
        )
        f.add_evidence(f"命令行: {proc.cmdline[:300] or '(空)'}")
        f.add_evidence(f"路径: {proc.exe or '(未知)'}")
        for h in hits:
            f.add_evidence(f"命中规则 {h.rule.id}: {h.detail()}")
        out.append(f)
    return out


def _masquerading(ctx: ScanContext) -> list[Finding]:
    """进程名伪装：系统进程名却跑在异常目录。"""
    if not ctx.snapshot.processes:
        return []
    is_windows = "win" in ctx.snapshot.platform.lower()
    out: list[Finding] = []
    for proc in ctx.snapshot.processes:
        name = proc.name.lower()
        exe = proc.exe.lower()

        if is_windows:
            expected = SYSTEM_PROCESS_HOME.get(name)
            if not expected or not exe:
                continue
            if re.search(expected, exe):
                continue
            reason = f"{proc.name} 正常应位于系统目录，实际路径为 {proc.exe}"
        else:
            if name not in SYSTEM_PROCESS_HOME_UNIX or not exe:
                continue

            if exe.startswith(("/usr/sbin", "/sbin", "/usr/bin", "/bin",
                               "/lib/systemd", "/usr/lib/systemd")):
                continue
            reason = f"{proc.name} 正常应位于系统目录，实际路径为 {proc.exe}"

        f = Finding(
            title=f"进程名伪装：{proc.name} (PID {proc.pid}) 路径异常",
            severity=Severity.HIGH,
            category="可疑进程",
            description=(
                f"{reason}。攻击者在拿到权限后常把木马改名为 svchost.exe 之类"
                f"以躲避人工排查，这是最需要优先核实的一类发现。"
            ),
            recommendation=(
                f"1) 核对文件数字签名与哈希，到威胁情报平台查询；"
                f"2) 检查该文件创建时间是否晚于系统安装时间；"
                f"3) 查看该进程的网络连接与子进程。"
            ),
            subjects=[proc.name, proc.exe],
            source="进程快照",
            confidence="高",
            technique="T1036",
            tactic="防御规避",
        )
        f.add_evidence(f"命令行: {proc.cmdline[:300] or '(空)'}")
        f.add_evidence(f"父进程 PID: {proc.ppid}")
        out.append(f)
    return out


def _suspicious_connections(ctx: ScanContext) -> list[Finding]:
    out: list[Finding] = []
    for conn in ctx.snapshot.connections:
        suspicious_port = (
            conn.remote_port in SUSPICIOUS_PORTS or conn.local_port in SUSPICIOUS_PORTS
        )
        established = conn.state.upper() in ("ESTABLISHED", "ESTAB")
        if not (established or conn.state.upper() == "LISTEN"):
            continue

        if established and suspicious_port:
            f = Finding(
                title=f"可疑端口连接：{conn.remote_addr}:{conn.remote_port}"
                      f"（{conn.process or '未知进程'}）",
                severity=Severity.HIGH,
                category="可疑连接",
                description=(
                    f"本机 {conn.local_addr}:{conn.local_port} 与 "
                    f"{conn.remote_addr}:{conn.remote_port} 建立连接，"
                    f"端口 {conn.remote_port} 是常见的反弹 shell / 远控端口。"
                    f"进程：{conn.process or '未知'}（PID {conn.pid}）。"
                ),
                recommendation=(
                    f"1) 确认该连接的业务归属，无法归属则按失陷处理；"
                    f"2) 抓取该进程的完整命令行与内存；"
                    f"3) 在边界防火墙核查是否有其他主机连向同一地址。"
                ),
                subjects=[conn.remote_addr, conn.process or "-"],
                source="网络连接快照",
                confidence="中",
                technique="T1071",
                tactic="命令与控制",
            )
            f.add_evidence(
                f"{conn.proto} {conn.local_addr}:{conn.local_port} -> "
                f"{conn.remote_addr}:{conn.remote_port} {conn.state} "
                f"pid={conn.pid} proc={conn.process}"
            )
            out.append(f)

        elif conn.state.upper() == "LISTEN" and _is_wide_listen(conn) and suspicious_port:
            f = Finding(
                title=f"可疑监听端口：{conn.local_port}（{conn.process or '未知进程'}）",
                severity=Severity.MEDIUM,
                category="可疑连接",
                description=(
                    f"进程 {conn.process or '未知'}（PID {conn.pid}）在所有网卡上监听 "
                    f"{conn.local_port} 端口，该端口常与后门/远控相关。"
                ),
                recommendation="确认业务是否需要对外监听该端口，若不需要则关闭并排查对应进程。",
                subjects=[str(conn.local_port), conn.process or "-"],
                source="网络连接快照",
                confidence="中",
                technique="T1571",
                tactic="命令与控制",
            )
            f.add_evidence(
                f"{conn.proto} {conn.local_addr}:{conn.local_port} {conn.state} "
                f"pid={conn.pid} proc={conn.process}"
            )
            out.append(f)
    return out


def _is_wide_listen(conn: ConnectionInfo) -> bool:
    return conn.local_addr in ("0.0.0.0", "::", "*", "")


def _account_anomalies(ctx: ScanContext) -> list[Finding]:
    out: list[Finding] = []
    is_windows = "win" in ctx.snapshot.platform.lower()

    for acc in ctx.snapshot.accounts:

        if not is_windows and acc.uid == "0" and acc.username != "root":
            f = Finding(
                title=f"发现影子 root 账户：{acc.username}",
                severity=Severity.CRITICAL,
                category="账户异常",
                description=(
                    f"账户 {acc.username} 的 UID 为 0，等同于 root 权限。"
                    f"这是攻击者提权后留后门的常见手法，比新增一个 sudo 账户更隐蔽。"
                ),
                recommendation=(
                    f"1) 立即禁用该账户并排查其登录记录；"
                    f"2) 检查 /etc/passwd、/etc/shadow 的修改时间；"
                    f"3) 排查该账户创建的文件与计划任务；"
                    f"4) 确认无其他 UID=0 的异常账户后，考虑重建主机。"
                ),
                subjects=[acc.username],
                source="/etc/passwd",
                confidence="高",
                technique="T1136",
                tactic="持久化",
            )
            f.add_evidence(f"{acc.username}: uid={acc.uid} gid={acc.gid} home={acc.home} shell={acc.shell}")
            out.append(f)
            continue

        if acc.note and ("500" in acc.note or "机器账户" in acc.note):
            severity = Severity.MEDIUM if "500" in acc.note else Severity.INFO
            f = Finding(
                title=f"账户需确认：{acc.username}",
                severity=severity,
                category="账户异常",
                description=acc.note,
                recommendation=(
                    "确认该账户是否为业务必需；内置 Administrator 建议重命名并禁用，"
                    "同时确认没有以它身份执行的可疑登录。"
                ),
                subjects=[acc.username],
                source="Win32_UserAccount",
                confidence="中",
            )
            f.add_evidence(f"{acc.username} SID={acc.uid} 启用={acc.enabled}")
            out.append(f)

    if not is_windows:
        system_accounts = {"daemon", "bin", "sys", "sync", "games", "man", "lp",
                           "mail", "news", "uucp", "proxy", "www-data", "backup",
                           "list", "irc", "nobody"}
        for acc in ctx.snapshot.accounts:
            if (acc.username in system_accounts and acc.enabled
                    and acc.shell and "nologin" not in acc.shell):
                f = Finding(
                    title=f"系统账户 {acc.username} 具备可登录 shell",
                    severity=Severity.MEDIUM,
                    category="账户异常",
                    description=(
                        f"账户 {acc.username} 的登录 shell 为 {acc.shell}，"
                        f"系统账户通常应为 /usr/sbin/nologin。被改成可登录 shell "
                        f"往往意味着攻击者想用它做持久化登录。"
                    ),
                    recommendation=(
                        f"1) 将该账户 shell 改回 nologin 或禁用；"
                        f"2) 排查该账户最近的登录记录与其家目录下的文件。"
                    ),
                    subjects=[acc.username],
                    source="/etc/passwd",
                    confidence="中",
                    technique="T1098",
                    tactic="持久化",
                )
                f.add_evidence(f"{acc.username}: shell={acc.shell} home={acc.home}")
                out.append(f)
    return out


def _persistence_anomalies(ctx: ScanContext) -> list[Finding]:
    out: list[Finding] = []
    for item in ctx.snapshot.startup:
        cmd = item.command or ""
        if not cmd:
            continue
        ruleset = ctx.ruleset
        hits: list[str] = []
        rule_hits = ruleset.scan("startup", cmd) if ruleset else []
        hits += [h.rule.label() for h in rule_hits]
        if _is_temp_path(cmd):
            hits.append("执行路径位于临时目录")
        if not hits:
            continue

        severity = max((h.rule.severity for h in rule_hits), default=Severity.HIGH)
        top = max(rule_hits, key=lambda h: h.rule.severity).rule if rule_hits else None
        falsepositives: list[str] = []
        for h in rule_hits:
            for fp in h.rule.falsepositives:
                if fp not in falsepositives:
                    falsepositives.append(fp)

        f = Finding(
            title=f"可疑持久化项：{item.name}",
            severity=severity,
            category="持久化",
            description=(
                f"{item.source} 中的条目 {item.name} 命中：{'；'.join(hits)}。"
                f"持久化是攻击者维持权限的关键手段，即便主机已清理进程，"
                f"漏掉一条计划任务就等于没处置完。"
            ),
            recommendation=(
                f"1) 确认该条目是否为业务/运维所需；"
                f"2) 无法归属则禁用该条目并保留其命令行作为取证材料；"
                f"3) 排查同批创建的其它持久化项（攻击很少只写一条）。"
            ),
            subjects=[item.name],
            source=item.source,
            confidence="中",
            technique=(top.technique if top else "")
            or ("T1053" if item.source in ("计划任务", "cron", "systemd") else "T1547.001"),
            tactic="持久化",
            falsepositives=falsepositives,
        )
        f.add_evidence(f"来源: {item.source}")
        f.add_evidence(f"命令: {cmd[:300]}")
        for h in rule_hits:
            f.add_evidence(f"命中规则 {h.rule.id}: {h.detail()}")
        out.append(f)
    return out
