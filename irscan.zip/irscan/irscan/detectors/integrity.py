"""完整性交叉验证：比对进程与命令的两个视角。"""

from __future__ import annotations

from ..core.models import Finding, Severity

DRIFT_TOLERANCE = 2


def detect(ctx) -> list[Finding]:
    out: list[Finding] = []
    out.extend(_hidden_processes(ctx))
    out.extend(_promisc(ctx))
    out.extend(_shell_rc(ctx))
    out.extend(_pkg_integrity(ctx))
    out.extend(_startup_folder(ctx))
    return out


def _hidden_processes(ctx) -> list[Finding]:
    """隐藏进程：/proc 与 ps 两个视角取差集，两个方向都要报。"""
    snap = ctx.snapshot
    cli_pids = set(snap.extra.get("visible_pids") or [])
    if not cli_pids:

        snap.note_error("命令行进程枚举不可用，跳过隐藏进程交叉验证")
        return []

    proc_pids = {str(p.pid) for p in snap.processes}
    if not proc_pids:
        return []

    only_kernel = sorted(proc_pids - cli_pids)
    only_cli = sorted(cli_pids - proc_pids)
    total = max(len(proc_pids), 1)

    findings: list[Finding] = []
    for diff, direction, detail in (
        (only_kernel, "命令行视角缺失", "内核枚举可见但 ps/tasklist 未列出，命令行工具可能已被替换或过滤"),
        (only_cli, "内核视角缺失", "命令行可见但 /proc 枚举未出现，进程枚举路径可能被挂钩"),
    ):
        if len(diff) <= DRIFT_TOLERANCE:
            continue
        ratio = len(diff) / total
        severity = Severity.CRITICAL if ratio > 0.1 else (
            Severity.HIGH if ratio > 0.03 else Severity.MEDIUM)
        findings.append(Finding(
            title=f"进程视图不一致：{len(diff)} 个 PID 仅存在于{direction}",
            severity=severity,
            category="Rootkit / 进程隐藏",
            description=(
                f"{detail}。共采集到内核视角 {len(proc_pids)} 个进程、"
                f"命令行视角 {len(cli_pids)} 个，差异 {len(diff)} 个"
                f"（占比 {ratio:.1%}）。"
            ),
            recommendation=(
                "用干净的 Live CD 或已知可信的静态 ps 二进制复核；"
                "本机命令已不可信时，不要依据本机输出做结论。"
            ),
            evidence=[f"PID {p}" for p in diff[:20]],
            subjects=[p for p in diff[:10]],
            source="进程双视角交叉验证",
            confidence="中",
            technique="T1014",
            tactic="防御规避",
        ))
    return findings


def _promisc(ctx) -> list[Finding]:
    """返回混杂模式网卡。"""
    ifaces = ctx.snapshot.extra.get("promisc") or []
    if not ifaces:
        return []
    return [Finding(
        title=f"网卡处于混杂模式：{', '.join(ifaces)}",
        severity=Severity.HIGH,
        category="网络嗅探",
        description=(
            "网卡被设置为混杂模式，通常由嗅探器或流量劫持程序触发。"
            "在共享网段内可用于抓取其他主机的明文凭据。"
        ),
        recommendation=(
            "定位持有该网卡句柄的进程并检查其可执行文件来源；"
            "确认非授权后关闭网卡混杂模式并排查凭据泄露范围。"
        ),
        evidence=ifaces,
        subjects=ifaces,
        source="/sys/class/net/*/flags",
        confidence="高",
        technique="T1040",
        tactic="凭据访问",
    )]


def _shell_rc(ctx) -> list[Finding]:
    """shell 初始化文件后门：PROMPT_COMMAND 与排障命令的 alias 覆盖。"""
    hits = ctx.snapshot.extra.get("shell_rc") or []
    if not hits:
        return []
    critical = [h for h in hits if any(
        c in h for c in ("ps", "netstat", "top", "lsof", "ss", "ls"))]
    return [Finding(
        title=f"shell 初始化文件存在可疑配置（{len(hits)} 处）",
        severity=Severity.CRITICAL if critical else Severity.HIGH,
        category="持久化 / 后门",
        description=(
            "在 shell 初始化文件中发现可疑的 alias 覆盖或 PROMPT_COMMAND 注入。"
            + ("其中覆盖了对排障命令的 alias,本机命令输出已不可信。"
               if critical else "")
        ),
        recommendation=(
            "逐条确认是否由运维主动配置；非预期的条目应删除并排查投放者。"
            "注意：在 alias 被覆盖的机器上，后续所有命令输出都需保持怀疑。"
        ),
        evidence=hits[:15],
        subjects=[h.split(":")[0] for h in hits[:8]],
        source="shell 初始化文件",
        confidence="中",
        technique="T1546.004",
        tactic="持久化",
    )]


def _pkg_integrity(ctx) -> list[Finding]:
    """校验排障命令是否被包管理器改动，决定其余结论是否可信。"""
    modified = ctx.snapshot.extra.get("pkg_modified") or []
    if not modified:
        return []
    critical_hit = any(c in " ".join(modified) for c in ("ps", "top", "netstat", "lsof", "ss"))
    return [Finding(
        title=f"关键系统命令与包管理器记录不一致（{len(modified)} 项）",
        severity=Severity.CRITICAL if critical_hit else Severity.HIGH,
        category="完整性 / 防御削弱",
        description=(
            "包管理器校验发现系统文件与发行版记录不符。"
            + ("其中包含排障命令（ps/top/netstat/lsof/ss），"
               "意味着攻击者可能正在干扰排查，本机进程与网络输出均不可信。"
               if critical_hit else "")
        ),
        recommendation=(
            "从同版本安装介质提取原始文件比对；"
            "确认被替换后应视为主机完全失陷，按重装处理而非单点清除。"
        ),
        evidence=modified[:20],
        subjects=[ln.split()[-1] for ln in modified[:10] if ln.split()],
        source="rpm -Vf / dpkg -V",
        confidence="高",
        technique="T1562.001",
        tactic="防御规避",
    )]


def _startup_folder(ctx) -> list[Finding]:
    """Windows 启动文件夹，无需管理员权限即可投放。"""

    items = [f.path for f in ctx.snapshot.files if f.kind == "startup_folder"]
    if not items:
        return []
    suspicious = [p for p in items if p.lower().endswith(
        (".exe", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".hta", ".lnk"))]
    if not suspicious:
        return []
    return [Finding(
        title=f"启动文件夹存在可执行项（{len(suspicious)} 个）",
        severity=Severity.MEDIUM,
        category="持久化",
        description=(
            "启动文件夹中的条目会在用户登录时自动执行，"
            "且普通用户权限即可写入，常被用于权限受限场景下的持久化。"
        ),
        recommendation="逐一确认来源，未知条目移除后排查投放时间点附近的登录记录。",
        evidence=suspicious[:15],
        subjects=suspicious[:10],
        source="启动文件夹",
        confidence="低",
        technique="T1547.001",
        tactic="持久化",
    )]
