"""核心数据模型：采集侧的快照结构与检测侧的结论结构。"""

from __future__ import annotations

import enum
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


class Severity(enum.IntEnum):
    """风险等级。IntEnum 便于直接比较大小与排序。"""

    INFO = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

    @property
    def label(self) -> str:
        return {
            Severity.INFO: "信息",
            Severity.LOW: "低危",
            Severity.MEDIUM: "中危",
            Severity.HIGH: "高危",
            Severity.CRITICAL: "严重",
        }[self]


@dataclass
class Finding:
    """一条检测结论：发现了什么、依据是什么、该怎么处置。"""

    title: str
    severity: Severity
    category: str
    description: str = ""
    recommendation: str = ""
    evidence: list[str] = field(default_factory=list)
    subjects: list[str] = field(default_factory=list)
    source: str = ""
    occurred_at: datetime | None = None
    confidence: str = "中"
    technique: str = ""
    tactic: str = ""
    falsepositives: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.id = uuid.uuid4().hex[:12]

    def add_evidence(self, line: str, limit: int = 20) -> None:
        """追加证据行，限制条数以免报告被单个大日志撑爆。"""
        if len(self.evidence) < limit:
            self.evidence.append(line)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "severity": self.severity.name,
            "severity_label": self.severity.label,
            "category": self.category,
            "description": self.description,
            "recommendation": self.recommendation,
            "evidence": self.evidence,
            "subjects": self.subjects,
            "source": self.source,
            "confidence": self.confidence,
            "technique": self.technique,
            "tactic": self.tactic,
            "falsepositives": self.falsepositives,
            "occurred_at": self.occurred_at.isoformat() if self.occurred_at else None,
        }


@dataclass
class ProcessInfo:
    pid: int
    name: str
    ppid: int = -1
    exe: str = ""
    cmdline: str = ""
    user: str = ""
    started_at: str = ""


@dataclass
class ConnectionInfo:
    proto: str
    local_addr: str
    local_port: int
    remote_addr: str
    remote_port: int
    state: str = ""
    pid: int = -1
    process: str = ""


@dataclass
class StartupItem:
    """持久化项：启动项、计划任务或服务。"""

    source: str
    name: str
    command: str = ""
    user: str = ""
    enabled: bool = True


@dataclass
class AccountInfo:
    username: str
    uid: str = ""
    gid: str = ""
    home: str = ""
    shell: str = ""
    enabled: bool = True
    note: str = ""


@dataclass
class EventRecord:
    """Windows 安全日志事件，主要用 4624 / 4625。"""

    event_id: int
    timestamp: datetime | None
    fields: dict[str, str] = field(default_factory=dict)


@dataclass
class FileInfo:
    """值得记录的文件对象，mtime 往往对应攻击者动手的时刻。"""

    path: str
    kind: str = ""
    mode: str = ""
    owner: str = ""
    size: int = 0
    modified_at: str = ""
    content: str = ""
    note: str = ""


@dataclass
class ServiceInfo:
    """系统服务，Windows 为主。"""

    name: str
    display_name: str = ""
    path: str = ""
    state: str = ""
    start_mode: str = ""
    user: str = ""
    note: str = ""
    risk: str = ""


@dataclass
class WmiSubscription:
    """WMI 永久事件订阅，不落注册表也不建计划任务，需单独查询。"""

    kind: str
    name: str = ""
    query: str = ""
    command: str = ""
    note: str = ""


@dataclass
class TimelineEvent:
    """时间线节点，按顺序反映攻击者做了什么。"""

    timestamp: datetime
    label: str
    detail: str = ""
    severity: Severity = Severity.INFO
    source: str = ""


@dataclass
class HostSnapshot:
    """一次采集的结果。errors 记录想采但没采到的项，报告中作为盲区列出。"""

    platform: str
    hostname: str = ""
    collected_at: datetime = field(default_factory=datetime.now)
    processes: list[ProcessInfo] = field(default_factory=list)
    connections: list[ConnectionInfo] = field(default_factory=list)
    startup: list[StartupItem] = field(default_factory=list)
    accounts: list[AccountInfo] = field(default_factory=list)
    events: list[EventRecord] = field(default_factory=list)
    files: list[FileInfo] = field(default_factory=list)
    services: list[ServiceInfo] = field(default_factory=list)
    wmi: list[WmiSubscription] = field(default_factory=list)
    extra: dict[str, list[str]] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    def note_error(self, msg: str) -> None:
        self.errors.append(msg)

    @property
    def summary(self) -> dict[str, int]:
        return {
            "进程": len(self.processes),
            "网络连接": len(self.connections),
            "持久化项": len(self.startup),
            "账户": len(self.accounts),
            "安全事件": len(self.events),
            "关键文件": len(self.files),
            "服务": len(self.services),
            "WMI订阅": len(self.wmi),
        }

    def to_baseline(self) -> dict[str, object]:
        """导出基线指纹，只存标识不存状态，用于对比多了什么、少了什么。"""
        return {
            "hostname": self.hostname,
            "platform": self.platform,
            "listening": sorted({
                f"{c.proto}:{c.local_port}"
                for c in self.connections if c.state.upper() == "LISTEN"
            }),
            "startup": sorted({
                f"{s.source}::{s.name}" for s in self.startup
            }),
            "accounts": sorted({a.username for a in self.accounts}),
            "services": sorted({s.name for s in self.services}),
            "suid_files": sorted({f.path for f in self.files if f.kind in ("suid", "sgid")}),
            "process_names": sorted({p.name for p in self.processes}),
        }


@dataclass
class ScanResult:
    """最终扫描结果，交给报告模块渲染。"""

    snapshot: HostSnapshot
    findings: list[Finding] = field(default_factory=list)
    started_at: datetime = field(default_factory=datetime.now)
    finished_at: datetime | None = None
    targets: list[str] = field(default_factory=list)
    timeline: list[TimelineEvent] = field(default_factory=list)

    def add(self, finding: Finding) -> None:
        self.findings.append(finding)

    def sort_findings(self) -> None:
        """按严重度降序、同级按标题与主体排序，保证输出稳定。"""
        self.findings.sort(key=lambda f: (-int(f.severity), f.title, f.subjects))

    @property
    def counts(self) -> dict[str, int]:
        out = {s.name: 0 for s in Severity}
        for f in self.findings:
            out[f.severity.name] += 1
        return out

    @property
    def highest(self) -> Severity:
        return max((f.severity for f in self.findings), default=Severity.INFO)

    @property
    def duration(self) -> float:
        if not self.finished_at:
            return 0.0
        return (self.finished_at - self.started_at).total_seconds()
