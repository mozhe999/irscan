"""外置检测规则：加载、校验、匹配。规则为 JSON，字段沿用 Sigma 命名。"""

from __future__ import annotations

import glob
import json
import os
import re
from dataclasses import dataclass, field
from typing import Iterable

from .attck import TECHNIQUES
from .models import Severity

DATA_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "rules"
)

LEVEL_MAP = {
    "info": Severity.INFO,
    "low": Severity.LOW,
    "medium": Severity.MEDIUM,
    "high": Severity.HIGH,
    "critical": Severity.CRITICAL,
}

_MODES = ("any", "all", "score")

MAX_HIT_COUNT = 500

_FINDALL_MAX_TEXT = 65536


@dataclass
class Pattern:
    regex: re.Pattern[str]
    weight: int = 1
    note: str = ""

    def search(self, text: str) -> tuple[str, int] | None:
        """返回 (命中片段, 命中次数)。"""
        m = self.regex.search(text)
        if not m:
            return None
        sample = m.group(0)[:120].replace("\n", " ").replace("\r", "")
        if len(text) <= _FINDALL_MAX_TEXT:

            return sample, len(self.regex.findall(text))
        count = 0
        for _ in self.regex.finditer(text):
            count += 1
            if count >= MAX_HIT_COUNT:
                break
        return sample, count


@dataclass
class Rule:
    id: str
    title: str
    targets: tuple[str, ...] = ()
    mode: str = "any"
    patterns: list[Pattern] = field(default_factory=list)
    level: str = "medium"
    description: str = ""
    falsepositives: list[str] = field(default_factory=list)
    references: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    enabled: bool = True
    status: str = "experimental"
    source: str = ""

    @property
    def severity(self) -> Severity:
        return LEVEL_MAP.get(self.level.lower(), Severity.MEDIUM)

    @property
    def technique(self) -> str:
        """从 tags 取 ATT&CK 技术编号：attack.t1059.001 -> T1059.001。"""
        for tag in self.tags:
            low = tag.lower()
            if low.startswith("attack.t"):
                return "T" + low.split("attack.t", 1)[1].upper()
        return ""

    @property
    def tactic(self) -> str:
        t = TECHNIQUES.get(self.technique)
        return t.tactic if t else ""

    def match(self, text: str) -> RuleHit | None:
        """对一段文本执行本规则，未命中返回 None。"""
        hits: list[tuple[int, str, int, str]] = []
        for p in self.patterns:
            found = p.search(text)
            if found is None:
                if self.mode == "all":
                    return None
                continue
            sample, count = found
            hits.append((p.weight, sample, count, p.note))
        if not hits:
            return None
        return RuleHit(rule=self, score=sum(h[0] for h in hits), hits=hits)

    def label(self) -> str:
        return self.title + (f"（{self.description}）" if self.description else "")


@dataclass
class RuleHit:
    rule: Rule
    score: int
    hits: list[tuple[int, str, int, str]] = field(default_factory=list)

    def detail(self) -> str:
        parts = []
        for weight, sample, count, note in self.hits:
            text = f"[{weight}分] {self.rule.title}"
            if note:
                text += f"：{note}"
            if count > 1:
                text += f" ×{count}"
            if sample:
                text += f"  样例: {sample}"
            parts.append(text)
        return "；".join(parts)


@dataclass
class RuleSet:
    rules: list[Rule] = field(default_factory=list)
    scoring: dict[str, int] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    def for_target(self, target: str) -> list[Rule]:
        return [r for r in self.rules if target in r.targets and r.enabled]

    def scan(self, target: str, text: str) -> list[RuleHit]:
        """对一段文本执行该 target 下的全部规则。"""
        out: list[RuleHit] = []
        for rule in self.for_target(target):
            hit = rule.match(text)
            if hit:
                out.append(hit)
        return out

    def severity_for_score(self, score: int) -> Severity:
        """score 模式分级，阈值由规则文件的 scoring 段控制，默认 6 / 3。"""
        high = int(self.scoring.get("high", 6))
        medium = int(self.scoring.get("medium", 3))
        if score >= high:
            return Severity.HIGH
        if score >= medium:
            return Severity.MEDIUM
        return Severity.LOW

    def summary(self) -> dict[str, int]:
        """按 target 统计已启用规则数。"""
        out: dict[str, int] = {}
        for r in self.rules:
            if not r.enabled:
                continue
            for t in r.targets:
                out[t] = out.get(t, 0) + 1
        return out


def _parse_rule(data: dict, source: str, errors: list[str]) -> Rule | None:
    rid = str(data.get("id") or "").strip()
    if not rid:
        errors.append(f"{source}: 规则缺少 id，已跳过")
        return None
    raw_patterns = data.get("patterns") or []
    if not raw_patterns:
        errors.append(f"{source}: 规则 {rid} 没有 patterns，已跳过")
        return None

    patterns: list[Pattern] = []
    for item in raw_patterns:
        expr = item.get("re") if isinstance(item, dict) else item
        if not expr:
            continue
        flags = re.I
        if isinstance(item, dict) and item.get("case_sensitive"):
            flags = 0
        if isinstance(item, dict) and item.get("dotall"):
            flags |= re.S
        try:
            compiled = re.compile(str(expr), flags)
        except re.error as exc:
            errors.append(f"{source}: 规则 {rid} 正则编译失败（{exc}），已跳过")
            return None
        weight = int(item.get("weight", 1)) if isinstance(item, dict) else 1
        note = str(item.get("note", "")) if isinstance(item, dict) else ""
        patterns.append(Pattern(compiled, weight, note))
    if not patterns:
        errors.append(f"{source}: 规则 {rid} 的 patterns 全部无效，已跳过")
        return None

    targets = data.get("target") or []
    if isinstance(targets, str):
        targets = [t.strip() for t in targets.split(",") if t.strip()]
    mode = str(data.get("mode") or "any").lower()
    if mode not in _MODES:
        errors.append(f"{source}: 规则 {rid} 的 mode={mode} 不支持，按 any 处理")
        mode = "any"

    return Rule(
        id=rid,
        title=str(data.get("title") or rid),
        targets=tuple(str(t) for t in targets),
        mode=mode,
        patterns=patterns,
        level=str(data.get("level") or "medium").lower(),
        description=str(data.get("description") or ""),
        falsepositives=[str(x) for x in (data.get("falsepositives") or [])],
        references=[str(x) for x in (data.get("references") or [])],
        tags=[str(x) for x in (data.get("tags") or [])],
        enabled=bool(data.get("enabled", True)),
        status=str(data.get("status") or "experimental"),
        source=source,
    )


def _parse_doc(name: str, text: str, errors: list[str]) -> tuple[list[Rule], dict[str, int]]:
    """解析一份规则文件，返回 (规则列表, scoring 段)。"""
    try:
        data = json.loads(text)
    except ValueError as exc:
        errors.append(f"规则文件 {name} 解析失败：{exc}")
        return [], {}
    if isinstance(data, list):
        items, scoring = data, {}
    else:
        items = data.get("rules") or []
        scoring = data.get("scoring") or {}
    rules: list[Rule] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        rule = _parse_rule(item, name, errors)
        if rule:
            rules.append(rule)
    return rules, scoring


def _load_file(path: str, errors: list[str]) -> tuple[list[Rule], dict[str, int]]:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            text = fh.read()
    except OSError as exc:
        errors.append(f"规则文件 {path} 读取失败：{exc}")
        return [], {}
    return _parse_doc(os.path.basename(path), text, errors)


def _builtin_docs(errors: list[str]) -> list[tuple[str, str]]:
    """返回内置规则的 (文件名, 文本) 列表。"""
    if os.path.isdir(DATA_DIR):
        out: list[tuple[str, str]] = []
        for p in sorted(glob.glob(os.path.join(DATA_DIR, "*.json"))):
            with open(p, "r", encoding="utf-8") as fh:
                out.append((os.path.basename(p), fh.read()))
        return out
    try:
        from importlib import resources

        rules_dir = resources.files("irscan").joinpath("data/rules")
        return sorted(
            (r.name, r.read_text(encoding="utf-8"))
            for r in rules_dir.iterdir()
            if r.name.endswith(".json")
        )
    except Exception as exc:  # noqa: BLE001 - 取不到必须报错，不能静默变空
        errors.append(f"内置规则读取失败：{exc}")
        return []


def load(extra_dirs: Iterable[str] = ()) -> RuleSet:
    """加载内置规则与外部规则目录，同 id 时外部覆盖内置。"""
    errors: list[str] = []
    by_id: dict[str, Rule] = {}
    scoring: dict[str, int] = {}

    for name, text in _builtin_docs(errors):
        rules, sc = _parse_doc(name, text, errors)
        for r in rules:
            by_id[r.id] = r
        if sc:
            scoring.update(sc)

    files: list[str] = []
    for d in extra_dirs or ():
        if not d:
            continue
        if os.path.isdir(d):
            files.extend(sorted(glob.glob(os.path.join(d, "*.json"))))
        elif os.path.isfile(d):
            files.append(d)
        else:
            files.append(d)
    for path in files:
        rules, sc = _load_file(path, errors)
        for r in rules:
            by_id[r.id] = r
        if sc:
            scoring.update(sc)
    return RuleSet(rules=list(by_id.values()), scoring=scoring, errors=errors)
