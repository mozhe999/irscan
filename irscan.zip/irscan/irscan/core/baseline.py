"""基线对比：与上次采集相比新增与消失的项。"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

from .models import HostSnapshot, Severity


@dataclass
class DiffResult:
    """基线对比结果。"""

    added: dict[str, list[str]] = field(default_factory=dict)
    removed: dict[str, list[str]] = field(default_factory=dict)
    unchanged: dict[str, int] = field(default_factory=dict)
    has_baseline: bool = True

    @property
    def total_changes(self) -> int:
        return sum(len(v) for v in self.added.values()) + sum(len(v) for v in self.removed.values())

    def is_empty(self) -> bool:
        return self.total_changes == 0

_ADD_WEIGHT = {
    "listening": Severity.HIGH,
    "startup": Severity.HIGH,
    "accounts": Severity.HIGH,
    "services": Severity.MEDIUM,
    "suid_files": Severity.HIGH,
    "process_names": Severity.LOW,
}

_LABEL = {
    "listening": "监听端口",
    "startup": "持久化项",
    "accounts": "账户",
    "services": "服务",
    "suid_files": "SUID 文件",
    "process_names": "进程名",
}


def save(snapshot: HostSnapshot, path: str) -> str:
    """把当前快照存为基线文件。"""
    payload = {
        "version": 1,
        "saved_at": snapshot.collected_at.isoformat(),
        "baseline": snapshot.to_baseline(),
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)
    return path


def load(path: str) -> dict[str, object]:
    with open(path, encoding="utf-8") as fh:
        payload = json.load(fh)
    return dict(payload.get("baseline", {}))


def compare(current: HostSnapshot, baseline: dict[str, object]) -> DiffResult:
    """对比当前快照与基线，返回新增/减少项。"""
    now = current.to_baseline()
    result = DiffResult()

    for key in now:
        old = set(baseline.get(key) or [])
        new = set(now[key])  # type: ignore[arg-type]
        added = sorted(new - old)
        removed = sorted(old - new)
        if added:
            result.added[key] = added
        if removed:
            result.removed[key] = removed
        result.unchanged[key] = len(new & old)
    return result


def to_findings(diff: DiffResult, baseline_path: str = "") -> list:
    """把差异转成 Finding。"""
    from .models import Finding

    out: list[Finding] = []
    for key, items in diff.added.items():
        severity = _ADD_WEIGHT.get(key, Severity.MEDIUM)
        label = _LABEL.get(key, key)
        f = Finding(
            title=f"对比基线新增 {len(items)} 项 {label}",
            severity=severity,
            category="基线变更",
            description=(
                f"与基线{'（' + baseline_path + '）' if baseline_path else ''}相比，"
                f"{label}新增了 {len(items)} 项：{'、'.join(items[:10])}"
                f"{' 等' if len(items) > 10 else ''}。"
                f"{_why_it_matters(key)}"
            ),
            recommendation=(
                f"1) 逐项确认这些新增是否为近期的正常变更（发版、装软件、扩容）；"
                f"2) 无法归属到具体变更记录的，按可疑项处理并深入排查；"
                f"3) 若确认为攻击导致，检查其创建时间与当时的登录记录。"
            ),
            subjects=items[:12],
            source="基线对比",
            confidence="中",
        )
        for i in items[:12]:
            f.add_evidence(f"新增: {i}")
        out.append(f)

    for key, items in diff.removed.items():
        label = _LABEL.get(key, key)

        if key in ("process_names",):
            continue
        f = Finding(
            title=f"对比基线减少 {len(items)} 项 {label}",
            severity=Severity.LOW,
            category="基线变更",
            description=(
                f"{label}相比基线减少了 {len(items)} 项：{'、'.join(items[:10])}"
                f"{' 等' if len(items) > 10 else ''}。"
                f"减少通常不如新增危险，但也可能是攻击者清理痕迹后留下的痕迹。"
            ),
            recommendation="确认这些项的消失是否对应已知的卸载/下线操作。",
            subjects=items[:12],
            source="基线对比",
            confidence="低",
        )
        for i in items[:12]:
            f.add_evidence(f"减少: {i}")
        out.append(f)
    return out


def _why_it_matters(key: str) -> str:
    return {
        "listening": "新增监听端口通常意味着新开了服务或后门，是失陷后最常见的变化。",
        "startup": "新增持久化项意味着攻击者在维持访问权限，这类变更优先级最高。",
        "accounts": "新增账户可能是攻击者建立的后门账户，需立即确认归属。",
        "services": "新增服务同样可作为持久化手段，且常以 SYSTEM 权限运行。",
        "suid_files": "新增 SUID 文件是典型的提权准备工作，危害极高。",
        "process_names": "进程名变化参考意义较弱，可能是正常业务启停。",
    }.get(key, "")
