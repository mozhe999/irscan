"""扫描引擎：按 采集 → 解析 → 检测 → 时间线 → 报告 的顺序串起流水线。"""

from __future__ import annotations

import platform as platform_mod
import sys
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Callable

from . import rules as rules_mod
from .models import HostSnapshot, ScanResult, Severity
from .rules import RuleSet


@dataclass
class ScanConfig:
    """一次扫描的可调参数。"""

    fail_threshold: int = 5
    window_seconds: int = 300
    critical_threshold: int = 30
    lateral_host_threshold: int = 3
    live: bool = True
    platform_override: str = ""
    root: str = "/"
    auth_logs: list[str] = field(default_factory=list)
    web_logs: list[str] = field(default_factory=list)
    webroots: list[str] = field(default_factory=list)
    ioc_files: list[str] = field(default_factory=list)
    rules_dirs: list[str] = field(default_factory=list)
    jobs: int = 1
    event_hours: int = 24
    baseline_save: str = ""
    baseline_diff: str = ""
    timeout: int = 30

    @property
    def window(self) -> timedelta:
        return timedelta(seconds=self.window_seconds)


@dataclass
class AuthEvent:
    """归一化后的一次登录尝试，屏蔽 Linux 与 Windows 的日志格式差异。"""

    timestamp: datetime | None
    success: bool
    username: str = ""
    source_ip: str = ""
    auth_type: str = ""
    logon_type: str = ""
    raw: str = ""
    origin: str = ""


@dataclass
class ScanContext:
    """检测器之间共享的上下文。"""

    config: ScanConfig
    snapshot: HostSnapshot
    result: ScanResult
    auth_events: list[AuthEvent] = field(default_factory=list)
    weblog_lines: list[str] = field(default_factory=list)
    ruleset: RuleSet | None = None

    def __post_init__(self) -> None:
        if self.ruleset is None:
            self.ruleset = rules_mod.load(self.config.rules_dirs)

        for err in self.ruleset.errors:
            self.snapshot.note_error(f"规则加载：{err}")

    def note_error(self, msg: str) -> None:
        self.snapshot.note_error(msg)

Detector = Callable[[ScanContext], list["Finding"]]


def detect_platform(override: str = "") -> str:
    """判定主机平台。"""
    if override:
        return override.lower()
    if sys.platform.startswith("linux"):
        return "linux"
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform.startswith("darwin"):
        return "macos"
    return "unknown"


class IRScanner:
    """扫描主控：注册采集器、解析器、检测器并依次执行。"""

    def __init__(self, config: ScanConfig | None = None) -> None:
        self.config = config or ScanConfig()
        self.collectors: dict[str, Callable[[ScanConfig], HostSnapshot]] = {}
        self.parsers: list[Callable[[ScanContext], None]] = []
        self.detectors: list[Detector] = []
        self.timeline_builders: list[Callable[[ScanContext], list]] = []
        self.timeline_summarizers: list[Callable[[list], list]] = []

    def register_collector(self, name: str, fn: Callable[[ScanConfig], HostSnapshot]) -> None:
        self.collectors[name] = fn

    def register_parser(self, fn: Callable[[ScanContext], None]) -> None:
        self.parsers.append(fn)

    def register_detector(self, fn: Detector) -> None:
        self.detectors.append(fn)

    def register_timeline(self, fn: Callable[[ScanContext], list]) -> None:
        self.timeline_builders.append(fn)

    def register_timeline_summarizer(self, fn: Callable[[list], list]) -> None:
        self.timeline_summarizers.append(fn)

    def collect(self) -> HostSnapshot:
        name = detect_platform(self.config.platform_override)
        if not self.config.live:

            label = f"{name}(离线)" if self.config.platform_override else "离线"
            snap = HostSnapshot(platform=label)
            snap.note_error("已关闭实时采集，仅分析指定日志与目录")
            return snap

        fn = self.collectors.get(name)
        if fn is None:
            snap = HostSnapshot(platform=name)
            snap.hostname = platform_mod.node()
            snap.note_error(f"当前平台 {name} 暂无可用采集器，仅能做日志与目录分析")
            return snap
        return fn(self.config)

    def run(self) -> ScanResult:
        started = datetime.now()
        snapshot = self.collect()
        result = ScanResult(snapshot=snapshot, started_at=started)
        result.targets = (
            self.config.auth_logs + self.config.web_logs + self.config.webroots
        )
        ctx = ScanContext(config=self.config, snapshot=snapshot, result=result)

        for parser in self.parsers:
            try:
                parser(ctx)
            except Exception as exc:
                ctx.note_error(f"{getattr(parser, '__name__', parser)} 解析失败: {exc}")

        for detector in self.detectors:
            try:
                for finding in detector(ctx) or []:
                    result.add(finding)
            except Exception as exc:
                ctx.note_error(f"{getattr(detector, '__name__', detector)} 检测失败: {exc}")

        for builder in self.timeline_builders:
            try:
                result.timeline = builder(ctx) or result.timeline
            except Exception as exc:
                ctx.note_error(f"时间线重建失败: {exc}")
        result.timeline.sort(key=lambda e: e.timestamp)

        for summarizer in self.timeline_summarizers:
            try:
                for finding in summarizer(result.timeline) or []:
                    result.add(finding)
            except Exception as exc:
                ctx.note_error(f"时间线结论生成失败: {exc}")

        if self.config.baseline_diff:
            self._apply_baseline(result)

        result.finished_at = datetime.now()
        result.sort_findings()
        return result

    def _apply_baseline(self, result: ScanResult) -> None:
        """读取基线并比对，把差异并入结论。"""
        from . import baseline as baseline_mod

        try:
            saved = baseline_mod.load(self.config.baseline_diff)
        except (OSError, ValueError) as exc:
            result.snapshot.note_error(f"基线文件读取失败: {exc}")
            return
        diff = baseline_mod.compare(result.snapshot, saved)
        for f in baseline_mod.to_findings(diff, self.config.baseline_diff):
            result.add(f)


def risk_level(result: ScanResult) -> str:
    """整机总体结论，用于报告头部。"""
    top = result.highest
    if top >= Severity.CRITICAL:
        return "已失陷 / 高度可疑"
    if top >= Severity.HIGH:
        return "存在明确攻击行为"
    if top >= Severity.MEDIUM:
        return "存在可疑迹象，需人工复核"
    if top >= Severity.LOW:
        return "基本正常，有少量待确认项"
    return "未发现明显异常"
