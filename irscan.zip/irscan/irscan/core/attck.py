"""MITRE ATT&CK 技术映射表，数据取自 Enterprise v14。"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Technique:
    id: str
    name: str
    tactic: str
    next_step: str = ""

TECHNIQUES: dict[str, Technique] = {
    "T1595": Technique("T1595", "主动扫描", "侦察", "发现开放服务后转入漏洞利用或爆破"),
    "T1590": Technique("T1590", "收集目标网络信息", "侦察", "绘制网络拓扑，为横向移动做准备"),
    "T1078": Technique("T1078", "有效账户", "防御规避/持久化/权限提升/初始访问",
                       "使用合法凭据登录，规避基于异常行为的检测"),
    "T1133": Technique("T1133", "外部远程服务", "初始访问/持久化", "通过 VPN/RDP 等远程入口进入内网"),
    "T1190": Technique("T1190", "利用面向公网的应用漏洞", "初始访问",
                       "通过 Web 漏洞获取立足点，通常紧接着落地 Web Shell"),
    "T1204.002": Technique("T1204.002", "恶意文件", "执行",
                           "磁盘上存在情报库已标注的已知恶意样本"),
    "T1110": Technique("T1110", "暴力破解", "凭据访问", "获取口令后使用有效账户登录"),
    "T1110.001": Technique("T1110.001", "暴力破解：口令猜测", "凭据访问", "成功后再用于横向移动"),
    "T1110.003": Technique("T1110.003", "暴力破解：密码喷洒", "凭据访问",
                           "对大量账号试少量常用口令，规避锁定策略"),
    "T1552": Technique("T1552", "不安全凭据存储", "凭据访问", "从配置文件/备份中读取明文口令"),
    "T1003": Technique("T1003", "OS 凭据转储", "凭据访问", "导出哈希后用于传递哈希攻击"),
    "T1087": Technique("T1087", "账户发现", "发现", "枚举账号后选择目标做喷洒或提权"),
    "T1049": Technique("T1049", "系统网络连接发现", "发现", "确认横向移动的连通性"),
    "T1021": Technique("T1021", "远程服务", "横向移动", "沿内网扩散至更多主机"),
    "T1021.002": Technique("T1021.002", "横向移动：SMB/Windows 管理共享", "横向移动",
                           "通过共享与远程执行工具扩散"),
    "T1021.006": Technique("T1021.006", "横向移动：SMB/远程服务", "横向移动", "批量分发 payload"),
    "T1570": Technique("T1570", "横向工具转移", "横向移动", "把攻击工具复制到已控主机"),
    "T1505.003": Technique("T1505.003", "Web Shell", "持久化", "维持 Web 入口，随时可返回执行"),
    "T1547.001": Technique("T1547.001", "注册表 Run 键 / 启动文件夹", "持久化",
                           "每次开机或登录自动运行"),
    "T1053": Technique("T1053", "计划任务/作业", "持久化/执行", "定时触发执行 payload"),
    "T1543": Technique("T1543", "创建或修改系统进程", "持久化/权限提升", "以服务形式常驻"),
    "T1546.003": Technique("T1546.003", "WMI 事件订阅", "持久化/权限提升",
                           "无文件落地，事件触发时执行，极难被发现"),
    "T1574": Technique("T1574", "劫持执行流", "持久化/权限提升/防御规避",
                       "通过 LD_PRELOAD 等机制注入正常进程"),
    "T1574.009": Technique("T1574.009", "未加引号路径劫持", "权限提升",
                           "利用未加引号且含空格的服务路径插入恶意程序"),
    "T1574.010": Technique("T1574.010", "服务文件权限弱点", "权限提升",
                           "服务二进制权限过松，可被普通用户替换"),
    "T1098": Technique("T1098", "账户操纵", "持久化", "通过加公钥/NOPASSWD 维持访问"),
    "T1136": Technique("T1136", "创建账户", "持久化", "建立独立后门账户"),
    "T1548": Technique("T1548", "绕过用户账户控制", "权限提升/防御规避", "获取更高权限执行敏感操作"),
    "T1547.008": Technique("T1547.008", "SUID/SGID 二进制", "权限提升/持久化", "以文件属主权限执行"),
    "T1068": Technique("T1068", "利用漏洞提权", "权限提升", "获取 root/SYSTEM"),
    "T1070": Technique("T1070", "清除主机痕迹", "防御规避", "擦除日志后更难还原攻击链"),
    "T1562.001": Technique("T1562.001", "禁用或篡改安全工具", "防御规避", "关闭防护后长驱直入"),
    "T1036": Technique("T1036", "伪装", "防御规避", "伪装成系统进程躲避人工排查"),
    "T1027": Technique("T1027", "混淆文件或信息", "防御规避", "绕过基于明文关键字的检测"),
    "T1014": Technique("T1014", "Rootkit", "防御规避", "内核或用户态组件被替换以隐藏痕迹"),
    "T1040": Technique("T1040", "网络嗅探", "凭据访问", "抓取网络流量中的明文凭据"),
    "T1546.004": Technique("T1546.004", "Shell 配置文件", "持久化", "改写 .bashrc 等文件实现登录即执行"),
    "T1564": Technique("T1564", "隐藏工件", "防御规避", "把后门藏在不易检查的位置"),
    "T1565": Technique("T1565", "数据操纵", "防御规避/影响", "篡改解析或配置以劫持流量"),
    "T1071": Technique("T1071", "应用层协议", "命令与控制", "通过 HTTP 等常见协议回连"),
    "T1571": Technique("T1571", "非标准端口", "命令与控制", "用非常规端口承载 C2 流量以绕过策略"),
    "T1059": Technique("T1059", "命令与脚本解释器", "执行", "通过系统自带解释器执行 payload"),
    "T1059.001": Technique("T1059.001", "PowerShell", "执行", "利用系统自带工具规避白名单"),
    "T1105": Technique("T1105", "入口工具转移", "命令与控制", "下载后续攻击载荷"),
    "T1490": Technique("T1490", "抑制数据恢复", "影响", "删除备份后索要赎金"),
}


def get(technique_id: str) -> Technique | None:
    return TECHNIQUES.get(technique_id)


def describe(technique_id: str) -> str:
    """给报告用的简短描述，如 "T1110 暴力破解（凭据访问）"。"""
    t = TECHNIQUES.get(technique_id)
    if not t:
        return technique_id
    return f"{t.id} {t.name}（{t.tactic}）"


def summarize_coverage(ids: list[str]) -> list[dict[str, object]]:
    """按战术阶段汇总覆盖率，用于判断攻击停在哪一步。"""
    by_tactic: dict[str, set[str]] = {}
    for tid in ids:
        t = TECHNIQUES.get(tid)
        if not t:
            continue
        by_tactic.setdefault(t.tactic, set()).add(t.id)
    return [
        {"tactic": tactic, "techniques": sorted(techs)}
        for tactic, techs in sorted(by_tactic.items(), key=lambda kv: -len(kv[1]))
    ]
