"""通用工具：命令执行、编码解码、时间解析、IP 判断、文件遍历。"""

from __future__ import annotations

import ipaddress
import locale
import os
import re
import subprocess
from datetime import datetime, timedelta

PRIVATE_NETWORKS = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
)

_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


def run_command(
    cmd: list[str],
    timeout: int = 30,
    encoding: str = "utf-8",
) -> tuple[int, str, str]:
    """执行命令，返回 (返回码, stdout, stderr)。异常统一转成非零码，不向上抛。"""
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            timeout=timeout,
            check=False,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
    except FileNotFoundError:
        return 127, "", f"命令不存在: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, "", f"命令超时({timeout}s): {' '.join(cmd)}"
    except OSError as exc:  # pragma: no cover - 依赖具体环境
        return 126, "", f"执行失败: {exc}"

    return proc.returncode, decode_best(proc.stdout, encoding), decode_best(proc.stderr, encoding)


def decode_best(data: bytes, preferred: str = "utf-8") -> str:
    """按 UTF-8、本地编码、GBK、latin-1 的顺序解码。"""
    candidates = [preferred, "utf-8"]
    try:
        candidates.append(locale.getpreferredencoding(False))
    except Exception:  # pragma: no cover
        pass
    candidates += ["gbk", "cp936", "latin-1"]

    seen: set[str] = set()
    for enc in candidates:
        if not enc or enc.lower() in seen:
            continue
        seen.add(enc.lower())
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("utf-8", errors="replace")

_RE_SYSLOG_TIME = re.compile(r"^([A-Za-z]{3})\s+(\d{1,2})\s+(\d{2}):(\d{2}):(\d{2})")
_RE_CLF_TIME = re.compile(r"^(\d{2})/([A-Za-z]{3})/(\d{4}):(\d{2}):(\d{2}):(\d{2})")

_RE_ISO_TIME = re.compile(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})")


def parse_syslog_time(raw: str, now: datetime | None = None) -> datetime | None:
    """解析认证日志时间戳，兼容带年份的 RFC 3339 与传统 syslog。"""
    now = now or datetime.now()
    text = raw.strip()
    iso = _RE_ISO_TIME.match(text)
    if iso:
        try:
            return datetime(*(int(g) for g in iso.groups()))
        except ValueError:
            return None
    match = _RE_SYSLOG_TIME.match(text)
    if not match:
        return None
    mon = _MONTHS.get(match.group(1).lower())
    if not mon:
        return None
    day, hh, mm, ss = (int(match.group(i)) for i in (2, 3, 4, 5))
    try:
        stamp = datetime(now.year, mon, day, hh, mm, ss)
    except ValueError:
        return None

    if stamp - now > timedelta(days=1):
        try:
            stamp = stamp.replace(year=now.year - 1)
        except ValueError:  # pragma: no cover - 2月29日边界
            return None
    return stamp


def parse_clf_time(raw: str) -> datetime | None:
    """解析 Nginx / Apache 访问日志时间，如 15/Jan/2024:10:21:33 +0800。"""
    match = _RE_CLF_TIME.match(raw.strip())
    if not match:
        return None
    mon = _MONTHS.get(match.group(2).lower())
    if not mon:
        return None
    day, year, hh, mm, ss = (int(match.group(i)) for i in (1, 3, 4, 5, 6))
    try:
        return datetime(year, mon, day, hh, mm, ss)
    except ValueError:
        return None


def is_public_ip(value: str) -> bool:
    """判断是否为公网 IP，用于区分外部攻击与内网横向。"""
    try:
        addr = ipaddress.ip_address(value)
    except ValueError:
        return False
    if addr.is_loopback or addr.is_multicast or addr.is_unspecified:
        return False
    return not any(addr in net for net in PRIVATE_NETWORKS)


def iter_files(
    root: str,
    exts: tuple[str, ...] | None = None,
    max_size: int = 2 * 1024 * 1024,
    max_files: int = 20000,
) -> list[str]:
    """遍历目录下的文本文件，跳过超大文件与依赖目录。"""
    results: list[str] = []
    skip_dirs = {".git", "node_modules", "__pycache__", ".svn", "vendor", "cache"}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in skip_dirs]
        for name in filenames:
            if exts and not name.lower().endswith(exts):
                continue
            path = os.path.join(dirpath, name)
            try:
                if os.path.getsize(path) > max_size:
                    continue
            except OSError:
                continue
            results.append(path)
            if len(results) >= max_files:
                return results
    return results


def read_text(path: str, encoding: str = "utf-8") -> str:
    """读取文本文件，编码不匹配时自动降级。"""
    with open(path, "rb") as fh:
        data = fh.read()
    return decode_best(data, encoding)


def iter_lines(path: str, chunk_size: int = 1024 * 1024):
    """按块流式读取，内存占用恒定；跨块的不完整行留到下一块拼接。"""
    with open(path, "rb") as fh:
        remainder = b""
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            chunk = remainder + chunk
            idx = chunk.rfind(b"\n")
            if idx == -1:
                remainder = chunk
                continue
            remainder = chunk[idx + 1:]
            yield from decode_best(chunk[:idx]).splitlines()
        if remainder:
            yield from decode_best(remainder).splitlines()
