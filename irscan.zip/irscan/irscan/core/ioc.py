"""IOC 情报解析：哈希、文件名、内容正则。

两种行格式可混在同一文件：

    275a021bbf...fd0f                        每行一个哈希，# 后可跟说明
    sha256;275a021bbf...fd0f;EICAR 测试文件   Loki 风格：类型;值;描述
"""

from __future__ import annotations

import hashlib
import os
import re
from dataclasses import dataclass, field

MAX_HASH_BYTES = 64 * 1024 * 1024

MAX_TEXT_BYTES = 8 * 1024 * 1024

HASH_KINDS = {"md5": 32, "sha1": 40, "sha256": 64}
_HEX = set("0123456789abcdef")


@dataclass
class IOC:
    kind: str
    value: str
    description: str = ""

    @property
    def regex(self) -> re.Pattern[str] | None:
        if self.kind in ("regex", "filename"):
            try:
                return re.compile(self.value, re.I)
            except re.error:
                return None
        return None


@dataclass
class IOCSet:
    hashes: dict[str, str] = field(default_factory=dict)
    filenames: list[IOC] = field(default_factory=list)
    content: list[IOC] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.hashes) + len(self.filenames) + len(self.content)

    def merge(self, other: IOCSet) -> None:
        self.hashes.update(other.hashes)
        self.filenames.extend(other.filenames)
        self.content.extend(other.content)
        self.errors.extend(other.errors)


def _is_hash(value: str, length: int | None = None) -> bool:
    return (length is None or len(value) == length) and all(c in _HEX for c in value)


def load_ioc_file(path: str) -> IOCSet:
    """加载单个情报文件。文件不存在时返回空集，由调用方记录盲区。"""
    out = IOCSet()
    if not os.path.isfile(path):
        return out
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            lines = fh.readlines()
    except OSError as exc:
        out.errors.append(f"{path} 读取失败：{exc}")
        return out

    for lineno, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue

        if ";" in line:
            kind, _, rest = line.partition(";")
            kind = kind.strip().lower()
            value, _, desc = rest.partition(";")
            value = value.strip()
            desc = desc.strip()
            if kind in HASH_KINDS:
                if _is_hash(value.lower(), HASH_KINDS[kind]):
                    out.hashes[value.lower()] = desc or "已知恶意样本"
                else:
                    out.errors.append(f"{path}:{lineno} 哈希长度与类型 {kind} 不符，已跳过")
            elif kind == "regex":
                ioc = IOC("regex", value, desc)
                if ioc.regex is None:
                    out.errors.append(f"{path}:{lineno} 正则无法编译，已跳过")
                else:
                    out.content.append(ioc)
            elif kind == "filename":
                ioc = IOC("filename", value, desc)
                if ioc.regex is None:
                    out.errors.append(f"{path}:{lineno} 文件名正则无法编译，已跳过")
                else:
                    out.filenames.append(ioc)
            else:
                out.errors.append(f"{path}:{lineno} 不支持的 IOC 类型 {kind}，已跳过")
            continue

        for sep in ("#", ","):
            if sep in line:
                line, _, note = line.partition(sep)
                line = line.strip()
                break
        else:
            note = ""
        token = line.split()[0].lower() if line.split() else ""

        if token and len(token) in HASH_KINDS.values() and _is_hash(token):
            out.hashes[token] = note.strip() or "已知恶意样本"
    return out


def file_hashes(path: str) -> tuple[str, str, str] | None:
    """返回 (md5, sha1, sha256)，无法读取时返回 None。"""
    try:
        size = os.path.getsize(path)
    except OSError:
        return None
    if size > MAX_HASH_BYTES:
        return None

    md5 = hashlib.md5()
    sha1 = hashlib.sha1()
    sha256 = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b""):
                md5.update(chunk)
                sha1.update(chunk)
                sha256.update(chunk)
    except OSError:
        return None
    return md5.hexdigest(), sha1.hexdigest(), sha256.hexdigest()
