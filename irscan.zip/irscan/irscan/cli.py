"""命令行入口。

用法：
    python -m irscan                                   排查当前主机
    python -m irscan --webroot /var/www/html -o r.html  指定站点目录与输出
    python -m irscan --offline --auth-log samples/auth.log  只分析给定文件
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from . import __version__
from .core import baseline as baseline_mod
from .core.attck import summarize_coverage
from .core.engine import IRScanner, ScanConfig, detect_platform, risk_level
from .collectors import LinuxCollector, MacOSCollector, WindowsCollector
from .detectors import DETECTORS, TIMELINE_BUILDERS, TIMELINE_SUMMARIZERS
from .detectors import timeline as timeline_mod
from .parsers import parse_auth_files, parse_web_logs, parse_windows_events
from .report import render_console_summary, write_markdown, write_report


def build_default_scanner(config: ScanConfig) -> IRScanner:
    """装配一条完整的检测流水线。"""
    scanner = IRScanner(config)

    scanner.register_collector("linux", lambda cfg: LinuxCollector(cfg)())
    scanner.register_collector("windows", lambda cfg: WindowsCollector(cfg)())
    scanner.register_collector("macos", lambda cfg: MacOSCollector(cfg)())

    scanner.register_parser(parse_auth_files)
    scanner.register_parser(parse_windows_events)
    scanner.register_parser(parse_web_logs)

    for detector in DETECTORS:
        scanner.register_detector(detector)
    for builder in TIMELINE_BUILDERS:
        scanner.register_timeline(builder)
    for summarizer in TIMELINE_SUMMARIZERS:
        scanner.register_timeline_summarizer(summarizer)
    return scanner


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="irscan",
        description="应急响应一键排查工具（Linux + Windows，零第三方依赖）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("-V", "--version", action="version", version=f"irscan {__version__}")
    p.add_argument("--auth-log", action="append", default=[], metavar="PATH",
                   help="认证日志文件，可重复（Linux auth.log/secure）")
    p.add_argument("--web-log", action="append", default=[], metavar="PATH",
                   help="Web 访问日志文件，可重复")
    p.add_argument("--webroot", action="append", default=[], metavar="DIR",
                   help="网站根目录，可重复（做 webshell 扫描）")
    p.add_argument("--ioc", action="append", default=[], metavar="PATH",
                   help="外部 IOC 情报文件，可重复；支持每行一个哈希，"
                        "也支持 Loki 的 类型;值;描述（md5/sha1/sha256/regex/filename）；"
                        "不给则不跑 IOC 比对")
    p.add_argument("--rules", action="append", default=[], metavar="PATH",
                   help="额外检测规则文件或目录（JSON），可重复；"
                        "同 id 的规则覆盖内置规则")
    p.add_argument("--jobs", type=int, default=1, metavar="N",
                   help="文件扫描的并发读线程数，默认 1（串行）。"
                        "站点目录文件多时调到 4~8 可明显加速；"
                        "受害主机已高负载时建议保持 1")
    p.add_argument("--list-rules", action="store_true",
                   help="列出已加载的检测规则后退出")
    p.add_argument("-o", "--output", default="irscan_report.html", metavar="PATH",
                   help="HTML 报告输出路径（默认 irscan_report.html）")
    p.add_argument("--json", metavar="PATH", help="同时导出 JSON 结果")
    p.add_argument("--markdown", metavar="PATH",
                   help="同时导出 Markdown 报告（便于贴工单/二次编辑）")
    p.add_argument("--no-html", action="store_true", help="不生成 HTML 报告")
    p.add_argument("--offline", action="store_true",
                   help="关闭实时采集，仅分析给定的日志与目录")
    p.add_argument("--platform", choices=("linux", "windows", "macos"), default="",
                   help="强制指定平台（默认自动检测）")
    p.add_argument("--root", metavar="DIR", default="/",
                   help="系统根目录，指向挂载的证据盘即可做离线取证分析（默认 /）")
    p.add_argument("--event-hours", type=int, default=24,
                   help="Windows 安全日志回溯小时数（默认 24）")
    p.add_argument("--fail-threshold", type=int, default=5,
                   help="爆破判定：窗口内失败次数阈值（默认 5）")
    p.add_argument("--window", type=int, default=300,
                   help="爆破判定滑动窗口秒数（默认 300）")
    p.add_argument("--critical-threshold", type=int, default=30,
                   help="窗口内失败达到此值直接判严重（默认 30）")
    p.add_argument("--lateral-hosts", type=int, default=3,
                   help="横向移动：同一账号网络登录来源主机数阈值（默认 3）")
    p.add_argument("--baseline-save", metavar="PATH",
                   help="把本次采集结果存为基线文件")
    p.add_argument("--baseline-diff", metavar="PATH",
                   help="与指定的基线文件对比，只报告新增/减少的项")
    p.add_argument("--timeline", action="store_true",
                   help="在终端打印攻击时间线")
    p.add_argument("--timeout", type=int, default=30, help="单条命令超时秒数")
    p.add_argument("--title", default="应急响应排查报告", help="报告标题")
    p.add_argument("-q", "--quiet", action="store_true", help="只输出结论摘要")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.list_rules:
        from .core import rules as rules_mod
        rs = rules_mod.load(args.rules)
        print(f"已加载 {len(rs.rules)} 条规则：{rs.summary()}")
        for r in sorted(rs.rules, key=lambda x: (x.targets, x.id)):
            flag = "" if r.enabled else "  [已停用]"
            print(f"  {','.join(r.targets) or '-':12s} {r.id:34s} "
                  f"{r.level:8s}{r.title}{flag}")
        for err in rs.errors:
            print(f"  ! {err}")
        return 0

    config = ScanConfig(
        fail_threshold=args.fail_threshold,
        window_seconds=args.window,
        critical_threshold=args.critical_threshold,
        lateral_host_threshold=args.lateral_hosts,
        live=not args.offline,
        platform_override=args.platform,
        root=args.root or "/",
        auth_logs=args.auth_log,
        web_logs=args.web_log,
        webroots=args.webroot,
        ioc_files=args.ioc,
        rules_dirs=args.rules,
        jobs=args.jobs,
        event_hours=args.event_hours,
        baseline_save=args.baseline_save,
        baseline_diff=args.baseline_diff,
        timeout=args.timeout,
    )

    if not args.quiet:
        plat = config.platform_override or detect_platform()
        print(f"[*] irscan 启动：平台 {plat}"
              f"{'（离线模式）' if args.offline else ''}")
        if config.live and plat == "windows" and not _is_admin_windows():
            print("[!] 当前非管理员权限，Windows 安全日志可能读取失败，"
                  "4624/4625 相关检测会失效（报告中会标注盲区）")

    scanner = build_default_scanner(config)
    result = scanner.run()

    if config.baseline_save:
        path = baseline_mod.save(result.snapshot, config.baseline_save)
        print(f"[*] 基线已保存：{os.path.abspath(path)}")

    print(render_console_summary(result))

    if args.timeline:
        print("\n--- 攻击时间线 ---")
        print(timeline_mod.render_text(result.timeline))

    if not args.quiet:
        coverage = summarize_coverage([f.technique for f in result.findings if f.technique])
        if coverage:
            print("\n--- ATT&CK 战术覆盖 ---")
            for item in coverage:
                print(f"  {item['tactic']}: {' '.join(item['techniques'])}")  # type: ignore[arg-type]

    if not args.no_html:
        out = write_report(result, args.output, title=args.title)
        if not args.quiet:
            print(f"\n[*] HTML 报告已生成：{os.path.abspath(out)}")

    if args.markdown:
        write_markdown(result, args.markdown, title=args.title)
        if not args.quiet:
            print(f"[*] Markdown 报告已生成：{os.path.abspath(args.markdown)}")

    if args.json:
        payload = {
            "host": result.snapshot.hostname,
            "platform": result.snapshot.platform,
            "collected_at": result.snapshot.collected_at.isoformat(),
            "risk": risk_level(result),
            "counts": result.counts,
            "errors": result.snapshot.errors,
            "findings": [f.to_dict() for f in result.findings],
            "collected": result.snapshot.summary,
        }
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=2)
        if not args.quiet:
            print(f"[*] JSON 结果已导出：{os.path.abspath(args.json)}")

    if result.counts["CRITICAL"]:
        return 2
    if result.counts["HIGH"]:
        return 1
    return 0


def _is_admin_windows() -> bool:
    """当前进程是否具备 Windows 管理员权限。"""
    if os.name != "nt":
        return True
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False

if __name__ == "__main__":
    sys.exit(main())
