"""HTML 报告渲染：不使用模板引擎，所有输出经 HTML 转义。"""

from __future__ import annotations

import html
from datetime import datetime

from .. import __version__ as version
from ..core.attck import describe, summarize_coverage
from ..core.engine import risk_level
from ..core.models import ScanResult

_CSS = """
:root{
  --bg:#f6f7f9; --card:#ffffff; --line:#e3e6ea; --text:#1f2328;
  --muted:#6b7280; --accent:#2563eb;
  --crit:#b91c1c; --high:#ea580c; --med:#ca8a04; --low:#0891b2; --info:#6b7280;
}
*{box-sizing:border-box}
body{margin:0;padding:24px;background:var(--bg);color:var(--text);
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC",
  "Microsoft YaHei",Helvetica,Arial,sans-serif;line-height:1.6;font-size:14px}
.wrap{max-width:1100px;margin:0 auto}
h1{font-size:22px;margin:0 0 4px}
h2{font-size:16px;margin:28px 0 12px;padding-bottom:6px;border-bottom:2px solid var(--line)}
.sub{color:var(--muted);font-size:13px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;
  padding:18px 20px;margin-bottom:16px}
.verdict{display:flex;align-items:center;gap:16px;flex-wrap:wrap}
.verdict .label{font-size:18px;font-weight:600}
.badge{display:inline-block;padding:3px 10px;border-radius:999px;color:#fff;
  font-size:12px;font-weight:600}
.badge.critical{background:var(--crit)} .badge.high{background:var(--high)}
.badge.medium{background:var(--med)} .badge.low{background:var(--low)}
.badge.info{background:var(--info)}
.stats{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
.stat{flex:1;min-width:88px;background:var(--bg);border:1px solid var(--line);
  border-radius:8px;padding:10px 12px;text-align:center}
.stat .n{font-size:20px;font-weight:700}
.stat .t{font-size:12px;color:var(--muted)}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{background:var(--bg);font-weight:600;width:150px}
.finding{border-left:4px solid var(--info);background:var(--card);
  border:1px solid var(--line);border-left-width:4px;border-radius:8px;
  padding:14px 16px;margin-bottom:12px}
.finding.critical{border-left-color:var(--crit)}
.finding.high{border-left-color:var(--high)}
.finding.medium{border-left-color:var(--med)}
.finding.low{border-left-color:var(--low)}
.finding .head{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:6px}
.finding .title{font-weight:600;font-size:15px}
.finding .meta{font-size:12px;color:var(--muted)}
.finding .desc{margin:6px 0}
.finding .rec{background:#fffbeb;border:1px solid #fde68a;border-radius:6px;
  padding:8px 12px;margin-top:8px;font-size:13px}
.finding .fp{background:#f1f5f9;border:1px solid #cbd5e1;border-radius:6px;
  padding:6px 12px;margin-top:6px;font-size:12px;color:#475569}
pre{background:#0f172a;color:#e2e8f0;padding:10px 12px;border-radius:6px;
  overflow-x:auto;font-size:12px;line-height:1.5;margin:8px 0 0;white-space:pre-wrap;
  word-break:break-all}
details{margin-top:8px}
summary{cursor:pointer;color:var(--accent);font-size:13px}
ul.ev{margin:6px 0 0;padding-left:18px;font-size:12px;color:#374151}
.chips{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
.chip{background:var(--bg);border:1px solid var(--line);border-radius:4px;
  padding:2px 8px;font-size:12px;color:#374151}
.warn{background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:10px 14px;
  margin-top:10px;font-size:13px;color:#991b1b}
.foot{color:var(--muted);font-size:12px;text-align:center;padding:20px 0 8px}
/* --- 时间线 --- */
.tl{position:relative;padding-left:22px;margin-top:8px}
.tl::before{content:"";position:absolute;left:6px;top:6px;bottom:6px;width:2px;
  background:var(--line)}
.tl-item{position:relative;padding:6px 0 10px}
.tl-item::before{content:"";position:absolute;left:-20px;top:12px;width:10px;height:10px;
  border-radius:50%;background:var(--info);border:2px solid #fff;box-shadow:0 0 0 2px var(--line)}
.tl-item.critical::before{background:var(--crit)}
.tl-item.high::before{background:var(--high)}
.tl-item.medium::before{background:var(--med)}
.tl-item.low::before{background:var(--low)}
.tl-time{font-size:12px;color:var(--muted);font-variant-numeric:tabular-nums}
.tl-label{font-weight:600;font-size:13px}
.tl-detail{font-size:12px;color:#374151;word-break:break-all;margin-top:2px}
/* --- ATT&CK --- */
.attck{display:flex;flex-direction:column;gap:8px;margin-top:8px}
.attck-row{display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap}
.attck-tactic{min-width:150px;font-weight:600;font-size:13px;color:#374151}
.tech{background:#eef2ff;border:1px solid #c7d2fe;color:#3730a3;border-radius:4px;
  padding:2px 8px;font-size:12px;font-variant-numeric:tabular-nums}
.tag-tech{background:#eef2ff;border:1px solid #c7d2fe;color:#3730a3;border-radius:4px;
  padding:1px 7px;font-size:11px;margin-left:6px}
"""

_JS = """
document.querySelectorAll('[data-filter]').forEach(function(btn){
  btn.addEventListener('click', function(){
    var lv = btn.getAttribute('data-filter');
    document.querySelectorAll('.finding').forEach(function(el){
      el.style.display = (lv === 'all' || el.classList.contains(lv)) ? '' : 'none';
    });
    document.querySelectorAll('[data-filter]').forEach(function(b){
      b.style.fontWeight = (b === btn) ? '700' : '400';
    });
  });
});
"""


def esc(value: object) -> str:
    return html.escape(str(value if value is not None else ""))


def render(result: ScanResult, title: str = "应急响应排查报告") -> str:
    """渲染完整 HTML 报告。"""
    snap = result.snapshot
    counts = result.counts
    level = risk_level(result)
    top = result.highest
    sev_class = top.name.lower()

    parts: list[str] = [
        "<!DOCTYPE html><html lang='zh-CN'><head><meta charset='utf-8'>",
        "<meta name='viewport' content='width=device-width,initial-scale=1'>",
        f"<title>{esc(title)}</title><style>{_CSS}</style></head><body><div class='wrap'>",
        f"<h1>{esc(title)}</h1>",
        f"<div class='sub'>主机 {esc(snap.hostname or '未知')} · 平台 {esc(snap.platform)} · "
        f"生成于 {esc(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))} · "
        f"耗时 {result.duration:.1f}s</div>",
    ]

    parts.append("<div class='card'><div class='verdict'>")
    parts.append(f"<span class='badge {sev_class}'>{esc(top.label)}</span>")
    parts.append(f"<span class='label'>{esc(level)}</span></div>")
    parts.append(
        "<div class='stats'>"
        + "".join(
            f"<div class='stat'><div class='n'>{counts[name]}</div><div class='t'>{esc(lbl)}</div></div>"
            for name, lbl in (
                ("CRITICAL", "严重"), ("HIGH", "高危"),
                ("MEDIUM", "中危"), ("LOW", "低危"), ("INFO", "信息"),
            )
        )
        + "</div>"
    )
    if snap.errors:
        parts.append(
            "<div class='warn'><b>采集盲区（以下项目未采集到，结论不代表这些方面没问题）：</b><ul>"
            + "".join(f"<li>{esc(e)}</li>" for e in snap.errors)
            + "</ul></div>"
        )
    parts.append("</div>")

    parts.append("<h2>一、采集概况</h2><div class='card'><table>")
    parts.append(f"<tr><th>主机 / 平台</th><td>{esc(snap.hostname or '未知')} / {esc(snap.platform)}</td></tr>")
    parts.append(f"<tr><th>采集时间</th><td>{esc(snap.collected_at.strftime('%Y-%m-%d %H:%M:%S'))}</td></tr>")
    parts.append(
        "<tr><th>采集条目</th><td>"
        + "；".join(f"{esc(k)} {v}" for k, v in snap.summary.items())
        + "</td></tr>"
    )
    if result.targets:
        parts.append(f"<tr><th>分析目标</th><td>{esc('；'.join(result.targets))}</td></tr>")
    parts.append("</table></div>")

    parts.append("<h2>二、检测结论</h2>")
    if not result.findings:
        parts.append(
            "<div class='card'>本次未在已采集范围内发现明显异常。"
            "请注意上方「采集盲区」，缺失的数据源需另行核查。</div>"
        )
    else:
        parts.append(
            "<div class='card'><div class='chips'>"
            "<button data-filter='all' style='border:none;background:none;cursor:pointer;"
            "color:var(--accent);font-weight:700'>全部</button>"
            + "".join(
                f"<button data-filter='{n.lower()}' style='border:none;background:none;"
                f"cursor:pointer;color:var(--accent)'>{esc(lbl)}({counts[n]})</button>"
                for n, lbl in (("CRITICAL", "严重"), ("HIGH", "高危"),
                               ("MEDIUM", "中危"), ("LOW", "低危"))
            )
            + "</div></div>"
        )
        for f in result.findings:
            cls = f.severity.name.lower()
            parts.append(f"<div class='finding {cls}'>")
            parts.append("<div class='head'>")
            parts.append(f"<span class='badge {cls}'>{esc(f.severity.label)}</span>")
            parts.append(f"<span class='title'>{esc(f.title)}</span>")
            parts.append(f"<span class='meta'>{esc(f.category)} · 置信度 {esc(f.confidence)}</span>")
            if f.technique:
                parts.append(f"<span class='tag-tech'>{esc(describe(f.technique))}</span>")
            parts.append("</div>")
            if f.description:
                parts.append(f"<div class='desc'>{esc(f.description)}</div>")
            if f.subjects:
                parts.append(
                    "<div class='chips'>"
                    + "".join(f"<span class='chip'>{esc(s)}</span>" for s in f.subjects[:12])
                    + "</div>"
                )
            if f.recommendation:
                parts.append(f"<div class='rec'><b>处置建议：</b>{esc(f.recommendation)}</div>")
            if f.falsepositives:
                parts.append(
                    "<div class='fp'><b>已知的误报场景：</b>"
                    + esc("；".join(f.falsepositives))
                    + "</div>"
                )
            if f.evidence:
                parts.append("<details><summary>展开证据（{} 条）</summary><ul class='ev'>".format(len(f.evidence)))
                parts.append("".join(f"<li>{esc(e)}</li>" for e in f.evidence))
                parts.append("</ul><pre>" + "\n".join(esc(e) for e in f.evidence[:10]) + "</pre></details>")
            parts.append(f"<div class='meta' style='margin-top:6px'>来源：{esc(f.source)}"
                         + (f" · 时间：{esc(f.occurred_at.strftime('%Y-%m-%d %H:%M:%S'))}"
                            if f.occurred_at else "")
                         + "</div>")
            parts.append("</div>")

    parts.append("<h2>三、攻击时间线</h2>")
    if not result.timeline:
        parts.append("<div class='card'>未采集到带时间戳的事件（可能缺少日志或权限）。</div>")
    else:
        parts.append(
            "<div class='card'><div class='sub'>按时间顺序还原关键动作。"
            "密集的同类请求已合并为一段并标注次数，"
            "<b>红色节点为攻击链闭合点</b>（此前有失败记录却登录成功）。</div>"
            "<div class='tl'>"
        )
        for e in result.timeline:
            cls = e.severity.name.lower()
            parts.append(f"<div class='tl-item {cls}'>")
            parts.append(
                f"<div><span class='tl-time'>{esc(e.timestamp.strftime('%m-%d %H:%M:%S'))}</span> "
                f"<span class='badge {cls}' style='margin-left:6px'>{esc(e.severity.label)}</span> "
                f"<span class='tl-label'>{esc(e.label)}</span></div>"
            )
            if e.detail:
                parts.append(f"<div class='tl-detail'>{esc(e.detail)}</div>")
            parts.append(f"<div class='tl-detail' style='color:var(--muted)'>来源：{esc(e.source)}</div>")
            parts.append("</div>")
        parts.append("</div></div>")

    parts.append("<h2>四、ATT&CK 攻击链覆盖</h2>")
    coverage = summarize_coverage([f.technique for f in result.findings if f.technique])
    if not coverage:
        parts.append("<div class='card'>本次结论未映射到具体 ATT&CK 技术。</div>")
    else:
        parts.append(
            "<div class='card'><div class='sub'>"
            "已覆盖的战术阶段。若「凭据访问」已命中而「横向移动」尚未出现，"
            "说明攻击仍停留在单点。</div><div class='attck'>"
        )
        for item in coverage:
            techs = "".join(f"<span class='tech'>{esc(t)}</span>" for t in item["techniques"])  # type: ignore[union-attr]
            parts.append(
                f"<div class='attck-row'><div class='attck-tactic'>{esc(item['tactic'])}</div>"
                f"<div>{techs}</div></div>"
            )
        parts.append("</div></div>")

    parts.append("<h2>五、说明与局限性</h2><div class='card'><ul>")
    parts.append("<li>本工具只做<b>线索提示</b>，所有结论需人工复核后才能作为处置依据。</li>")
    parts.append("<li>报告中的「未采集到」不代表「没问题」，例如缺少管理员权限时"
                 "Windows 安全日志无法读取，爆破检测将完全失效。</li>")
    parts.append("<li>攻击者可能已篡改日志或使用 rootkit 隐藏进程，"
                 "高度怀疑时应结合内存取证与网络流量分析。</li>")
    parts.append("<li>Webshell 采用加权评分模型，业务代码中若存在动态执行逻辑可能误报，"
                 "请以人工阅读源码为准。</li>")
    parts.append("</ul></div>")

    parts.append(
        f"<div class='foot'>irscan v{esc(version)} · 生成时间 "
        f"{esc(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}</div>"
    )
    parts.append(f"</div><script>{_JS}</script></body></html>")
    return "".join(parts)


def write_report(result: ScanResult, path: str, title: str = "应急响应排查报告") -> str:
    """渲染并落盘，返回写入路径。"""
    content = render(result, title=title)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    return path


def render_markdown(result: ScanResult, title: str = "应急响应排查报告") -> str:
    """Markdown 版报告，便于贴进工单或文档系统。"""
    snap = result.snapshot
    lines = [
        f"# {title}",
        "",
        f"- **主机**：{snap.hostname or '未知'}（{snap.platform}）",
        f"- **生成时间**：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"- **总体结论**：{risk_level(result)}",
        f"- **耗时**：{result.duration:.1f}s",
        "",
        "## 结论统计",
        "",
        "| 严重 | 高危 | 中危 | 低危 |",
        "|---|---|---|---|",
        f"| {result.counts['CRITICAL']} | {result.counts['HIGH']} "
        f"| {result.counts['MEDIUM']} | {result.counts['LOW']} |",
        "",
    ]

    if snap.errors:
        lines += ["## 采集盲区", ""]
        lines += [f"- {e}" for e in snap.errors]
        lines.append("")

    if result.findings:
        lines += ["## 检测结论", ""]
        for f in result.findings:
            tech = f" `{describe(f.technique)}`" if f.technique else ""
            lines.append(f"### [{f.severity.label}] {f.title}{tech}")
            lines.append("")
            lines.append(f"- **类别**：{f.category}　**置信度**：{f.confidence}")
            if f.description:
                lines.append(f"- **说明**：{f.description}")
            if f.recommendation:
                lines.append(f"- **处置建议**：{f.recommendation}")
            if f.falsepositives:
                lines.append(f"- **已知的误报场景**：{'；'.join(f.falsepositives)}")
            if f.evidence:
                lines.append("- **证据**：")
                lines += [f"  - {e}" for e in f.evidence[:8]]
            lines.append("")

    if result.timeline:
        lines += ["## 攻击时间线", "", "| 时间 | 等级 | 事件 |", "|---|---|---|"]
        for e in result.timeline:
            detail = e.detail.replace("|", "\\|") if e.detail else ""
            lines.append(
                f"| {e.timestamp.strftime('%m-%d %H:%M:%S')} | {e.severity.label} "
                f"| {e.label}"
                + (f"<br><sub>{detail}</sub>" if detail else "")
                + " |"
            )
        lines.append("")

    lines += [
        "## 局限性",
        "",
        "- 本工具只做线索提示，所有结论需人工复核后方可作为处置依据。",
        "- 报告中的「未采集到」不等于「没问题」。",
        "- 攻击者可能已篡改日志或部署 rootkit，高度怀疑时应结合内存取证与流量分析。",
        "",
    ]
    return "\n".join(lines)


def write_markdown(result: ScanResult, path: str, title: str = "应急响应排查报告") -> str:
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(render_markdown(result, title=title))
    return path


def render_console_summary(result: ScanResult) -> str:
    """命令行摘要。"""
    lines = [
        "",
        "=" * 62,
        f"  应急排查结论：{risk_level(result)}",
        f"  主机 {result.snapshot.hostname or '未知'} "
        f"({result.snapshot.platform})   耗时 {result.duration:.1f}s",
        "=" * 62,
    ]
    for name, lbl in (("CRITICAL", "严重"), ("HIGH", "高危"),
                      ("MEDIUM", "中危"), ("LOW", "低危"), ("INFO", "信息")):
        lines.append(f"  {lbl}：{result.counts[name]}")
    lines.append("-" * 62)
    for f in result.findings:
        lines.append(f"  [{f.severity.label}] {f.title}")
    if not result.findings:
        lines.append("  （未发现异常）")
    if result.snapshot.errors:
        lines.append("-" * 62)
        lines.append("  采集盲区：")
        for e in result.snapshot.errors:
            lines.append(f"    - {e}")
    lines.append("=" * 62)
    return "\n".join(lines)
