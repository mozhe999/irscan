"""报告渲染层：HTML 报告 + 命令行摘要。"""

from .html_report import (
    render,
    render_console_summary,
    render_markdown,
    write_markdown,
    write_report,
)

__all__ = [
    "render",
    "render_console_summary",
    "render_markdown",
    "write_markdown",
    "write_report",
]
