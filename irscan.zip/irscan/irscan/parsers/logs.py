"""日志解析：把不同来源的登录记录归一化成 AuthEvent。"""

from __future__ import annotations

import os
import re

from ..core.engine import AuthEvent, ScanContext
from ..core.utils import iter_lines, parse_clf_time, parse_syslog_time

DEFAULT_AUTH_LOGS = ("/var/log/auth.log", "/var/log/secure")

RE_FAILED_PASSWORD = re.compile(
    r"Failed password for (?:invalid user )?(?P<user>\S+) from (?P<ip>\S+)"
)
RE_FAILED_PUBLICKEY = re.compile(
    r"Failed publickey for (?:invalid user )?(?P<user>\S+) from (?P<ip>\S+)"
)
RE_INVALID_USER = re.compile(r"Invalid user (?P<user>\S+) from (?P<ip>\S+)")
RE_ACCEPTED = re.compile(
    r"Accepted (?P<method>\w+) for (?P<user>\S+) from (?P<ip>\S+)"
)
RE_PAM_FAILURE = re.compile(
    r"authentication failure;.*rhost=(?P<ip>\S+)(?:.*user=(?P<user>\S+))?"
)
RE_MAX_AUTH = re.compile(
    r"error: maximum authentication attempts exceeded for "
    r"(?:invalid user )?(?P<user>\S+) from (?P<ip>\S+)"
)


def parse_line(line: str, origin: str) -> AuthEvent | None:
    """解析一行 auth.log，失败返回 None。"""
    if not line.strip():
        return None
    stamp = parse_syslog_time(line[:32])

    m = RE_ACCEPTED.search(line)
    if m:
        return AuthEvent(
            timestamp=stamp, success=True, username=m.group("user"),
            source_ip=_clean_ip(m.group("ip")), auth_type=m.group("method"),
            raw=line.rstrip(), origin=origin,
        )

    for pattern, kind in (
        (RE_FAILED_PASSWORD, "password"),
        (RE_FAILED_PUBLICKEY, "publickey"),
        (RE_MAX_AUTH, "password"),
        (RE_INVALID_USER, "invalid_user"),
    ):
        m = pattern.search(line)
        if m:
            return AuthEvent(
                timestamp=stamp, success=False, username=m.group("user"),
                source_ip=_clean_ip(m.group("ip")), auth_type=kind,
                raw=line.rstrip(), origin=origin,
            )

    m = RE_PAM_FAILURE.search(line)
    if m:
        return AuthEvent(
            timestamp=stamp, success=False, username=m.group("user") or "",
            source_ip=_clean_ip(m.group("ip")), auth_type="pam",
            raw=line.rstrip(), origin=origin,
        )
    return None


def _clean_ip(value: str) -> str:
    value = (value or "").strip()

    if value.lower().startswith("::ffff:"):
        return value[7:]
    return value


def parse_auth_files(ctx: ScanContext) -> None:
    """引擎注册用：读取所有 auth 日志，填充 ctx.auth_events。"""
    paths = list(ctx.config.auth_logs)
    if not paths and ctx.config.live:
        paths = [p for p in DEFAULT_AUTH_LOGS if os.path.isfile(p)]
        if not paths:
            return
    for path in paths:
        if not os.path.isfile(path):
            ctx.note_error(f"认证日志不存在: {path}")
            continue
        try:

            for line in iter_lines(path):
                event = parse_line(line, origin=path)
                if event:
                    ctx.auth_events.append(event)
        except OSError as exc:
            ctx.note_error(f"读取失败 {path}: {exc}")
            continue


def parse_windows_events(ctx: ScanContext) -> None:
    """把 Windows 4624 / 4625 事件转成 AuthEvent。"""
    for rec in ctx.snapshot.events:
        if rec.event_id not in (4624, 4625):
            continue
        fields = rec.fields
        ip = _clean_ip(fields.get("IpAddress", ""))
        user = fields.get("TargetUserName", "")
        logon_type = fields.get("LogonType", "")

        ctx.auth_events.append(AuthEvent(
            timestamp=rec.timestamp,
            success=rec.event_id == 4624,
            username=user,
            source_ip=ip,
            auth_type=fields.get("AuthenticationPackageName", ""),
            logon_type=logon_type,
            raw=f"EventID={rec.event_id} user={user} ip={ip} type={logon_type}",
            origin="Windows 安全日志",
        ))


def parse_web_logs(ctx: ScanContext) -> None:
    """读取 Web 访问日志原始行，交给 weblog 检测器。"""
    for path in ctx.config.web_logs:
        if not os.path.isfile(path):
            ctx.note_error(f"Web 日志不存在: {path}")
            continue
        try:

            ctx.weblog_lines.extend(iter_lines(path))
        except OSError as exc:
            ctx.note_error(f"读取失败 {path}: {exc}")

_RE_CLF = re.compile(
    r'^(?P<ip>\S+) \S+ \S+ \[(?P<time>[^\]]+)\] "(?P<method>\S+) (?P<uri>\S+) [^"]*" '
    r'(?P<status>\d{3})'
)

_RE_UA = re.compile(r'"([^"]*)"\s*$')


def parse_clf_line(line: str, want_ts: bool = True, want_ua: bool = True) -> dict[str, str] | None:
    """解析一行 combined / common 格式的访问日志。"""
    m = _RE_CLF.match(line)
    if not m:
        return None
    ua = ""
    if want_ua:
        ua_m = _RE_UA.search(line)
        ua = ua_m.group(1) if ua_m else ""
    return {
        "ip": m.group("ip"),
        "time": m.group("time"),
        "method": m.group("method"),
        "uri": m.group("uri"),
        "status": m.group("status"),
        "ua": ua,
        "ts": parse_clf_time(m.group("time")) if want_ts else None,
        "raw": line.rstrip(),
    }
