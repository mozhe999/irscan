"""打包为单文件 dist/irscan.pyz：python irscan.pyz 等价于 python -m irscan。"""

from __future__ import annotations

import shutil
import sys
import tempfile
import zipapp
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "irscan"
DIST = ROOT / "dist"
OUT = DIST / "irscan.pyz"

_MAIN = "import sys\nfrom irscan.cli import main\nsys.exit(main())\n"

_FIXED_TIME = (2024, 1, 15, 0, 0, 0)


def _normalize_timestamps(path: Path) -> None:
    """把 pyz 内全部条目的时间戳改写为固定值，保留解释器前缀行。"""
    with zipfile.ZipFile(path) as z:
        entries = [(info.filename, info.external_attr, z.read(info.filename))
                   for info in z.infolist()]

    raw = path.read_bytes()
    marker = raw.find(b"PK\x03\x04")
    prefix = raw[:marker] if marker > 0 else b""

    tmp = path.with_suffix(".tmp")
    with open(tmp, "wb") as fh:
        fh.write(prefix)
        with zipfile.ZipFile(fh, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for name, _attr, data in entries:
                info = zipfile.ZipInfo(name, date_time=_FIXED_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                if name.endswith("/"):
                    info.external_attr = (0o40755 << 16) | 0x10
                else:
                    info.external_attr = 0o100644 << 16
                z.writestr(info, data)
    tmp.replace(path)


def build() -> Path:
    DIST.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        shutil.copytree(
            SRC,
            tmp_path / "irscan",
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
        (tmp_path / "__main__.py").write_text(_MAIN, encoding="utf-8")
        zipapp.create_archive(
            tmp, target=OUT, interpreter="/usr/bin/env python3", compressed=True
        )
    _normalize_timestamps(OUT)
    return OUT


def main() -> None:
    out = build()
    print(f"OK  {out}  ({out.stat().st_size / 1024:.0f} KB)")
    print(f"运行:  python {out.name} --offline --auth-log samples/auth.log")

if __name__ == "__main__":
    sys.exit(main())
