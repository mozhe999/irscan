#!/usr/bin/env python
"""获取外部情报：YARA 规则库与哈希黑名单。"""

from __future__ import annotations

import argparse
import io
import os
import sys
import tarfile
import urllib.error
import urllib.request

UA = {"User-Agent": "irscan-ioc-fetcher"}

YARA_SOURCES = [
    ("Neo23x0/signature-base",
     "https://github.com/Neo23x0/signature-base/archive/refs/heads/master.tar.gz"),
]

HASH_SOURCES = [
    ("MalwareBazaar 近期样本",
     "https://bazaar.abuse.ch/export/txt/sha256/recent/"),
]

TIMEOUT = 120


def _get(url: str) -> bytes | None:
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return resp.read()
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        print(f"    [失败] {exc}")
        return None


def fetch_yara(out_dir: str) -> int:
    """下载 YARA 规则库并解压。返回解压出的 .yar 文件数。"""
    total = 0
    for name, url in YARA_SOURCES:
        print(f"[YARA] {name}")
        data = _get(url)
        if not data:
            print("    下载失败：检查网络，或手动下载后解压到 rules/ 目录")
            continue
        try:
            with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
                count = 0
                for member in tar.getmembers():
                    if not member.name.lower().endswith((".yar", ".yara")):
                        continue
                    member.name = os.path.basename(member.name)
                    try:

                        tar.extract(member, out_dir, filter="data")
                    except TypeError:
                        tar.extract(member, out_dir)
                    count += 1
                total += count
        except tarfile.TarError as exc:
            print(f"    [失败] 解压出错: {exc}")
            continue
        print(f"    已解压 {count} 个规则文件 -> {out_dir}")
    return total


def fetch_hashes(out_path: str) -> int:
    """下载哈希黑名单，转成 irscan 的 IOC 格式。"""
    lines: list[str] = [
        "# 由 tools/fetch_ioc.py 自动获取",
        "# 每行一个 sha256，命中即判严重",
        "",
    ]
    total = 0
    for name, url in HASH_SOURCES:
        print(f"[哈希] {name}")
        data = _get(url)
        if not data:
            print("    未获取到。abuse.ch 在部分网络环境不可达，"
                  "可手动下载后按此格式保存")
            continue
        got = 0
        for raw in data.decode("utf-8", errors="replace").splitlines():
            token = raw.strip()
            if not token or token.startswith("#"):
                continue
            if len(token) == 64 and all(c in "0123456789abcdef" for c in token.lower()):
                lines.append(token.lower())
                got += 1
        print(f"    获取到 {got} 条")
        total += got

    if total:
        with open(out_path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("\n".join(lines) + "\n")
        print(f"    已写入 {out_path}（{total} 条）")
    return total


def main() -> int:
    p = argparse.ArgumentParser(description="获取外部威胁情报")
    p.add_argument("--out-dir", default="rules", help="YARA 规则输出目录（默认 rules）")
    p.add_argument("--hashes-out", default="ioc.txt", help="哈希情报输出文件")
    p.add_argument("--hashes", action="store_true", help="同时尝试拉取哈希黑名单")
    p.add_argument("--yara-only", action="store_true", help="只拉 YARA 规则")
    args = p.parse_args()

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    out_dir = args.out_dir if os.path.isabs(args.out_dir) else os.path.join(root, args.out_dir)
    os.makedirs(out_dir, exist_ok=True)

    if not args.hashes:
        n = fetch_yara(out_dir)
        if n:
            print(f"\n完成：{n} 个 YARA 规则文件位于 {out_dir}")
            print("使用方式（需先安装 yara-python，属可选依赖）：")
            print(f"    pip install yara-python")
            print(f"    set IRSCAN_YARA_RULES={out_dir}")
            print("    python -m irscan --webroot /var/www/html")
        return 0 if n else 1

    if args.yara_only:
        n = fetch_yara(out_dir)
        return 0 if n else 1

    y = fetch_yara(out_dir)
    h_path = args.hashes_out if os.path.isabs(args.hashes_out) else os.path.join(root, args.hashes_out)
    h = fetch_hashes(h_path)
    if h:
        print(f"\n哈希情报已就绪，用法：python -m irscan --ioc {h_path}")
    return 0 if (y or h) else 1

if __name__ == "__main__":
    sys.exit(main())
