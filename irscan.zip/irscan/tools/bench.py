"""生成压测数据集并分阶段计时。

用法：
    python tools/bench.py --build      只造数据到 benchdata/
    python tools/bench.py              跑全部基准
    python tools/bench.py --quick      小规模，CI 用
    python tools/bench.py --no-live    跳过实时采集
"""

from __future__ import annotations

import argparse
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DATA = ROOT / "benchdata"
RANDOM = random.Random(42)

IPS = [f"203.0.113.{i}" for i in range(1, 60)] + [f"198.51.100.{i}" for i in range(1, 40)]
USERS = ["root", "admin", "oracle", "postgres", "ubuntu", "deploy", "git", "mysql", "www-data"]
MONTHS = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()


def _auth_line(ts: str, ok: bool, user: str, ip: str) -> str:
    pid = RANDOM.randint(1000, 30000)
    port = RANDOM.randint(20000, 60000)
    if ok:
        return f"{ts} web01 sshd[{pid}]: Accepted password for {user} from {ip} port {port} ssh2"
    return f"{ts} web01 sshd[{pid}]: Failed password for {user} from {ip} port {port} ssh2"

_UAS = ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/605.1.15",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) Mobile/15E148",
        "Mozilla/5.0 (X11; Linux x86_64) Firefox/121.0",
        "python-requests/2.31.0", "curl/8.4.0",
        "sqlmap/1.7.11#stable (https://sqlmap.org)", "Mozilla/5.0 (Nikto/2.5.0)",
        "WPScan v3.8.24 (https://wpscan.com/wordpress-security-scanner)"]
_ATTACK_TAILS = ["?id=1%27+UNION+SELECT+1,2,3--", "?q=../../../../etc/passwd",
                 "/.env", "/.git/config", "/shell.php?cmd=whoami", "/wp-config.php.bak",
                 "?id=1 AND SLEEP(5)", "/cgi-bin/test.cgi?cmd=id"]


def _make_uri_pool(size: int) -> list[str]:
    pool = []
    for i in range(size):
        kind = i % 5
        if kind == 0:
            pool.append(f"/product/{1000 + i}.html")
        elif kind == 1:
            pool.append(f"/api/v1/orders/{20000 + i}?t={(i * 37) % 99999}")
        elif kind == 2:
            pool.append(f"/static/js/bundle.{i}.js")
        elif kind == 3:
            pool.append(f"/user/{i}/profile")
        else:
            pool.append(f"/category/{i % 30}/page/{i % 9}")
    return pool


def _access_line(ip: str, ts: str, pool: list[str]) -> tuple[str, str]:
    """返回 (日志行, uri)。约 2% 的请求带攻击载荷。"""
    if RANDOM.random() < 0.02:
        uri = RANDOM.choice(pool) + RANDOM.choice(_ATTACK_TAILS)
        status = RANDOM.choice([200, 200, 404, 500])
        ua = RANDOM.choice(_UAS[6:]) if RANDOM.random() < 0.5 else RANDOM.choice(_UAS[:6])
    else:
        uri = RANDOM.choice(pool)
        status = RANDOM.choice([200, 200, 200, 200, 301, 404, 500])
        ua = RANDOM.choice(_UAS[:6])
    return (f'{ip} - - [{ts}] "GET {uri} HTTP/1.1" {status} '
            f'{RANDOM.randint(120, 90000)} "-" "{ua}"'), uri


def build(n_auth: int, n_access: int, n_files: int) -> dict[str, object]:
    """按规模分目录生成数据集；已存在就直接复用，不做任何删除。"""
    import json

    data = ROOT / "benchdata" / f"a{n_auth}-w{n_access}-f{n_files}"
    meta_file = data / "meta.json"
    if meta_file.exists():
        with open(meta_file, encoding="utf-8") as fh:
            meta = json.load(fh)
        print(f"  复用已有数据集 {data.name}")
        return meta

    (data / "wwwroot").mkdir(parents=True, exist_ok=True)
    (data / "log").mkdir(parents=True, exist_ok=True)

    month = RANDOM.choice(MONTHS)
    auth = data / "log" / "auth.log"
    with open(auth, "w", encoding="utf-8", buffering=1 << 20) as fh:
        for i in range(n_auth):
            day = 1 + (i // max(n_auth // 27, 1)) % 27
            ts = f"{month} {day:02d} {i % 24:02d}:{i % 60:02d}:{(i * 7) % 60:02d}"
            ok = RANDOM.random() > 0.82
            fh.write(_auth_line(ts, ok, RANDOM.choice(USERS), RANDOM.choice(IPS)) + "\n")

    access = data / "log" / "access.log"
    pool = _make_uri_pool(max(200, int(n_access / 150)))
    seen: set[str] = set()
    with open(access, "w", encoding="utf-8", buffering=1 << 20) as fh:
        for i in range(n_access):
            day = 1 + (i // max(n_access // 27, 1)) % 27
            ts = f"{day:02d}/Jan/2024:{i % 24:02d}:{i % 60:02d}:{(i * 7) % 60:02d} +0800"
            line, uri = _access_line(RANDOM.choice(IPS), ts, pool)
            seen.add(uri)
            fh.write(line + "\n")

    tpl = """<?php
// page %d
class Db_%d {
    private $pdo;
    public function __construct($dsn) { $this->pdo = new PDO($dsn); }
    public function find($id) {
        $stmt = $this->pdo->prepare('SELECT * FROM t WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->fetchAll();
    }
    public function render($rows) { return json_encode($rows, JSON_UNESCAPED_UNICODE); }
}
$db = new Db_%d('mysql:host=127.0.0.1;dbname=app');
echo $db->render($db->find($_GET['id'] ?? 0));
"""
    for i in range(n_files):
        d = data / "wwwroot" / f"m{i % 40:02d}"
        d.mkdir(exist_ok=True)
        if i % 97 == 0:
            (d / f"c99_{i}.php").write_text(
                '<?php @eval($_POST["x"]); system($_GET["c"]); ?>', encoding="utf-8")
        else:
            (d / f"page_{i}.php").write_text(tpl % (i, i, i), encoding="utf-8")

    meta = {
        "auth_log": str(auth), "web_log": str(access), "webroot": str(data / "wwwroot"),
        "auth_lines": n_auth, "web_lines": n_access, "files": n_files,
        "unique_uris": len(seen),
        "auth_bytes": auth.stat().st_size, "web_bytes": access.stat().st_size,
    }
    with open(meta_file, "w", encoding="utf-8") as fh:
        json.dump(meta, fh)
    return meta


def legacy_weblog_scan(lines: list[str]) -> int:
    """优化前的实现，保留用于同进程 A/B 对比。"""
    import re

    from irscan.parsers.logs import parse_clf_line

    def match_all(patterns, text):
        return [label for pattern, label in patterns if re.search(pattern, text, re.I)]

    from irscan.detectors import weblog as w

    total = 0
    for line in lines:
        if not line.strip():
            continue
        rec = parse_clf_line(line)
        if rec is None:
            total += len(match_all(w.SQLI_PATTERNS, line))
            continue
        uri = rec["uri"]
        total += len(match_all(w.SQLI_PATTERNS, uri))
        total += len(match_all(w.RCE_PATTERNS, uri))
        total += len(match_all(w.TRAVERSAL_PATTERNS, uri))
        total += len(match_all(w.SENSITIVE_PATHS, uri))
        if rec["ua"]:
            total += len(match_all(w.SCANNER_UA, rec["ua"]))
    return total


def legacy_rules_scan(texts: list[str], ruleset) -> int:
    """优化前的规则匹配：命中后对整个文本做一次无上限 findall。"""
    total = 0
    rules = ruleset.for_target("file")
    for text in texts:
        for rule in rules:
            for p in rule.patterns:
                m = p.regex.search(text)
                if not m:
                    continue
                _ = m.group(0)[:120]
                _ = len(p.regex.findall(text))
                total += 1
    return total


class Bench:
    def __init__(self) -> None:
        self.rows: list[tuple[str, float, str]] = []

    def run(self, label: str, fn, count: float = 0, unit: str = "", repeat: int = 1) -> object:
        """repeat>1 时取最小值，抑制宿主机后台负载带来的波动。"""
        best = None
        out = None
        for _ in range(repeat):
            t0 = time.perf_counter()
            out = fn()
            dt = time.perf_counter() - t0
            best = dt if best is None else min(best, dt)
        assert best is not None
        rate = f"{count / best:,.0f} {unit}/s" if best > 0 and count else "-"
        self.rows.append((label, best, rate))
        print(f"  {label:<24} {best:8.3f}s  {rate:>16}"
              + (f"  (best of {repeat})" if repeat > 1 else ""))
        return out

    def report(self) -> None:
        w = max(len(r[0]) for r in self.rows) + 2
        print("\n" + "=" * (w + 26))
        print(f"{'阶段'.ljust(w)}{'耗时(s)':>10}{'吞吐':>18}")
        print("-" * (w + 28))
        for label, dt, rate in self.rows:
            print(f"{label.ljust(w)}{dt:10.3f}{rate:>18}")
        print("=" * (w + 26))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", action="store_true")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--no-live", action="store_true")
    args = ap.parse_args()

    scale = 0.1 if args.quick else 1.0
    n_auth, n_access, n_files = int(200_000 * scale), int(300_000 * scale), int(5_000 * scale)

    print(f"数据集: auth {n_auth:,} 行 / access {n_access:,} 行 / webroot {n_files:,} 文件")
    t0 = time.perf_counter()
    meta = build(n_auth, n_access, n_files)
    print(f"造数据 {time.perf_counter() - t0:.1f}s")
    if args.build:
        return 0

    import platform
    from irscan.core.engine import ScanConfig, ScanContext
    from irscan.core.models import HostSnapshot, ScanResult
    from irscan.core import rules as rules_mod
    from irscan.detectors import bruteforce, weblog, webshell
    from irscan.parsers import logs
    from irscan.cli import build_default_scanner

    print(f"\n环境: Python {platform.python_version()} / {platform.platform()}")
    b = Bench()

    cfg = ScanConfig(live=False, auth_logs=[str(meta["auth_log"])],
                     web_logs=[str(meta["web_log"])], webroots=[str(meta["webroot"])])

    def fresh_ctx() -> ScanContext:
        snap = HostSnapshot(platform="bench(离线)")
        return ScanContext(config=cfg, snapshot=snap, result=ScanResult(snapshot=snap))

    def ctx_with_lines(lines: list[str]) -> ScanContext:
        c = fresh_ctx()
        c.weblog_lines = lines
        return c

    print("\n[规则]")
    rs = b.run("加载内置规则集", lambda: rules_mod.load(), len(rules_mod.load().rules), "条")

    print(f"\n[日志]  （唯一 URL {meta['unique_uris']:,} 个）")
    ctx = fresh_ctx()
    b.run("auth.log 解析", lambda: logs.parse_auth_files(ctx), n_auth, "行")
    b.run("access.log 解析", lambda: logs.parse_web_logs(ctx), n_access, "行")
    b.run("纯按行读(基线)", lambda: sum(1 for _ in open(meta["auth_log"],
                                                     encoding="utf-8", errors="replace")),
          n_auth, "行")

    print("\n[检测]")
    b.run("爆破检测", lambda: bruteforce.detect(ctx), len(ctx.auth_events), "事件")
    b.run("Web 日志检测", lambda: weblog.detect(ctx), len(ctx.weblog_lines), "行")

    lines = list(ctx.weblog_lines)
    t_legacy = time.perf_counter()
    legacy_weblog_scan(lines)
    dt_legacy = time.perf_counter() - t_legacy
    t_new = time.perf_counter()
    weblog.detect(ctx_with_lines(lines))
    dt_new = time.perf_counter() - t_new
    print(f"  A/B 对比（同数据）: 优化前 {dt_legacy:.3f}s -> 优化后 {dt_new:.3f}s "
          f"（{dt_legacy / max(dt_new, 1e-9):.1f}x）")

    print("\n[文件]")
    ctx2 = fresh_ctx()
    nbytes = sum(f.stat().st_size for f in Path(meta["webroot"]).rglob("*") if f.is_file())
    b.run("Webshell 扫描", lambda: webshell.detect(ctx2), n_files, "文件", repeat=3)
    print(f"  （扫描字节 {nbytes / 1e6:.1f} MB）")

    from irscan.core.rules import load as load_rules
    from irscan.detectors.webshell import WEB_EXTS
    from irscan.core.utils import iter_files, read_text

    paths = iter_files(meta["webroot"], exts=WEB_EXTS)

    contents = []
    for p in paths:
        try:
            contents.append(read_text(p))
        except OSError:
            continue
    rs = load_rules()
    t_l = time.perf_counter()
    legacy_rules_scan(contents, rs)
    dt_l = time.perf_counter() - t_l
    t_n = time.perf_counter()
    for c in contents:
        rs.scan("file", c)
    dt_n = time.perf_counter() - t_n
    print(f"  A/B 对比（纯规则匹配，{len(contents)} 文件）: "
          f"{dt_l:.3f}s -> {dt_n:.3f}s（{dt_l / max(dt_n, 1e-9):.1f}x）")

    sample = next(Path(meta["webroot"]).rglob("page_*.php")).read_text(encoding="utf-8")
    n_iter = 3000
    b.run("规则匹配(单文件×3000)", lambda: [rs.scan("file", sample) for _ in range(n_iter)],
          n_iter, "次")

    print("\n[端到端]")
    b.run("离线全流水线", lambda: build_default_scanner(cfg).run(), 0, "", repeat=2)

    if not args.no_live and not args.quick:
        b.run("实时采集全流水线", lambda: build_default_scanner(ScanConfig(live=True)).run(), 0, "")

    b.report()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
