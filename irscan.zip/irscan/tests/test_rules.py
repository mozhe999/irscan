"""外置规则引擎测试，重点保证单条规则写坏不影响其余规则。"""

from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from irscan.core import rules  # noqa: E402
from irscan.core.models import Severity  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TestBuiltinRules(unittest.TestCase):
    def test_builtin_loads(self):
        rs = rules.load()
        self.assertGreaterEqual(len(rs.rules), 30)
        summary = rs.summary()
        for target in ("file", "process", "startup"):
            self.assertIn(target, summary)
            self.assertGreater(summary[target], 0)
        self.assertEqual(rs.errors, [])

    def test_webshell_scoring_thresholds(self):
        rs = rules.load()
        self.assertEqual(rs.severity_for_score(6), Severity.HIGH)
        self.assertEqual(rs.severity_for_score(5), Severity.MEDIUM)
        self.assertEqual(rs.severity_for_score(1), Severity.LOW)

    def test_webshell_sample_hits(self):
        """样本里的一句话木马必须命中，且分数够高危。"""
        rs = rules.load()
        path = os.path.join(ROOT, "samples", "wwwroot", "uploads", "img_20240115.php")
        with open(path, encoding="utf-8") as fh:
            hits = rs.scan("file", fh.read())
        self.assertTrue(hits)
        self.assertGreaterEqual(sum(h.score for h in hits),
                                int(rs.scoring.get("high", 6)))

    def test_technique_parsed_from_tags(self):
        rs = rules.load()
        by_id = {r.id: r for r in rs.rules}
        self.assertEqual(by_id["proc-credential-mimikatz"].technique, "T1003")
        self.assertEqual(by_id["proc-credential-mimikatz"].tactic, "凭据访问")

    def test_target_filtering(self):
        rs = rules.load()

        self.assertTrue(all("file" in r.targets for r in rs.for_target("file")))
        self.assertFalse(any("file" in r.targets for r in rs.for_target("process")))


class TestRuleMatching(unittest.TestCase):
    def _write(self, content: str, name: str = "r.json") -> str:
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        p = os.path.join(d, name)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(content)
        return p

    def test_mode_all_requires_every_pattern(self):
        p = self._write(json.dumps({"rules": [{
            "id": "x", "title": "t", "target": ["file"], "mode": "all",
            "patterns": [{"re": "foo"}, {"re": "bar"}],
        }]}))
        rs = rules.load([p])
        rule = [r for r in rs.rules if r.id == "x"][0]
        self.assertIsNone(rule.match("only foo here"))
        self.assertIsNotNone(rule.match("foo and bar"))

    def test_weight_and_count(self):
        p = self._write(json.dumps({"rules": [{
            "id": "x", "title": "t", "target": ["file"],
            "patterns": [{"re": "abc", "weight": 3}],
        }]}))
        rs = rules.load([p])
        hits = rs.scan("file", "abc abc abc")
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0].score, 3)
        self.assertEqual(hits[0].hits[0][2], 3)

    def test_override_builtin_rule(self):
        """外部目录里同 id 的规则覆盖内置规则。"""
        p = self._write(json.dumps({"rules": [{
            "id": "webshell-dangerous-call", "title": "业务允许的系统调用",
            "target": ["file"], "level": "info",
            "patterns": [{"re": "never-ever-match"}],
        }]}))
        rs = rules.load([p])
        matched = [r for r in rs.rules if r.id == "webshell-dangerous-call"]
        self.assertEqual(len(matched), 1)
        self.assertEqual(matched[0].title, "业务允许的系统调用")

    def test_disabled_rule_not_scanned(self):
        p = self._write(json.dumps({"rules": [{
            "id": "x", "title": "t", "target": ["file"],
            "enabled": False, "patterns": [{"re": "abc"}],
        }]}))
        rs = rules.load([p])
        self.assertEqual(rs.scan("file", "abc"), [])
        self.assertFalse(any(r.id == "x" for r in rs.for_target("file")))

    def test_bad_regex_skipped_not_fatal(self):
        """一条规则写坏，其余规则照常工作，并且错误要被记下来。"""
        p = self._write(json.dumps({"rules": [
            {"id": "bad", "title": "b", "target": ["file"],
             "patterns": [{"re": "([unclosed"}]},
            {"id": "good", "title": "g", "target": ["file"],
             "patterns": [{"re": "abc"}]},
        ]}))
        rs = rules.load([p])
        ids = [r.id for r in rs.rules]
        self.assertTrue(any("bad" in e for e in rs.errors))
        self.assertIn("good", ids)
        self.assertNotIn("bad", ids)
        self.assertEqual(len(rs.scan("file", "abc")), 1)

    def test_rule_without_id_or_patterns_skipped(self):
        p = self._write(json.dumps({"rules": [
            {"title": "没有 id", "target": ["file"], "patterns": [{"re": "a"}]},
            {"id": "no-pattern", "title": "没有 patterns", "target": ["file"]},
        ]}))
        rs = rules.load([p])
        self.assertEqual(len(rs.errors), 2)
        self.assertNotIn("no-pattern", [r.id for r in rs.rules])

    def test_unsupported_mode_falls_back_to_any(self):
        p = self._write(json.dumps({"rules": [{
            "id": "x", "title": "t", "target": ["file"], "mode": "quantum",
            "patterns": [{"re": "abc"}],
        }]}))
        rs = rules.load([p])
        self.assertTrue(any("mode" in e for e in rs.errors))
        self.assertEqual(len(rs.scan("file", "abc")), 1)

    def test_missing_file_recorded(self):
        rs = rules.load(["/nonexistent/rules"])
        self.assertTrue(any("读取失败" in e for e in rs.errors))


class TestRuleErrorsSurfaced(unittest.TestCase):
    def test_engine_reports_rule_errors_as_blindspot(self):
        """规则加载失败记入盲区。"""
        from irscan.core.engine import ScanConfig, ScanContext
        from irscan.core.models import HostSnapshot, ScanResult

        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        p = os.path.join(d, "bad.json")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"rules": [
                {"id": "bad", "title": "b", "target": ["file"],
                 "patterns": [{"re": "([unclosed"}]}]}))

        snap = HostSnapshot(platform="test")
        cfg = ScanConfig(live=False, rules_dirs=[p])
        ctx = ScanContext(config=cfg, snapshot=snap, result=ScanResult(snapshot=snap))
        self.assertTrue(any("规则加载" in e for e in snap.errors))
        self.assertIsNotNone(ctx.ruleset)

if __name__ == "__main__":
    unittest.main()
