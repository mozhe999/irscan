"""性能优化的正确性回归：缓存不吞计数、惰性时间解析、命中计数上限。"""

from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from irscan.core.engine import ScanConfig, ScanContext  # noqa: E402
from irscan.core.models import HostSnapshot, ScanResult  # noqa: E402
from irscan.core.rules import MAX_HIT_COUNT, load  # noqa: E402
from irscan.detectors import weblog  # noqa: E402
from irscan.parsers.logs import parse_clf_line  # noqa: E402


def ctx_with(lines: list[str]) -> ScanContext:
    cfg = ScanConfig(live=False)
    snap = HostSnapshot(platform="test")
    ctx = ScanContext(config=cfg, snapshot=snap, result=ScanResult(snapshot=snap))
    ctx.weblog_lines = lines
    return ctx


class TestWeblogCache(unittest.TestCase):
    def setUp(self) -> None:
        weblog._URI_CACHE.clear()
        weblog._UA_CACHE.clear()

    def test_repeated_uri_still_counted(self):
        """同一 URL 出现 12 次，命中数为 12。"""
        line = ('198.51.100.7 - - [15/Jan/2024:10:00:01 +0800] '
                '"GET /index.php?id=1%27+UNION+SELECT+1,2,3-- HTTP/1.1" 200 123 "-" "curl/8.4.0"')
        ctx = ctx_with([line] * 12)
        findings = weblog.detect(ctx)
        self.assertEqual(len(findings), 1)
        joined = " ".join(findings[0].evidence)
        self.assertIn("× 12", joined, f"计数被缓存吞掉了: {joined}")

    def test_cache_returns_same_result(self):
        """冷/热缓存两次检测结果必须一致。"""
        lines = [
            '198.51.100.7 - - [15/Jan/2024:10:00:01 +0800] '
            '"GET /.env HTTP/1.1" 200 12 "-" "curl/8.4.0"',
            '203.0.113.9 - - [15/Jan/2024:10:00:02 +0800] '
            '"GET /index.php HTTP/1.1" 200 12 "-" "Mozilla/5.0"',
            '203.0.113.9 - - [15/Jan/2024:10:00:03 +0800] '
            '"GET /x?q=../../../../etc/passwd HTTP/1.1" 404 12 "-" "sqlmap/1.7"',
        ]
        first = [f.title for f in weblog.detect(ctx_with(lines))]
        second = [f.title for f in weblog.detect(ctx_with(lines))]
        self.assertEqual(first, second)
        self.assertTrue(first)

    def test_scanner_ua_detected(self):
        ctx = ctx_with(['192.0.2.4 - - [15/Jan/2024:10:00:01 +0800] '
                        '"GET / HTTP/1.1" 200 1 "-" "sqlmap/1.7.11#stable"'])
        findings = weblog.detect(ctx)
        self.assertTrue(any("扫描器指纹" in e for f in findings for e in f.evidence))


class TestLazyTimeParsing(unittest.TestCase):
    def test_want_ts_false_skips_datetime(self):
        line = ('192.0.2.4 - - [15/Jan/2024:10:00:01 +0800] '
                '"GET /a HTTP/1.1" 200 1 "-" "curl/8.4.0"')
        full = parse_clf_line(line)
        lazy = parse_clf_line(line, want_ts=False)
        self.assertIsNotNone(full)
        self.assertIsNotNone(lazy)
        self.assertIsNotNone(full["ts"])
        self.assertIsNone(lazy["ts"])
        for key in ("ip", "time", "method", "uri", "status", "ua", "raw"):
            self.assertEqual(full[key], lazy[key], f"字段 {key} 不一致")

    def test_want_ts_default_keeps_backward_compat(self):
        line = ('192.0.2.4 - - [15/Jan/2024:10:00:01 +0800] '
                '"GET /a HTTP/1.1" 200 1 "-" "curl/8.4.0"')
        self.assertIsNotNone(parse_clf_line(line)["ts"])


class TestWebTimelineStillWorks(unittest.TestCase):
    """时间线路径的回归测试。"""

    def setUp(self) -> None:
        from irscan.detectors import timeline as t
        t._STAGE_CACHE.clear()
        self.timeline = t

    def test_web_attack_produces_timeline_event(self):
        lines = [
            '198.51.100.7 - - [15/Jan/2024:10:00:01 +0800] '
            '"GET /index.php?id=1+UNION+SELECT+1,2,3-- HTTP/1.1" 200 5 "-" "curl/8.4.0"',
            '198.51.100.7 - - [15/Jan/2024:10:00:02 +0800] '
            '"GET /.env HTTP/1.1" 200 5 "-" "curl/8.4.0"',
            '203.0.113.9 - - [15/Jan/2024:10:00:03 +0800] '
            '"GET /index.php HTTP/1.1" 200 5 "-" "Mozilla/5.0"',
        ]
        ctx = ctx_with(lines)
        events = self.timeline.build(ctx)
        self.assertTrue(any(e.source == "Web 访问日志" for e in events),
                        "攻击请求没有产生时间线事件")

    def test_clean_traffic_produces_no_web_event(self):
        ctx = ctx_with(['192.0.2.4 - - [15/Jan/2024:10:00:01 +0800] '
                        '"GET /index.php HTTP/1.1" 200 5 "-" "Mozilla/5.0"'])
        events = self.timeline.build(ctx)
        self.assertFalse([e for e in events if e.source == "Web 访问日志"])

    def test_scanner_ua_without_uri_hit_is_timelined(self):
        ctx = ctx_with(['192.0.2.4 - - [15/Jan/2024:10:00:01 +0800] '
                        '"GET /index.php HTTP/1.1" 200 5 "-" "sqlmap/1.7.11"'])
        events = self.timeline.build(ctx)
        self.assertTrue(any("扫描器" in e.label for e in events))


class TestHitCountCap(unittest.TestCase):
    def test_count_capped_on_large_text(self):
        """超过阈值的大文本，计数在上限处停止。"""
        from irscan.core.rules import _FINDALL_MAX_TEXT
        rs = load()
        unit = "eval($_POST['x']);"
        text = unit * (int(_FINDALL_MAX_TEXT / len(unit)) + MAX_HIT_COUNT * 2)
        self.assertGreater(len(text), _FINDALL_MAX_TEXT)
        hits = rs.scan("file", text)
        self.assertTrue(hits)
        for h in hits:
            for _w, _s, count, _n in h.hits:
                self.assertLessEqual(count, MAX_HIT_COUNT)

    def test_small_text_counts_exactly(self):
        """小文本走精确计数：报告里的 ×N 必须是真实次数。"""
        from irscan.core.rules import _FINDALL_MAX_TEXT
        rs = load()
        text = "<?php system($_GET['c']); " + "eval($_GET['a']); " * 7 + "?>"
        self.assertLess(len(text), _FINDALL_MAX_TEXT)
        hits = rs.scan("file", text)
        self.assertTrue(hits)
        self.assertTrue(all(c <= 10 for h in hits for _w, _s, c, _n in h.hits))

    def test_cap_does_not_affect_severity(self):
        """计数上限只影响展示，小样本下的评分必须与上限前一致。"""
        rs = load()
        small = "<?php @eval($_POST['x']); system($_GET['c']); ?>"
        hits = rs.scan("file", small)
        self.assertTrue(hits)
        score = sum(h.score for h in hits)
        self.assertGreater(score, 0)
        self.assertTrue(all(c <= 10 for h in hits for _w, _s, c, _n in h.hits))


if __name__ == "__main__":
    unittest.main()
