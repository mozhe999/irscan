"""时间线、文件系统检测、基线对比、流式读取、ATT&CK 与报告渲染的测试。"""

from __future__ import annotations

import json
import os
import sys
import shutil
import tempfile
import unittest
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from irscan.core.attck import describe, get, summarize_coverage  # noqa: E402
from irscan.core.baseline import compare, save  # noqa: E402
from irscan.core.engine import (  # noqa: E402
    AuthEvent, ScanConfig, ScanContext,
)
from irscan.core.baseline import to_findings  # noqa: E402
from irscan.core.models import (  # noqa: E402
    AccountInfo, ConnectionInfo, FileInfo, HostSnapshot, ProcessInfo, ScanResult,
    ServiceInfo, Severity, StartupItem, TimelineEvent, WmiSubscription,
)
from irscan.core.utils import iter_lines  # noqa: E402
from irscan.detectors import filesystem, integrity, timeline  # noqa: E402
from irscan.detectors import ioc as ioc_mod  # noqa: E402
from irscan.report import render, render_console_summary, render_markdown  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAMPLES = os.path.join(ROOT, "samples")


def make_ctx(events=None, config=None, weblog_lines=None, snapshot=None):
    cfg = config or ScanConfig(live=False)
    snap = snapshot or HostSnapshot(platform="test")
    result = ScanResult(snapshot=snap)
    ctx = ScanContext(config=cfg, snapshot=snap, result=result)
    ctx.auth_events = events or []
    ctx.weblog_lines = weblog_lines or []
    return ctx


def ev(second_offset: int, success: bool, ip: str, user: str = "root",
       base: datetime | None = None) -> AuthEvent:
    base = base or datetime(2024, 1, 15, 9, 0, 0)
    return AuthEvent(
        timestamp=base + timedelta(seconds=second_offset),
        success=success, username=user, source_ip=ip,
        raw=f"{'Accepted' if success else 'Failed'} password for {user} from {ip}",
    )


class TestTimeline(unittest.TestCase):
    def test_dense_failures_collapsed_into_one_span(self):
        """25 次连续失败必须聚成一条，不能刷满时间线。"""
        events = [ev(i * 3, False, "203.0.113.9") for i in range(25)]
        tl = timeline.build(make_ctx(events))
        labels = [e.label for e in tl]
        failed = [l for l in labels if "登录失败" in l]
        self.assertEqual(len(failed), 1, f"应聚合成 1 段，实际 {len(failed)}")
        self.assertIn("×25", failed[0])

    def test_separate_spans_not_merged(self):
        """间隔很久的两段爆破必须分成两条，不能糊在一起。"""
        events = [ev(i, False, "203.0.113.11") for i in range(6)]
        events += [ev(3600 + i, False, "203.0.113.11") for i in range(6)]
        tl = timeline.build(make_ctx(events))
        failed = [e for e in tl if "登录失败" in e.label]
        self.assertEqual(len(failed), 2)

    def test_success_after_failure_is_critical(self):
        """爆破后成功登录 = 攻击链闭合点，必须标严重且写进标签。"""
        events = [ev(i, False, "203.0.113.9") for i in range(8)]
        events.append(ev(300, True, "203.0.113.9"))
        tl = timeline.build(make_ctx(events))
        success = [e for e in tl if "登录成功" in e.label]
        self.assertEqual(len(success), 1)
        self.assertEqual(success[0].severity, Severity.CRITICAL)
        self.assertIn("爆破成功", success[0].label)

    def test_success_without_prior_failure_is_medium(self):
        """没有失败记录的成功登录不该被夸大成严重。"""
        events = [ev(0, True, "10.0.0.5", user="ops")]
        tl = timeline.build(make_ctx(events))
        self.assertEqual(tl[0].severity, Severity.MEDIUM)
        self.assertNotIn("爆破成功", tl[0].label)

    def test_timeline_sorted(self):
        events = [ev(100, False, "203.0.113.11"), ev(0, True, "203.0.113.12"),
                  ev(50, False, "203.0.113.13")]
        tl = timeline.build(make_ctx(events))
        stamps = [e.timestamp for e in tl]
        self.assertEqual(stamps, sorted(stamps))

    def test_summarize_empty(self):
        self.assertEqual(timeline.summarize([]), [])

    def test_end_to_end_sample_timeline(self):
        auth = os.path.join(SAMPLES, "auth.log")
        if not os.path.exists(auth):
            self.skipTest("样本缺失")
        from irscan.cli import build_default_scanner
        cfg = ScanConfig(live=False, auth_logs=[auth])
        result = build_default_scanner(cfg).run()
        self.assertTrue(result.timeline)

        self.assertTrue(any(e.severity == Severity.CRITICAL for e in result.timeline))


class TestFilesystem(unittest.TestCase):
    def test_ld_preload_is_critical(self):
        snap = HostSnapshot(platform="linux")
        snap.files = [FileInfo(path="/etc/ld.so.preload", kind="ld_preload",
                               content="/lib/.evil.so", modified_at="2024-01-15 09:40:00")]
        out = filesystem.detect(make_ctx(snapshot=snap))
        self.assertTrue(any(f.severity == Severity.CRITICAL for f in out))
        self.assertTrue(any("LD_PRELOAD" in f.title for f in out))

    def test_empty_ld_preload_not_flagged(self):
        snap = HostSnapshot(platform="linux")
        snap.files = [FileInfo(path="/etc/ld.so.preload", kind="ld_preload", content="")]
        self.assertEqual(filesystem.detect(make_ctx(snapshot=snap)), [])

    def test_wmi_consumer_flagged(self):
        snap = HostSnapshot(platform="windows")
        snap.wmi = [WmiSubscription(kind="Consumer", name="evil",
                                    command="powershell -enc AAA")]
        out = filesystem.detect(make_ctx(snapshot=snap))
        self.assertTrue(any("WMI" in f.title for f in out))
        self.assertTrue(any(f.technique == "T1546.003" for f in out))

    def test_whitelisted_suid_not_flagged(self):
        """/usr/bin/sudo 这类正常 SUID 不应报警。"""
        snap = HostSnapshot(platform="linux")
        snap.files = [FileInfo(path="/usr/bin/sudo", kind="suid", owner="root")]
        self.assertEqual(filesystem.detect(make_ctx(snapshot=snap)), [])

    def test_suid_in_tmp_is_critical(self):
        snap = HostSnapshot(platform="linux")
        snap.files = [FileInfo(path="/tmp/.x/bash", kind="suid", owner="root")]
        out = filesystem.detect(make_ctx(snapshot=snap))
        self.assertTrue(any(f.severity == Severity.CRITICAL for f in out))

    def test_unknown_suid_flagged(self):
        snap = HostSnapshot(platform="linux")
        snap.files = [FileInfo(path="/usr/bin/nmap", kind="suid", owner="root")]
        out = filesystem.detect(make_ctx(snapshot=snap))
        self.assertTrue(any("SUID" in f.title for f in out))

    def test_service_in_user_writable_dir(self):
        snap = HostSnapshot(platform="windows")
        snap.services = [ServiceInfo(name="EvilSvc", path="C:\\Temp\\svc.exe",
                                     risk="user_writable")]
        out = filesystem.detect(make_ctx(snapshot=snap))
        self.assertTrue(any("用户可写目录" in f.title for f in out))

    def test_service_third_party_not_flagged(self):
        """Program Files 下的第三方服务不告警。"""
        snap = HostSnapshot(platform="windows")
        snap.services = [ServiceInfo(
            name="LegitSvc", path="C:\\Program Files\\Vendor\\app.exe",
            risk="third_party")]
        out = filesystem.detect(make_ctx(snapshot=snap))
        self.assertFalse(any("LegitSvc" in f.title for f in out))

    def test_missing_binary_running_upgraded(self):
        """文件不存在但服务仍在运行：从卸载残留升级为高危。"""
        snap = HostSnapshot(platform="windows")
        snap.services = [ServiceInfo(name="GhostSvc", path="C:\\a\\b.exe",
                                     risk="missing_binary", state="Running")]
        out = filesystem.detect(make_ctx(snapshot=snap))
        hit = [f for f in out if "GhostSvc" in f.title]
        self.assertTrue(hit)
        self.assertEqual(hit[0].severity, Severity.HIGH)


class TestServicePathClassification(unittest.TestCase):
    """服务路径特征判定。"""

    def _c(self, raw):
        from irscan.collectors.windows import classify_service_path
        return classify_service_path(raw, raw.strip('"'))

    def test_unquoted_path_with_space(self):
        self.assertEqual(self._c(r"C:\Program Files\Vendor\app.exe -k x"),
                         "unquoted_space")

    def test_quoted_path_is_safe(self):
        """加引号后 Windows 不会分段猜测，不存在劫持空间。"""
        self.assertNotEqual(self._c(r'"C:\Program Files\Vendor\app.exe" -k x'),
                            "unquoted_space")

    def test_user_writable(self):
        self.assertEqual(self._c(r"C:\Users\bob\app.exe"), "user_writable")
        self.assertEqual(self._c(r"C:\ProgramData\Vendor\a.exe"), "user_writable")

    def test_defender_not_flagged(self):
        """Windows Defender 放在 ProgramData 下，但受 ACL 保护，不该报。"""
        self.assertNotEqual(
            self._c(r"C:\ProgramData\Microsoft\Windows Defender\Platform\MsMpEng.exe"),
            "user_writable")


class TestIntegrity(unittest.TestCase):
    """交叉视角检测：两个本该一致的视图对不上，本身就是证据。"""

    def _ctx(self, proc_pids, cli_pids, **extra):
        snap = HostSnapshot(platform="linux", hostname="h")
        snap.processes = [ProcessInfo(pid=p, name="x") for p in proc_pids]
        snap.extra = {"visible_pids": cli_pids, **extra}
        return make_ctx(snapshot=snap)

    def test_consistent_views_no_finding(self):
        out = integrity.detect(self._ctx([1, 2, 3], ["1", "2", "3"]))
        self.assertEqual(out, [])

    def test_hidden_in_cli_view(self):
        """/proc 看得到但 ps 看不到 → ps 的输出被过滤了。"""
        out = integrity.detect(self._ctx([1, 2, 3, 4, 5, 6], ["1", "2"]))
        self.assertTrue(any("命令行视角缺失" in f.title for f in out))

    def test_hidden_in_kernel_view(self):
        """ps 看得到但 /proc 看不到 → 枚举路径可能被挂钩。"""
        out = integrity.detect(self._ctx([1, 2], ["1", "2", "3", "4", "5", "6"]))
        self.assertTrue(any("内核视角缺失" in f.title for f in out))

    def test_small_drift_tolerated(self):
        """采集有时序差，少量漂移不应报警。"""
        out = integrity.detect(self._ctx([1, 2, 3, 4, 5], ["1", "2", "3"]))
        self.assertEqual(out, [])

    def test_cli_enum_failure_is_blindspot(self):
        """命令行枚举失败记入盲区。"""
        snap = HostSnapshot(platform="linux")
        snap.processes = [ProcessInfo(pid=1, name="x")]
        snap.extra = {"visible_pids": []}
        integrity.detect(make_ctx(snapshot=snap))
        self.assertTrue(any("跳过隐藏进程" in e for e in snap.errors))

    def test_promisc_flagged(self):
        snap = HostSnapshot(platform="linux")
        snap.processes = [ProcessInfo(pid=1, name="x")]
        snap.extra = {"visible_pids": ["1"], "promisc": ["eth0"]}
        out = integrity.detect(make_ctx(snapshot=snap))
        self.assertTrue(any("混杂模式" in f.title for f in out))

    def test_pkg_integrity_critical_on_triage_tools(self):
        """ps/top 被改 = 后续所有进程结论都要打问号，必须判严重。"""
        snap = HostSnapshot(platform="linux")
        snap.processes = [ProcessInfo(pid=1, name="x")]
        snap.extra = {"visible_pids": ["1"],
                      "pkg_modified": ["S.5....T.  /usr/bin/ps"]}
        out = integrity.detect(make_ctx(snapshot=snap))
        hit = [f for f in out if "包管理器" in f.title]
        self.assertTrue(hit)
        self.assertEqual(hit[0].severity, Severity.CRITICAL)


class TestIOC(unittest.TestCase):
    """哈希 IOC 比对——这是本工具唯一依赖外部数据的检测。"""

    def _write(self, body: str) -> str:
        fd, path = tempfile.mkstemp(suffix=".txt")
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(body)
        self.addCleanup(os.remove, path)
        return path

    def _ctx_with(self, ioc_path, webroot):
        cfg = ScanConfig(live=False, ioc_files=[ioc_path], webroots=[webroot])
        snap = HostSnapshot(platform="test")
        return make_ctx(config=cfg, snapshot=snap)

    def test_eicar_hit(self):
        """用 EICAR 测试串验证 IOC 比对链路。"""
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        target = os.path.join(d, "eicar.com")
        with open(target, "wb") as fh:
            fh.write(rb'X5O!P%@AP[4\PZX54(P^)7CC)7}$'
                     rb'EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*')

        ioc = self._write(
            "# 测试\n"
            "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f  # EICAR\n")
        out = ioc_mod.detect(self._ctx_with(ioc, d))
        self.assertTrue(any("已知恶意样本" in f.title for f in out))
        self.assertEqual(out[0].severity, Severity.CRITICAL)

    def test_clean_file_no_false_positive(self):
        """sha256 不会碰撞，正常文件绝不能命中。"""
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        with open(os.path.join(d, "ok.txt"), "w") as fh:
            fh.write("hello world")
        ioc = self._write(
            "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f\n")
        out = ioc_mod.detect(self._ctx_with(ioc, d))
        self.assertEqual(out, [])

    def test_no_ioc_file_means_no_scan(self):
        """未提供情报文件时不跑 IOC 比对。"""
        snap = HostSnapshot(platform="test")
        out = ioc_mod.detect(make_ctx(config=ScanConfig(live=False), snapshot=snap))
        self.assertEqual(out, [])

    def test_missing_ioc_file_recorded_as_error(self):
        snap = HostSnapshot(platform="test")
        cfg = ScanConfig(live=False, ioc_files=["/nonexistent/ioc.txt"])
        ioc_mod.detect(make_ctx(config=cfg, snapshot=snap))
        self.assertTrue(any("IOC" in e for e in snap.errors))

    def test_parser_handles_three_formats(self):
        from irscan.core.ioc import load_ioc_file
        h = "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f"
        m = "44d88612fea8a8f36de82e1278abb02f"
        p = self._write(f"# comment\n\n{h}\n{m}  # md5 entry\n{h[:10]}  # too short\n")
        entries = load_ioc_file(p).hashes
        self.assertEqual(len(entries), 2)
        self.assertIn(h, entries)
        self.assertIn(m, entries)

    def test_loki_style_ioc_file(self):
        """Loki 的格式：类型;值;描述，五类都要认。"""
        from irscan.core.ioc import load_ioc_file
        h = "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f"
        p = self._write(
            f"sha256;{h};EICAR 测试文件\n"
            "md5;44d88612fea8a8f36de82e1278abb02f;EICAR md5\n"
            "filename;^c99\\.php$;已知后门文件名\n"
            "regex;eval\\(\\$_POST\\)?;一句话木马\n"
            "unknown;x;不支持的类型\n"
        )
        loaded = load_ioc_file(p)
        self.assertIn(h, loaded.hashes)
        self.assertEqual(len(loaded.hashes), 2)
        self.assertEqual(len(loaded.filenames), 1)
        self.assertEqual(len(loaded.content), 1)
        self.assertTrue(any("不支持" in e for e in loaded.errors))


class TestBaseline(unittest.TestCase):
    def test_save_and_compare_roundtrip(self):
        snap = HostSnapshot(platform="linux", hostname="h")
        snap.startup = [StartupItem(source="cron", name="a")]
        snap.accounts = [AccountInfo(username="root")]
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "b.json")
            save(snap, p)
            with open(p, encoding="utf-8") as fh:
                loaded = json.load(fh)
            diff = compare(snap, loaded["baseline"])
        self.assertTrue(diff.is_empty())

    def test_new_listening_port_detected(self):
        snap = HostSnapshot(platform="linux", hostname="h")
        base = {"listening": ["tcp:22"], "startup": [], "accounts": [],
                "services": [], "suid_files": [], "process_names": []}
        from irscan.core.models import ConnectionInfo
        snap.connections = [ConnectionInfo(proto="tcp", local_addr="0.0.0.0",
                                           local_port=22, remote_addr="", remote_port=0,
                                           state="LISTEN"),
                            ConnectionInfo(proto="tcp", local_addr="0.0.0.0",
                                           local_port=4444, remote_addr="", remote_port=0,
                                           state="LISTEN")]
        diff = compare(snap, base)
        self.assertIn("tcp:4444", diff.added.get("listening", []))
        findings = to_findings(diff)
        self.assertTrue(any("监听端口" in f.title for f in findings))

    def test_removed_process_names_ignored(self):
        """进程名消失通常是正常退出，不应产生告警噪音。"""
        snap = HostSnapshot(platform="linux", hostname="h")
        base = {"process_names": ["a", "b", "c"], "startup": [], "accounts": [],
                "services": [], "suid_files": [], "listening": []}
        diff = compare(snap, base)
        findings = to_findings(diff)
        self.assertFalse(any("进程名" in f.title for f in findings))


class TestStreaming(unittest.TestCase):
    def test_iter_lines_matches_readlines(self):
        path = os.path.join(SAMPLES, "auth.log")
        if not os.path.exists(path):
            self.skipTest("样本缺失")
        with open(path, encoding="utf-8") as fh:
            expected = [l.rstrip("\n") for l in fh]
        got = list(iter_lines(path, chunk_size=64))
        self.assertEqual(got, expected)

    def test_iter_lines_handles_multibyte_boundary(self):
        """块大小刚好切在中文字符中间时不能报错或产生乱码。"""
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.log")
            with open(p, "w", encoding="utf-8") as fh:
                fh.write("中文日志行\n" * 50)
            got = list(iter_lines(p, chunk_size=7))
        self.assertEqual(len(got), 50)
        self.assertEqual(got[0], "中文日志行")


class TestAttck(unittest.TestCase):
    def test_describe(self):
        self.assertIn("T1110", describe("T1110"))
        self.assertIn("暴力破解", describe("T1110"))

    def test_unknown_id_passthrough(self):
        self.assertEqual(describe("T9999"), "T9999")
        self.assertIsNone(get("T9999"))

    def test_coverage_grouping(self):
        cov = summarize_coverage(["T1110.001", "T1110.003", "T1021.002"])
        tactics = [c["tactic"] for c in cov]
        self.assertIn("凭据访问", tactics)
        self.assertIn("横向移动", tactics)

    def test_findings_carry_technique(self):
        events = [ev(i, False, "203.0.113.9") for i in range(8)]
        from irscan.detectors import bruteforce
        out = bruteforce.detect(make_ctx(events))
        self.assertTrue(out)
        self.assertTrue(out[0].technique.startswith("T1110"))


class TestReportRendering(unittest.TestCase):
    def _result(self):
        snap = HostSnapshot(platform="linux", hostname="web-01")
        snap.errors = ["安全日志读不到"]
        r = ScanResult(snapshot=snap)
        from irscan.core.models import Finding
        r.add(Finding(title="测试发现", severity=Severity.HIGH, category="测试",
                      description="说明", recommendation="建议",
                      evidence=["证据1"], subjects=["X"], technique="T1110"))
        r.timeline = [TimelineEvent(timestamp=datetime(2024, 1, 15, 9, 0),
                                    label="登录失败 ×5", detail="192.0.2.4",
                                    severity=Severity.HIGH)]
        r.finished_at = datetime(2024, 1, 15, 9, 1)
        return r

    def test_html_contains_key_sections(self):
        html = render(self._result())
        for key in ("攻击时间线", "ATT&CK", "采集盲区", "T1110", "测试发现"):
            self.assertIn(key, html)

    def test_html_escapes_hostile_input(self):
        """日志内容里的 <script> 不能被原样渲染进报告。"""
        from irscan.core.models import Finding
        snap = HostSnapshot(platform="linux")
        r = ScanResult(snapshot=snap)
        r.add(Finding(title=" injected", severity=Severity.LOW, category="x",
                      evidence=["<script>alert(1)</script>"]))
        html = render(r)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;", html)

    def test_markdown_contains_table(self):
        md = render_markdown(self._result())
        self.assertIn("| 严重 | 高危 |", md)
        self.assertIn("## 攻击时间线", md)

    def test_console_summary(self):
        s = render_console_summary(self._result())
        self.assertIn("测试发现", s)
        self.assertIn("采集盲区", s)

if __name__ == "__main__":
    unittest.main(verbosity=2)
