# irscan

主机应急响应排查工具。一条命令采集 Linux / Windows / macOS 主机的进程、网络连接、
持久化项、账户与安全日志，检测入侵痕迹，重建攻击时间线，输出 HTML / Markdown 报告，
检测项标注对应的 MITRE ATT&CK 技术编号。

纯 Python 标准库，无第三方依赖，可打包为单个文件 `irscan.pyz` 在断网机器上运行。

[![Python 3.9+](https://img.shields.io/badge/python-3.9%2B-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![third-party deps 0](https://img.shields.io/badge/third--party_deps-0-brightgreen)](#局限)
[![platform Linux·Windows·macOS](https://img.shields.io/badge/platform-Linux%20%C2%B7%20Windows%20%C2%B7%20macOS-blue)](#跨平台)
[![License MIT](https://img.shields.io/badge/license-MIT-lightgrey)](LICENSE)

![irscan 生成的应急响应报告](docs/report_top.png)

## 特性

- 无第三方依赖，`python irscan.pyz …` 即可运行，适用于断网、无 pip 权限的环境。
- 三个平台共用一套检测逻辑，采集层按平台分支。
- 输出包含告警列表与攻击时间线：登录、Web 攻击、文件落地、进程按时间聚成一条线，
  并标注"爆破成功"这类性质发生变化的节点。
- 检测规则是外部 JSON，字段沿用 Sigma 命名，增加规则不需要改代码。
- 采不到的数据单独列为"采集盲区"，与"未发现异常"分开统计。

## 快速开始

仓库自带一份完整的入侵样例数据，不需要真实环境就能跑出报告：

```bash
python -m irscan --offline \
  --auth-log samples/auth.log \
  --web-log samples/access.log \
  --webroot samples/wwwroot \
  --ioc samples/ioc_demo.txt \
  --timeline -o demo_report.html
```

无需安装，Python 3.9 及以上：

```bash
python -m irscan                      # 排查当前主机
python -m irscan --auth-log /var/log/auth.log --webroot /var/www/html -o report.html
python -m irscan --webroot C:\inetpub\wwwroot -o report.html   # Windows / IIS
python -m irscan --offline --auth-log samples/auth.log      # 只分析给定文件，不采集本机
python -m irscan --baseline-save baseline.json              # 保存基线
python -m irscan --baseline-diff baseline.json              # 事后对比，只输出变化项
python -m irscan --version                                  # 查看版本
```

Windows 上读取安全日志（4624/4625）与 WMI 订阅需要管理员权限，权限不足时跳过该项，
并在报告的采集盲区中注明。

报告默认写入当前目录的 `irscan_report.html`，用 `-o` 指定其他路径；`--json` / `--markdown`
可同时导出结构化结果。退出码 `0` 表示无高危，`1` 表示存在高危，`2` 表示存在严重项，
可用于定时巡检。

打包为单文件（`python tools/build_pyz.py` 生成 `dist/irscan.pyz`，约 84 KB）：

```bash
python irscan.pyz --auth-log /var/log/auth.log -o report.html
```

`--auth-log` / `--web-log` / `--webroot` / `--ioc` / `--rules` 均可重复传入；
`--root` 指向挂载的证据盘做离线取证，`--offline` 关闭实时采集。
完整参数见 `python -m irscan --help`。

## 报告内容

首屏结构为总览 → 高危结论 → 采集盲区 → 明细证据，`docs/report_full.png` 是结论卡片的
完整截图，包含证据与处置建议。

时间线按时间间隔聚成段。同一来源此前有失败记录、随后登录成功的，单独标为严重：

```
01-15 09:02:11  [高危] 登录失败 ×25：203.0.113.77（疑似爆破）
01-15 09:05:11  [高危] SQL 注入探测 ×3（203.0.113.77）
01-15 09:33:41  [严重] 登录成功：root@203.0.113.77（此前有失败记录，疑为爆破成功）
01-15 09:33:55  [中危] 文件上传行为 ×2（203.0.113.77）
```

Webshell 采用加权评分，出现 `system(` 只累计 1 分，正常运行维护脚本不会被整体判为高危：

| 样本 | 命中 | 定级 |
|---|---|---|
| `uploads/img_20240115.php` | 一句话木马 | 高危（11 分） |
| `uploads/tunnel.jsp` | JSP Runtime.exec | 中危（3 分） |
| `includes/legacy_helper.php` | 仅业务 `system()` | 低危（1 分） |

## 检测能力

| 项目 | Linux | Windows | macOS |
|---|---|---|---|
| 进程 | 读 `/proc`（含父进程、命令行、exe） | CIM `Win32_Process` | `ps` |
| 网络连接 | 解析 `/proc/net/tcp`，socket inode 反查进程 | `netstat -ano` | `lsof` |
| 持久化 | systemd、cron、rc.local | 计划任务、注册表 Run、启动文件夹、服务、WMI 订阅 | launchd plist、cron |
| 账户 | `/etc/passwd`（UID=0、可登录 shell） | `Win32_UserAccount` | `dscl` |
| 安全日志 | auth.log / secure（传统 syslog 与带年份的 RFC 3339 两种时间格式） | `wevtutil` 导出 XML 解析 4624/4625 | — |
| 关键文件 | SUID/SGID、`ld.so.preload`、`authorized_keys`、sudoers、hosts | hosts、启动文件夹 | — |

| 模块 | 内容 | ATT&CK |
|---|---|---|
| 暴力破解 | 滑动窗口失败次数、爆破后成功登录、密码喷洒 | T1110.001 / T1110.003 |
| 异常登录 | 同一账号短时间从多个 IP 登录成功 | T1078 |
| 横向移动 | LogonType=3 多主机网络登录、PsExec 类、RDP 来源为公网 | T1021.002 / T1133 |
| Webshell | 加权评分特征扫描（PHP/JSP/ASP），可选 YARA | T1505.003 |
| Web 攻击 | SQL 注入、命令注入、路径穿越、扫描器指纹、敏感文件泄露 | T1190 / T1552 / T1595 |
| 文件系统 | LD_PRELOAD 后门、异常 SUID、WMI 订阅、hosts 劫持、服务路径缺陷 | T1574 / T1547.008 / T1546.003 |
| 主机侧 | 反弹 shell、PowerShell 编码命令、LOLBAS、凭据窃取、进程名伪装 | T1059 / T1003 / T1036 |
| 持久化 | 临时目录启动项、下载执行、关闭防护类动作 | T1053 / T1547.001 |
| 账户 | 影子 root、系统账户带登录 shell、内置 Administrator | T1136 / T1098 |
| 时间线 | 按时间聚类还原攻击过程，标注攻击链闭合点 | — |
| 完整性交叉验证 | 进程双视角比对、系统命令包校验、shell 初始化后门、网卡混杂模式 | T1014 / T1562.001 / T1546.004 / T1040 |
| IOC | 哈希 / 文件名 / 内容正则比对外部情报 | T1204.002 |

## 检测规则

规则为 JSON，位于 `irscan/data/rules/`，字段沿用 Sigma 习惯（`id`、`title`、`level`、
`falsepositives`、`references`、`tags`），直接沿用社区规则时不需要重命名字段。

```json
{
  "id": "proc-reverse-shell-nc-e",
  "title": "nc -e 绑定 shell",
  "target": ["process"],
  "mode": "any",
  "level": "critical",
  "patterns": [{ "re": "\\b(?:nc|ncat|netcat)\\b.{0,30}-e\\s" }],
  "tags": ["attack.t1071"]
}
```

`target` 指定作用的数据类型（`file` / `process` / `startup`）；`mode` 支持 `any`、`all`、
`score`（按权重累加后定级）；`tags` 中的 `attack.tXXXX` 自动映射为 ATT&CK 技术；
`falsepositives` 会显示在报告里，便于复核时判断误报原因。

```bash
python -m irscan --rules ./myrules --webroot /var/www/html   # 同 id 覆盖内置规则
python -m irscan --list-rules                                # 查看当前生效的规则
```

单条规则解析失败时只跳过该规则，错误写入报告的采集盲区，不影响其余检测。
`enabled: false` 可停用某条内置规则，示例见 `rules/example_custom.json`。

## IOC

一个文件内可混用两种格式，支持 `md5` / `sha1` / `sha256` / `regex` / `filename`。
哈希命中判严重，文件名与内容正则命中判高危：

```
275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f   # 每行一个哈希
sha256;275a021bbf…fd0f;EICAR                                      # Loki 风格：类型;值;描述
filename;c99\.php$;已知后门文件名
```

哈希比对只能匹配已知样本，文件改动一个字节即失效，对 0day 无效。
`tools/fetch_ioc.py` 可拉取社区情报（signature-base 的 YARA 规则可正常获取，
abuse.ch 在部分网络环境下返回 405）。

## 代码结构

`collectors → parsers → detectors → report`。新增检测模块实现
`detect(ctx) -> list[Finding]`，并在 `detectors/__init__.py` 的 `DETECTORS` 中注册。

## 跨平台

| 平台 | 覆盖 | 说明 |
|---|---|---|
| Linux | 完整 | 采集逻辑以 `--root` 合成目录树验证 |
| Windows | 完整 | 安全日志与 WMI 采集需管理员权限 |
| macOS | 基础 | 无 `/proc`，走命令行采集；解析逻辑有单测，整条链路未在真实 macOS 上运行 |

Linux 的发行版差异（systemd 与 sysvinit 的路径、journald-only 环境没有 `/var/log/auth.log`、
busybox 版 `ps` 的输出格式）需要在真机上验证。

可移植性相关的两点：

- **采集根可注入（`--root`）。** 所有系统路径经 `BaseCollector._p()` 映射，可以把证据盘挂到
  `/mnt/evidence` 做离线取证。离线模式不执行 `ps` / `rpm` / `dpkg`，这些命令读取的是执行扫描的机器。
- **子系统独立容错。** `/proc` 缺失、PowerShell 被执行策略禁用、权限不足时，只把对应采集项记为盲区，
  其余采集继续执行，缺失项在报告中列出。

CI 在 ubuntu / windows / macOS 三个平台 × Python 3.9–3.13 上运行全量测试，另有一项
Linux 实时采集冒烟；macOS 采集冒烟设为允许失败，用于观察该采集器的实际状态。

## 性能

20 万行 auth.log + 30 万行 access.log + 4,948 个文件的站点目录，端到端约 4.4 秒。

| 阶段 | 吞吐 |
|---|---|
| auth.log 解析 | 308,790 行/s |
| Web 日志检测 | 353,622 行/s |
| Webshell 文件扫描 | 2,344 文件/s |
| 端到端（上述全部） | 4.39 s |

复现方式 `python tools/bench.py --quick`，测试方法与同类工具对比见
[PERFORMANCE.md](PERFORMANCE.md)。

Web 日志检测使用预编译正则和按 URI 的匹配结果缓存。
`--jobs` 默认为 1；并发读文件在小文件集合上收益为负（jobs=8 时 3.58 s，串行 2.30 s），
网络盘、机械盘或大文件场景可调高。

样例数据的离线分析结果为严重 2（爆破成功、IOC 命中）、高危 8、中危 2、低危 1，
可用上面的快速开始命令复现。

## 局限

- 只做线索提示，所有结论需人工复核后才能作为处置依据。
- 报告中的"未采集到"不等于"没有问题"。缺少管理员权限时 Windows 安全日志无法读取，
  爆破与横向移动检测会完全失效。
- Webshell 使用特征评分，对未知 0day 后门无效；业务代码中存在动态执行逻辑时仍可能误报。
- 时间线依赖日志完整性，攻击者清理过日志就会出现断点。
- 未覆盖：全盘文件完整性校验、内存马检测、ETW 行为埋点、流量分析。
- 没有自有恶意特征库，仅接入外部情报。
- 未在真实入侵事件中验证过。

## 与同类工具

完整对比见 [BENCHMARK.md](BENCHMARK.md)。GScan（2,829 star，同为 Python 单机排查，
已停止维护，仅在 CentOS 上测试）有 60 多个检测项和 10 万条以上特征，广度上超过本项目；
irscan 提供时间线、爆破成功关联、ATT&CK 映射、Windows 支持、基线对比和测试覆盖。
osquery / Velociraptor / Chainsaw / Hayabusa 属于生产级平台，规模不在同一量级。

规则外置、IOC 文件格式（Loki）、输出分级这几处设计参考了上述项目。

## 测试

```bash
python -m unittest discover -s tests -v
```

共 126 个用例，覆盖日志解析（跨年边界、IPv4-mapped 归一化）、爆破判定（跨分钟不漏报、
爆破成功关联）、Webshell 误报抑制、规则加载与覆盖、IOC 五类格式、时间线聚类、基线对比、
流式读取的多字节边界、跨平台采集、报告 XSS 转义。

## English

<details>
<summary>English summary</summary>

**irscan** — zero-dependency, single-file host incident-response scanner for
Linux / Windows / macOS, pure Python standard library.

One command collects host state (processes, connections, persistence, accounts, auth logs),
detects intrusion traces (brute force, webshells, LOLBins, IOCs), rebuilds an attack
timeline, and renders an HTML/Markdown report mapped to MITRE ATT&CK.
Build a single file with `python tools/build_pyz.py` (`python irscan.pyz …`), no pip and no
network required. Detection rules are external JSON with Sigma-style fields; data that could
not be collected is reported as coverage gaps.

Verification status: unit tests run on Linux, Windows and macOS in CI; the Linux and macOS
collectors are validated against synthetic fixtures. Not yet validated on a real intrusion.

</details>

## License

[MIT](LICENSE)。
