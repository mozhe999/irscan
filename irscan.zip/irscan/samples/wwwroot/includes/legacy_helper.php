<?php
/**
 * 正常业务文件示例：这里有一个 system() 调用，但它是运维脚本里的合法用法。
 *
 * 这个文件存在的意义是验证误报抑制——如果检测只看"有没有 system("，
 * 它会被误标成 webshell。加权评分下它只会拿到 1 分，被判为"低危"而非"高危"，
 * 提醒人工看一眼但不会造成误报噪音。
 */
function flush_cache() {
    system('/usr/bin/php /var/www/artisan cache:clear');
    return true;
}

function build_asset_manifest() {
    exec('/usr/bin/npm run build', $out, $code);
    return $code === 0;
}
