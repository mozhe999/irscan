<?php
/**
 * 正常站点首页示例 —— 用于验证检测器不会误报干净文件。
 */

function render_header(string $title): string {
    return '<h1>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h1>';
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;   // 强制转型，不存在注入问题
echo render_header('示例站点');
echo '<p>当前 ID：' . $id . '</p>';
