# 同类工具对比

star 数取自 GitHub REST API，为统计时的快照。能力判断基于各项目 README 与源码。

性能数据见 [PERFORMANCE.md](PERFORMANCE.md)。

## 一、定位分层

| 梯队 | 代表项目 | star | 语言 | 维护状态 | 性质 |
|---|---|---:|---|---|---|
| 生产级 | osquery | 23,695 | C++ | 活跃 | 端点状态查询引擎，可 SQL 化 |
| 生产级 | PEASS-ng (linPEAS/winPEAS) | 20,726 | — | 活跃 | 权限提升枚举，红蓝通用 |
| 生产级 | Sigma 规则库 | 11,354 | — | 活跃 | 通用检测规则标准 |
| 生产级 | Security Onion | 4,949 | Shell | 活跃 | 完整 SOC 平台 |
| 生产级 | Velociraptor | 4,384 | Go | 活跃 | 企业级 DFIR，VQL 查询 |
| 生产级 | Loki | 3,801 | Python | 低频 | IOC/YARA 主机扫描 |
| 生产级 | Chainsaw | 3,702 | Rust | 活跃 | Windows 事件日志检索，Sigma 驱动 |
| 生产级 | Hayabusa | 3,418 | Rust | 活跃 | Windows 事件日志时间线 |
| 成熟单机 | **GScan** | **2,829** | Python | **停更** | Linux 主机应急排查 |
| 成熟单机 | CyLR | 737 | C# | 停更 | Windows 取证收集 |
| 个人项目 | SSlogs | 143 | — | — | Web 日志分析 |
| 个人项目 | FastLinLog | 48 | — | — | Linux 日志可视化 |
| 个人项目 | AutoIR_Remote | 35 | — | — | CTF 应急脚本 |
| 个人项目 | ir-forensic-analysis | 28 | — | — | 11 维检测 |
| 个人项目 | mcp-irt | 22 | — | — | 主机侧应急响应 |
| **本项目** | **irscan** | **0** | Python | 新项目 | 跨平台排查 + 研判报告 |

osquery / Velociraptor / Chainsaw / Hayabusa 为企业级平台，部署方式与使用场景不同。
同为 Python 单机应急排查的是 GScan，已停更，仅在 CentOS 上测试。

## 二、与 GScan 逐项对照

GScan v0.1 的 CheckList 约 60 项。

### GScan 有、irscan 没有

| 检测项 | 说明 |
|---|---|
| 文件恶意特征扫描 | GScan 内置 10 万+ 特征库 |
| 已知 Rootkit 文件 / LKM 特征 | 依赖特征库维护 |
| 隐藏文件、临时目录、用户目录扫描 | 全盘扫描；irscan 只做定点 |
| 境外 IP 操作与连接 | 需要 IP 归属库 |
| CPU/内存异常进程、僵尸进程 | 需要采样对比，单次快照无法判定 |
| wtmp / utmp / lastlog 登录历史 | 二进制格式，尚未实现 |
| SSH wrapper / inetd / xinetd 后门 | 已覆盖 ld.so.preload 与 authorized_keys，未覆盖这几项 |
| DNS / iptables 配置检测 | 属基线核查 |
| 多 Web 容器 webroot 自动识别 | 需手动指定 `--webroot` |

### irscan 有、GScan 没有

| 能力 | 说明 |
|---|---|
| 攻击时间线重建 | 按时间顺序还原登录、Web 攻击、文件落地、进程活动 |
| 爆破成功判定 | 失败记录后出现成功登录时标为严重，作为攻击链闭合点 |
| 密码喷洒 / impossible travel | GScan 只做失败计数 |
| 横向移动检测 | 4624 LogonType=3 按账号聚合来源主机 |
| WMI 永久事件订阅 | GScan 为 Linux 工具 |
| MITRE ATT&CK 映射 | 报告给出攻击覆盖的战术阶段 |
| 基线对比 | `--baseline-save` / `--baseline-diff` |
| 双视角交叉验证 | 进程与命令完整性比对 |
| 规则外置 | JSON 规则，改特征不改代码 |
| HTML / Markdown 报告 | GScan 输出纯文本 |
| 单元测试 | 126 个；GScan 0 个 |
| 跨平台 | Linux / Windows / macOS，CI 覆盖 3 OS × 5 Python 版本；GScan 仅 CentOS |
| 离线取证 | `--root` 分析挂载的证据盘 |

GScan 检测项更多，irscan 侧重时间线与结论输出。

## 三、差距

| 差距 | 现状 |
|---|---|
| 自有恶意特征库 | 无。可接外部哈希与 YARA，自身不建库 |
| 内存马 / 无文件攻击 | 未覆盖，需要进程内存扫描与运行时解析 |
| Linux 全盘扫描性能 | 2,344 文件/s，受磁盘 IO 限制（见 PERFORMANCE.md） |
| Windows 事件日志覆盖 | 4624/4625 之外未充分验证 |
| macOS 采集 | 解析逻辑有单测，整条采集链路未在真实 macOS 上运行 |
| 真实入侵验证 | 未在真实攻击事件中验证 |

macOS 采集器在 CI 的 macOS runner 上运行，文档中列为「基础」。
真实攻击不按构造的剧本走，攻击剧本上的验证结果不能等同于实战效果。

## 四、恶意特征库的三种形态

| 形态 | 代表 | 判什么 |
|---|---|---|
| 自带特征库 | ClamAV、GScan（10 万+）、Loki、rkhunter、chkrootkit | 这个文件是否恶意 |
| 规则库驱动 | SigmaHQ（11.4k star）、signature-base（753 个 YARA 文件）、Hayabusa | 这个行为是否可疑 |
| 不带库 | linPEAS（20.7k star）、osquery、Velociraptor | 只输出事实，判断交给人 |

irscan 不自建特征库，接入两类外部情报：哈希 IOC（零依赖，误报率低）与 YARA（可选依赖，可匹配变体）。
哈希的局限是文件改动一个字节即失效，对 0day 无效。
