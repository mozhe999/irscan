/*
 * 可选增强：YARA 规则示例。
 *
 * 使用方式（需自行安装第三方依赖 yara-python）：
 *     pip install yara-python
 *     set IRSCAN_YARA_RULES=rules        # Windows
 *     export IRSCAN_YARA_RULES=rules     # Linux
 *     python -m irscan --webroot /var/www/html
 *
 * 说明：内置特征库是主力，YARA 只是锦上添花。
 * 应急响应时客户机上大概率没有 yara 环境，所以本项目绝不依赖它。
 */

rule PHP_OneLine_Webshell
{
    meta:
        description = "PHP 一句话木马：请求参数直接进入 eval/assert"
        severity     = "high"
    strings:
        $eval_post   = /@?\s*eval\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)/ nocase
        $assert_post = /@?\s*assert\s*\(\s*\$_/ nocase
        $var_func    = /\$_(GET|POST|REQUEST)\s*\[[^\]]{1,40}\]\s*\(/ nocase
    condition:
        any of them
}

rule PHP_Obfuscated_Payload
{
    meta:
        description = "解码后执行：base64/gzinflate/str_rot13 配合执行函数"
        severity     = "high"
    strings:
        $dec_func = /(base64_decode|gzinflate|str_rot13|gzuncompress)/ nocase
        $exec     = /(eval|assert|system|exec|passthru|shell_exec|preg_replace)/ nocase
        $long_b64 = /[A-Za-z0-9+\/]{200,}={0,2}/
    condition:
        $dec_func and $exec and $long_b64
}

rule Known_Webshell_Tool
{
    meta:
        description = "已知 webshell / 隧道工具标识"
        severity     = "critical"
    strings:
        $cn_a = "冰蝎" nocase
        $cn_b = "哥斯拉" nocase
        $cn_c = "蚁剑" nocase
        $cn_d = "菜刀" nocase
        $en_a = "antsword" nocase
        $en_b = "godzilla" nocase
        $en_c = "behinder" nocase
        $en_d = "reGeorg" nocase
        $en_e = "neo-reGeorg" nocase
    condition:
        any of them
}

rule JSP_Runtime_Exec
{
    meta:
        description = "JSP 后门调用 Runtime.exec"
        severity     = "high"
    strings:
        $exec = /Runtime\s*\.\s*getRuntime\s*\(\s*\)\s*\.\s*exec/ nocase
        $req  = /request\.getParameter/ nocase
    condition:
        all of them
}
